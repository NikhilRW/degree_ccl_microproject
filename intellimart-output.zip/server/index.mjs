globalThis.__nitro_main__ = import.meta.url;
import { o as NodeResponse, s as serve } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
// #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs").then((n) => n.z)) };
globalThis.__nitro_vite_envs__ = services;
// node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
// #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-25T10:32:06.000Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-08-25T10:32:06.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/images/backpack.jpg": {
		"type": "image/jpeg",
		"etag": "\"13a77-2mGgLbCYVPgXuNsx7/gpYk2Nwsc\"",
		"mtime": "2026-10-24T08:31:33.882Z",
		"size": 80503,
		"path": "../public/images/backpack.jpg"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"d7-9vUD331trD4XkALJHcxkPj/Ozdg\"",
		"mtime": "2026-10-25T10:08:56.327Z",
		"size": 215,
		"path": "../public/favicon.svg"
	},
	"/images/books.jpg": {
		"type": "image/jpeg",
		"etag": "\"11d64-GYVw4032bxE9IQXzIKKt0XHxKGc\"",
		"mtime": "2026-10-24T08:31:33.897Z",
		"size": 73060,
		"path": "../public/images/books.jpg"
	},
	"/images/camera.jpg": {
		"type": "image/jpeg",
		"etag": "\"7072-AvUFW10GYSf7IlMQsLEiI45+lo0\"",
		"mtime": "2026-10-24T08:31:34.165Z",
		"size": 28786,
		"path": "../public/images/camera.jpg"
	},
	"/images/computing.jpg": {
		"type": "image/jpeg",
		"etag": "\"ea3e-a4pLBg3FJggvP8aFeawJMcdS5s4\"",
		"mtime": "2026-10-24T08:31:34.118Z",
		"size": 59966,
		"path": "../public/images/computing.jpg"
	},
	"/images/coffee.jpg": {
		"type": "image/jpeg",
		"etag": "\"110c3-3+6p/b5RB4xQsdl5oQbHrGOjpeA\"",
		"mtime": "2026-10-24T08:31:33.992Z",
		"size": 69827,
		"path": "../public/images/coffee.jpg"
	},
	"/images/drone.jpg": {
		"type": "image/jpeg",
		"etag": "\"10b57-5bNU7O9CQyD0uPw04+11tIasklw\"",
		"mtime": "2026-10-24T08:31:33.897Z",
		"size": 68439,
		"path": "../public/images/drone.jpg"
	},
	"/images/chair.jpg": {
		"type": "image/jpeg",
		"etag": "\"2a00a-Kepdo5mvsCwiguT4prMP6Zrtlf0\"",
		"mtime": "2026-10-24T08:31:33.945Z",
		"size": 172042,
		"path": "../public/images/chair.jpg"
	},
	"/images/controller.jpg": {
		"type": "image/jpeg",
		"etag": "\"6802-LiBhns5/4XXCrLPr/DNwnOUTf/8\"",
		"mtime": "2026-10-24T08:31:33.836Z",
		"size": 26626,
		"path": "../public/images/controller.jpg"
	},
	"/images/earbuds.jpg": {
		"type": "image/jpeg",
		"etag": "\"9a33-heoxi60j78vgNqcsNtC5SL7BxYI\"",
		"mtime": "2026-10-24T08:31:33.799Z",
		"size": 39475,
		"path": "../public/images/earbuds.jpg"
	},
	"/images/electronics.jpg": {
		"type": "image/jpeg",
		"etag": "\"7a76-w7SMrcbEyidhGgLGWF13FWl/gaQ\"",
		"mtime": "2026-10-24T08:31:33.807Z",
		"size": 31350,
		"path": "../public/images/electronics.jpg"
	},
	"/images/fashion.jpg": {
		"type": "image/jpeg",
		"etag": "\"ebee-hzHwFf1dKOBE3ovGAPyM8Q+lUnA\"",
		"mtime": "2026-10-24T08:31:33.866Z",
		"size": 60398,
		"path": "../public/images/fashion.jpg"
	},
	"/images/gaming.jpg": {
		"type": "image/jpeg",
		"etag": "\"10c58-uAwhuJUSktFg7xDGrEnu1Ov8S58\"",
		"mtime": "2026-10-24T08:31:33.882Z",
		"size": 68696,
		"path": "../public/images/gaming.jpg"
	},
	"/images/hub.jpg": {
		"type": "image/jpeg",
		"etag": "\"d141-GuQX+WJIEBiccjTW5Nyw9E0QGTk\"",
		"mtime": "2026-10-24T08:41:30.256Z",
		"size": 53569,
		"path": "../public/images/hub.jpg"
	},
	"/images/headphones-dark.jpg": {
		"type": "image/jpeg",
		"etag": "\"34451-IuKFWEFXQhlE+vRBO0DKtGcWTAk\"",
		"mtime": "2026-10-24T08:31:33.964Z",
		"size": 214097,
		"path": "../public/images/headphones-dark.jpg"
	},
	"/images/headphones-detail.jpg": {
		"type": "image/jpeg",
		"etag": "\"253da-aISzCzEVNLYfE8NUMjbkEfnWzs0\"",
		"mtime": "2026-10-24T08:31:34.118Z",
		"size": 152538,
		"path": "../public/images/headphones-detail.jpg"
	},
	"/images/monitor.jpg": {
		"type": "image/jpeg",
		"etag": "\"48ce-4Dr1ZcFKeZ9fvnW6D5bhzfp6jHY\"",
		"mtime": "2026-10-24T08:31:33.848Z",
		"size": 18638,
		"path": "../public/images/monitor.jpg"
	},
	"/images/headphones-yellow.jpg": {
		"type": "image/jpeg",
		"etag": "\"24270-xyHGsDC4gDQNR8o8ASAAkWX3N2s\"",
		"mtime": "2026-10-24T08:31:33.892Z",
		"size": 148080,
		"path": "../public/images/headphones-yellow.jpg"
	},
	"/images/lamp.jpg": {
		"type": "image/jpeg",
		"etag": "\"cce9-X8Q1KbpKTTXR9vzYrcotBahMYX8\"",
		"mtime": "2026-10-24T08:31:33.809Z",
		"size": 52457,
		"path": "../public/images/lamp.jpg"
	},
	"/images/home.jpg": {
		"type": "image/jpeg",
		"etag": "\"13a8e-B8aj7bmG1cCluH2PX1Bp6z5qYRI\"",
		"mtime": "2026-10-24T08:31:33.895Z",
		"size": 80526,
		"path": "../public/images/home.jpg"
	},
	"/images/keyboard.jpg": {
		"type": "image/jpeg",
		"etag": "\"1adf8-UKAJYyevjwPGF0ZMOZUp4gLj6NE\"",
		"mtime": "2026-10-24T08:31:34.372Z",
		"size": 110072,
		"path": "../public/images/keyboard.jpg"
	},
	"/images/mouse.jpg": {
		"type": "image/jpeg",
		"etag": "\"8cf7-4q9qOoUwnTuORhKXx4OvAkGO+Dw\"",
		"mtime": "2026-10-24T08:31:33.866Z",
		"size": 36087,
		"path": "../public/images/mouse.jpg"
	},
	"/images/smart.jpg": {
		"type": "image/jpeg",
		"etag": "\"a842-U9pe2Qoq4RWNN+qBU8VYH437z0w\"",
		"mtime": "2026-10-24T08:31:34.769Z",
		"size": 43074,
		"path": "../public/images/smart.jpg"
	},
	"/images/sneakers.jpg": {
		"type": "image/jpeg",
		"etag": "\"e98f-JpRs6F6wMHaqGJw+ZlgnJy7EcFg\"",
		"mtime": "2026-10-24T08:31:33.813Z",
		"size": 59791,
		"path": "../public/images/sneakers.jpg"
	},
	"/images/speaker.jpg": {
		"type": "image/jpeg",
		"etag": "\"242d1-qqJq+pvwW6tz4+ZBzjIjXeIaF2c\"",
		"mtime": "2026-10-24T08:31:33.964Z",
		"size": 148177,
		"path": "../public/images/speaker.jpg"
	},
	"/images/ssd.jpg": {
		"type": "image/jpeg",
		"etag": "\"35040-EDTS4OMyIp1bqkqPShSVdNFL+ug\"",
		"mtime": "2026-10-24T08:41:12.351Z",
		"size": 217152,
		"path": "../public/images/ssd.jpg"
	},
	"/images/sunglasses.jpg": {
		"type": "image/jpeg",
		"etag": "\"74f0-nZd/EFkK+4JKNnlOESImraKtMHs\"",
		"mtime": "2026-10-24T08:41:12.304Z",
		"size": 29936,
		"path": "../public/images/sunglasses.jpg"
	},
	"/images/watch.jpg": {
		"type": "image/jpeg",
		"etag": "\"603f-o3P6l3eQ4V/i7xe29WjAizFUHjU\"",
		"mtime": "2026-10-24T08:31:33.897Z",
		"size": 24639,
		"path": "../public/images/watch.jpg"
	},
	"/assets/about-DMmxkCV9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"869-pCwE+ckbCvoz/jeXxKcr9ILsu4g\"",
		"mtime": "2026-10-25T10:37:25.038Z",
		"size": 2153,
		"path": "../public/assets/about-DMmxkCV9.js"
	},
	"/assets/admin-DbzXWEiT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"446f-ueGHIpVsbJ++ThErfzgfFm8/lqM\"",
		"mtime": "2026-10-25T10:37:25.038Z",
		"size": 17519,
		"path": "../public/assets/admin-DbzXWEiT.js"
	},
	"/assets/account-Bzs3u38c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15fc-dye33GKu8ZXWUeed425ckXO+/+o\"",
		"mtime": "2026-10-25T10:37:25.038Z",
		"size": 5628,
		"path": "../public/assets/account-Bzs3u38c.js"
	},
	"/assets/awsOrderService-fMJnOVBJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-e2IErgcXewTzCe9L6M78oTSiMKg\"",
		"mtime": "2026-10-25T10:37:25.040Z",
		"size": 320,
		"path": "../public/assets/awsOrderService-fMJnOVBJ.js"
	},
	"/assets/auth.functions-UL77L3Rs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"866b-HqAgWvtTsR/KEd5ZFyaSfo6akDQ\"",
		"mtime": "2026-10-25T10:37:25.040Z",
		"size": 34411,
		"path": "../public/assets/auth.functions-UL77L3Rs.js"
	},
	"/assets/awsProductService-RGpHkPqe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b2-6OBa9vvlhw4Da0EW/wiKDSDTbJo\"",
		"mtime": "2026-10-25T10:37:25.040Z",
		"size": 434,
		"path": "../public/assets/awsProductService-RGpHkPqe.js"
	},
	"/assets/arrow-up-right-Dh-ju6k2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9c-ZKJi7rrVSWrS5z+KjrzK2xCtGU4\"",
		"mtime": "2026-10-25T10:37:25.040Z",
		"size": 156,
		"path": "../public/assets/arrow-up-right-Dh-ju6k2.js"
	},
	"/assets/cart-D-TdQk-U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f4-0YpDSAbYEHx4hSw57SiZAvuptq4\"",
		"mtime": "2026-10-25T10:37:25.040Z",
		"size": 2548,
		"path": "../public/assets/cart-D-TdQk-U.js"
	},
	"/assets/button-qhEr170a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10c68-hiA2XjPJLuUJA5vBah7f+yX8BMo\"",
		"mtime": "2026-10-25T10:37:25.040Z",
		"size": 68712,
		"path": "../public/assets/button-qhEr170a.js"
	},
	"/assets/categories-CL59L2BW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"770-dRRvCnLsgpsDUmIWarTOGYXBD2w\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 1904,
		"path": "../public/assets/categories-CL59L2BW.js"
	},
	"/assets/catalogue.functions-BvXrAWzM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"320-lhETIgzVXy8/Lx+S9NI1g1a29mo\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 800,
		"path": "../public/assets/catalogue.functions-BvXrAWzM.js"
	},
	"/assets/deals-BBmmU3kj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"52f-WaLNqIO50AcYuYJ3TtnAkFT4Hko\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 1327,
		"path": "../public/assets/deals-BBmmU3kj.js"
	},
	"/assets/checkout-vVDBMKBJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34bf-WLwjyyGopxJm9e1MCkyXQIlgC4U\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 13503,
		"path": "../public/assets/checkout-vVDBMKBJ.js"
	},
	"/assets/dist-BQlO0BAk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"332-vPXLsZszCYRJhsGlX/+iHAMN86Y\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 818,
		"path": "../public/assets/dist-BQlO0BAk.js"
	},
	"/assets/createServerFn-9qR_BEb8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a32c-Gh7YJKXy233keUFmTpWMwuYQUvM\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 41772,
		"path": "../public/assets/createServerFn-9qR_BEb8.js"
	},
	"/assets/dist-CBiRINxF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21ad-/5BHOiawhvV9io3lEafp+zof0l8\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 8621,
		"path": "../public/assets/dist-CBiRINxF.js"
	},
	"/assets/contracts-CGpFugt-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1760f-tBrjSoXm3PGg1C7qcuunrEYafIQ\"",
		"mtime": "2026-10-25T10:37:25.042Z",
		"size": 95759,
		"path": "../public/assets/contracts-CGpFugt-.js"
	},
	"/assets/forgot-password-iry8y8ly.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e5-6ZYmhgtRFAVNbkk4GGH7fZZrD+8\"",
		"mtime": "2026-10-25T10:37:25.044Z",
		"size": 2277,
		"path": "../public/assets/forgot-password-iry8y8ly.js"
	},
	"/assets/dist-DjPkIGPZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"106e-awLSFfAoaYBi9mlAGUu+jQ0yfx0\"",
		"mtime": "2026-10-25T10:37:25.044Z",
		"size": 4206,
		"path": "../public/assets/dist-DjPkIGPZ.js"
	},
	"/assets/index-CAsBlBF8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c02b-qdNjqEa5PkBdwaJpJH80I5DJdkQ\"",
		"mtime": "2026-10-25T10:37:25.036Z",
		"size": 376875,
		"path": "../public/assets/index-CAsBlBF8.js"
	},
	"/assets/label-CqZ_4DMk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"288-MrjAuDsLz7hW5UyLWgX6sIa+NH0\"",
		"mtime": "2026-10-25T10:37:25.044Z",
		"size": 648,
		"path": "../public/assets/label-CqZ_4DMk.js"
	},
	"/assets/input-B2ipAO5V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"247-uRtr4o2vbZ8wFtt1HMQyTePTP0M\"",
		"mtime": "2026-10-25T10:37:25.044Z",
		"size": 583,
		"path": "../public/assets/input-B2ipAO5V.js"
	},
	"/assets/order-confirmation-D5SmI5OD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d44-IMS1RGsWKJLjcWRvbdwigkaNc/E\"",
		"mtime": "2026-10-25T10:37:25.044Z",
		"size": 3396,
		"path": "../public/assets/order-confirmation-D5SmI5OD.js"
	},
	"/assets/login-PC4ZRYNF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a60-GmxLL6OKx4jOZndzdb9AUYrFN54\"",
		"mtime": "2026-10-25T10:37:25.044Z",
		"size": 2656,
		"path": "../public/assets/login-PC4ZRYNF.js"
	},
	"/assets/ProductGrid-CN1c9vXi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"93b-/WgPDjB/zthKL228n87NnLloQdY\"",
		"mtime": "2026-10-25T10:37:25.038Z",
		"size": 2363,
		"path": "../public/assets/ProductGrid-CN1c9vXi.js"
	},
	"/assets/register-D9nc2ruL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c33-UHHXPRVZQXYqIjEw6MGKqXQTWtk\"",
		"mtime": "2026-10-25T10:37:25.046Z",
		"size": 3123,
		"path": "../public/assets/register-D9nc2ruL.js"
	},
	"/assets/product._id-Ke4HFc9u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fc9-eK18MiUy14sK4ZFt9IXmuGk0cuA\"",
		"mtime": "2026-10-25T10:37:25.044Z",
		"size": 12233,
		"path": "../public/assets/product._id-Ke4HFc9u.js"
	},
	"/assets/rpc-C33UrGri.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3db-JgOvWnYEPtYhZe4R9LzCzYVKR8k\"",
		"mtime": "2026-10-25T10:37:25.046Z",
		"size": 987,
		"path": "../public/assets/rpc-C33UrGri.js"
	},
	"/assets/routes-Bmc3mr4u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13ed-LjoPHe6+j45u0p4wz7QyxaKaln8\"",
		"mtime": "2026-10-25T10:37:25.046Z",
		"size": 5101,
		"path": "../public/assets/routes-Bmc3mr4u.js"
	},
	"/assets/search-eCXg1NtW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6eb-MddaVOmKrlpBbDQCCiQ9s3i3/4s\"",
		"mtime": "2026-10-25T10:37:25.046Z",
		"size": 1771,
		"path": "../public/assets/search-eCXg1NtW.js"
	},
	"/assets/select-DTDhpeq-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd8a-pPXyyG1e7TR9Dplw93k3/kZf0So\"",
		"mtime": "2026-10-25T10:37:25.046Z",
		"size": 48522,
		"path": "../public/assets/select-DTDhpeq-.js"
	},
	"/assets/shop-NLcwlW2D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"514e-xiquqUxISsXOtqIdFnNhTUiTJcU\"",
		"mtime": "2026-10-25T10:37:25.046Z",
		"size": 20814,
		"path": "../public/assets/shop-NLcwlW2D.js"
	},
	"/assets/tabs-TsxrqxgL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dbc-3VtIhhPwhBp1lwfcALzuEs/F0qQ\"",
		"mtime": "2026-10-25T10:37:25.048Z",
		"size": 3516,
		"path": "../public/assets/tabs-TsxrqxgL.js"
	},
	"/assets/verify-email-D2Z_bVUg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"667-Pif+mRFjgQ9zliZb8uJmR+apVr0\"",
		"mtime": "2026-10-25T10:37:25.048Z",
		"size": 1639,
		"path": "../public/assets/verify-email-D2Z_bVUg.js"
	},
	"/assets/styles-B_DuRwGP.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"168ff-dWJ6bQlMuLOGVtih1FPfGsrIRIE\"",
		"mtime": "2026-10-25T10:37:25.048Z",
		"size": 92415,
		"path": "../public/assets/styles-B_DuRwGP.css"
	}
};
// #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
// #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
// node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
// #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_xh_6C5 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_xh_6C5
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
// node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
// #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
// #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
// node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
// node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
// #nitro/virtual/tracing
var tracingSrvxPlugins = [];
// node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
export { node_server_default as default };
