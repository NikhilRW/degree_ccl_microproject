// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BkRCMr-U.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/account",
			"/admin",
			"/cart",
			"/categories",
			"/checkout",
			"/deals",
			"/forgot-password",
			"/health",
			"/login",
			"/order-confirmation",
			"/register",
			"/search",
			"/shop",
			"/verify-email",
			"/product/$id"
		],
		preloads: [
			"/assets/index-CAsBlBF8.js",
			"/assets/button-qhEr170a.js",
			"/assets/createServerFn-9qR_BEb8.js",
			"/assets/auth.functions-UL77L3Rs.js",
			"/assets/rpc-C33UrGri.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CAsBlBF8.js"
		} }]
	},
	"/": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bmc3mr4u.js",
			"/assets/arrow-up-right-Dh-ju6k2.js",
			"/assets/ProductGrid-CN1c9vXi.js",
			"/assets/awsProductService-RGpHkPqe.js"
		]
	},
	"/about": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DMmxkCV9.js"]
	},
	"/account": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-Bzs3u38c.js",
			"/assets/awsProductService-RGpHkPqe.js",
			"/assets/awsOrderService-fMJnOVBJ.js",
			"/assets/tabs-TsxrqxgL.js"
		]
	},
	"/admin": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DbzXWEiT.js",
			"/assets/select-DTDhpeq-.js",
			"/assets/tabs-TsxrqxgL.js",
			"/assets/input-B2ipAO5V.js",
			"/assets/label-CqZ_4DMk.js",
			"/assets/contracts-CGpFugt-.js"
		]
	},
	"/cart": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/cart.tsx",
		children: void 0,
		preloads: ["/assets/cart-D-TdQk-U.js"]
	},
	"/categories": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-CL59L2BW.js",
			"/assets/arrow-up-right-Dh-ju6k2.js",
			"/assets/awsProductService-RGpHkPqe.js"
		]
	},
	"/checkout": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-vVDBMKBJ.js",
			"/assets/dist-BQlO0BAk.js",
			"/assets/awsOrderService-fMJnOVBJ.js",
			"/assets/dist-CBiRINxF.js",
			"/assets/dist-DjPkIGPZ.js",
			"/assets/input-B2ipAO5V.js",
			"/assets/label-CqZ_4DMk.js"
		]
	},
	"/deals": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/deals.tsx",
		children: void 0,
		preloads: [
			"/assets/deals-BBmmU3kj.js",
			"/assets/ProductGrid-CN1c9vXi.js",
			"/assets/awsProductService-RGpHkPqe.js"
		]
	},
	"/forgot-password": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-iry8y8ly.js",
			"/assets/input-B2ipAO5V.js",
			"/assets/label-CqZ_4DMk.js"
		]
	},
	"/login": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-PC4ZRYNF.js",
			"/assets/input-B2ipAO5V.js",
			"/assets/label-CqZ_4DMk.js"
		]
	},
	"/order-confirmation": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/order-confirmation.tsx",
		children: void 0,
		preloads: ["/assets/order-confirmation-D5SmI5OD.js", "/assets/awsOrderService-fMJnOVBJ.js"]
	},
	"/register": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-D9nc2ruL.js",
			"/assets/input-B2ipAO5V.js",
			"/assets/label-CqZ_4DMk.js"
		]
	},
	"/search": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-eCXg1NtW.js",
			"/assets/ProductGrid-CN1c9vXi.js",
			"/assets/catalogue.functions-BvXrAWzM.js"
		]
	},
	"/shop": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/shop.tsx",
		children: void 0,
		preloads: [
			"/assets/shop-NLcwlW2D.js",
			"/assets/dist-BQlO0BAk.js",
			"/assets/select-DTDhpeq-.js",
			"/assets/ProductGrid-CN1c9vXi.js",
			"/assets/awsProductService-RGpHkPqe.js",
			"/assets/dist-CBiRINxF.js",
			"/assets/label-CqZ_4DMk.js"
		]
	},
	"/verify-email": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/verify-email.tsx",
		children: void 0,
		preloads: [
			"/assets/verify-email-D2Z_bVUg.js",
			"/assets/input-B2ipAO5V.js",
			"/assets/label-CqZ_4DMk.js"
		]
	},
	"/product/$id": {
		filePath: "F:/Study (Random)/5TH Sem (Degree)/Microprojects/CCL/src/routes/product.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/product._id-Ke4HFc9u.js",
			"/assets/select-DTDhpeq-.js",
			"/assets/ProductGrid-CN1c9vXi.js",
			"/assets/awsProductService-RGpHkPqe.js",
			"/assets/tabs-TsxrqxgL.js",
			"/assets/input-B2ipAO5V.js",
			"/assets/label-CqZ_4DMk.js",
			"/assets/contracts-CGpFugt-.js"
		]
	}
} });
export { tsrStartManifest };
