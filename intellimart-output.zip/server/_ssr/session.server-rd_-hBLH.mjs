import { n as RevokeTokenCommand, o as GetTokensFromRefreshTokenCommand } from "../_libs/@aws-sdk/client-cognito-identity-provider+[...].mjs";
import { a as PutCommand, n as UpdateCommand, s as DeleteCommand } from "../_libs/@aws-sdk/lib-dynamodb+[...].mjs";
import { a as getItem, i as db, m as HttpError, n as clientId, o as getUser, p as table, r as cognito } from "./ssr.mjs";
import { l as setCookie$2, o as deleteCookie$2, s as getCookie } from "./server-CiMkYVYO.mjs";
import { createHash, randomBytes, randomUUID } from "node:crypto";
// node_modules/.nitro/vite/services/ssr/assets/session.server-rd_-hBLH.js
var secure = true;
var cookieName = "__Host-intellimart";
var cookieOptions = {
	httpOnly: true,
	secure,
	sameSite: "lax",
	path: "/"
};
var lifetime = 604800;
function sessionKey() {
	const value = getCookie(cookieName);
	if (!value || !/^[A-Za-z0-9_-]{43}$/.test(value)) return void 0;
	return `SESSION#${createHash("sha256").update(value).digest("hex")}`;
}
var publicSession = (row) => ({
	user: row.user,
	expiresAt: row.expiresAt * 1e3
});
var conditionalFailure = (error) => error instanceof Error && error.name === "ConditionalCheckFailedException";
async function revoke(token) {
	try {
		await cognito.send(new RevokeTokenCommand({
			ClientId: clientId,
			Token: token
		}));
	} catch (error) {
		if (!(error instanceof Error) || error.name !== "NotAuthorizedException") throw error;
	}
}
async function signOut() {
	const pk = sessionKey();
	try {
		if (pk) {
			const token = (await db.send(new DeleteCommand({
				TableName: table,
				Key: {
					pk,
					sk: "SESSION"
				},
				ReturnValues: "ALL_OLD"
			}))).Attributes?.["refreshToken"];
			if (typeof token === "string") await revoke(token);
		}
	} finally {
		deleteCookie$2(cookieName, cookieOptions);
	}
	return { signedOut: true };
}
async function createSession(accessToken, refreshToken, expiresIn) {
	const user = await getUser(accessToken);
	await signOut();
	const opaqueId = randomBytes(32).toString("base64url");
	const row = {
		pk: `SESSION#${createHash("sha256").update(opaqueId).digest("hex")}`,
		sk: "SESSION",
		accessToken,
		refreshToken,
		user,
		version: 1,
		accessExpiresAt: Date.now() + expiresIn * 1e3,
		expiresAt: Math.floor(Date.now() / 1e3) + lifetime
	};
	await db.send(new PutCommand({
		TableName: table,
		Item: row,
		ConditionExpression: "attribute_not_exists(pk)"
	}));
	setCookie$2(cookieName, opaqueId, {
		...cookieOptions,
		maxAge: lifetime
	});
	return publicSession(row);
}
async function currentSession() {
	const pk = sessionKey();
	if (!pk) return null;
	for (let attempt = 0; attempt < 40; attempt++) {
		const row = await getItem(pk, "SESSION");
		if (!row || row.expiresAt <= Math.floor(Date.now() / 1e3)) return null;
		if (row.accessExpiresAt > Date.now() + 6e4) return publicSession(row);
		if (row.lockUntil && row.lockUntil > Date.now()) {
			await new Promise((resolve) => setTimeout(resolve, 100));
			continue;
		}
		const lock = randomUUID();
		try {
			await db.send(new UpdateCommand({
				TableName: table,
				Key: {
					pk,
					sk: "SESSION"
				},
				UpdateExpression: "SET refreshLock = :lock, lockUntil = :until",
				ConditionExpression: "attribute_exists(pk) AND #version = :version AND expiresAt > :now AND (attribute_not_exists(lockUntil) OR lockUntil < :ms)",
				ExpressionAttributeNames: { "#version": "version" },
				ExpressionAttributeValues: {
					":lock": lock,
					":until": Date.now() + 15e3,
					":version": row.version,
					":now": Math.floor(Date.now() / 1e3),
					":ms": Date.now()
				}
			}));
		} catch (error) {
			if (conditionalFailure(error)) continue;
			throw error;
		}
		let rotatedToken;
		try {
			const tokens = (await cognito.send(new GetTokensFromRefreshTokenCommand({
				ClientId: clientId,
				RefreshToken: row.refreshToken
			}))).AuthenticationResult;
			if (!tokens?.AccessToken) throw new HttpError(401, "Your session expired. Sign in again.", "UNAUTHORIZED");
			rotatedToken = tokens.RefreshToken ?? row.refreshToken;
			const user = await getUser(tokens.AccessToken);
			if (user.id !== row.user.id) throw new HttpError(401, "Invalid session identity.", "UNAUTHORIZED");
			return publicSession((await db.send(new UpdateCommand({
				TableName: table,
				Key: {
					pk,
					sk: "SESSION"
				},
				UpdateExpression: "SET accessToken = :access, refreshToken = :refresh, accessExpiresAt = :expiry, #user = :user, #version = :next REMOVE refreshLock, lockUntil",
				ConditionExpression: "attribute_exists(pk) AND refreshLock = :lock AND #version = :version AND expiresAt > :now",
				ExpressionAttributeNames: {
					"#user": "user",
					"#version": "version"
				},
				ExpressionAttributeValues: {
					":access": tokens.AccessToken,
					":refresh": rotatedToken,
					":expiry": Date.now() + (tokens.ExpiresIn ?? 1800) * 1e3,
					":user": user,
					":next": row.version + 1,
					":version": row.version,
					":lock": lock,
					":now": Math.floor(Date.now() / 1e3)
				},
				ReturnValues: "ALL_NEW"
			}))).Attributes);
		} catch (error) {
			if (conditionalFailure(error)) {
				if (!await getItem(pk, "SESSION")) {
					if (rotatedToken) await revoke(rotatedToken);
					return null;
				}
				continue;
			}
			const invalid = error instanceof HttpError && error.status === 401 || error instanceof Error && [
				"NotAuthorizedException",
				"UserNotFoundException",
				"RefreshTokenReuseException"
			].includes(error.name);
			try {
				if (invalid) await db.send(new DeleteCommand({
					TableName: table,
					Key: {
						pk,
						sk: "SESSION"
					},
					ConditionExpression: "refreshLock = :lock",
					ExpressionAttributeValues: { ":lock": lock }
				}));
				else await db.send(new UpdateCommand({
					TableName: table,
					Key: {
						pk,
						sk: "SESSION"
					},
					UpdateExpression: "REMOVE refreshLock, lockUntil",
					ConditionExpression: "refreshLock = :lock",
					ExpressionAttributeValues: { ":lock": lock }
				}));
			} catch (releaseError) {
				if (!conditionalFailure(releaseError)) throw releaseError;
			}
			if (invalid) return null;
			throw error;
		}
	}
	throw new HttpError(503, "Session refresh is busy. Please try again shortly.", "SESSION_BUSY");
}
async function requireSession() {
	const session = await currentSession();
	if (!session) throw new HttpError(401, "Sign in to continue.", "UNAUTHORIZED");
	return session;
}
export { signOut as i, currentSession as n, requireSession as r, createSession as t };
