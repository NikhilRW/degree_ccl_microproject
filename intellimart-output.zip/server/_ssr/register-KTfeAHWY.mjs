import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as authService, E as useAuth } from "./router-Couj4mWN.mjs";
import { t as Input } from "./input-BbR4Ntsy.mjs";
import { t as Label } from "./label-Cvda4mU8.mjs";
// node_modules/.nitro/vite/services/ssr/assets/register-KTfeAHWY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RegisterPage() {
	const { signUp, signIn } = useAuth();
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const [code, setCode] = (0, import_react.useState)("");
	const submit = async (e) => {
		e.preventDefault();
		if (!confirming && !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{10,}$/.test(password)) {
			toast.error("Use at least 10 characters with uppercase, lowercase, a number and a symbol.");
			return;
		}
		setBusy(true);
		try {
			if (confirming) {
				await authService.confirmSignUp(email, code);
				await signIn(email, password);
				navigate({ to: "/account" });
			} else {
				await signUp(name, email, password);
				setConfirming(true);
				toast.success("Check your email for a verification code.");
			}
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Sign up failed");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-md flex-col px-4 py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: confirming ? "Verify your email" : "Create your account"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: confirming ? `Enter the verification code sent to ${email}.` : "Keep your orders, wishlist and favourite finds in one place."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-8 space-y-4 rounded-2xl border border-border bg-card p-6",
				children: [
					!confirming && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "name",
								children: "Full name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "name",
								value: name,
								onChange: (e) => setName(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "email",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "email",
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "password",
								children: "Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "password",
								type: "password",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								required: true,
								minLength: 10,
								autoComplete: "new-password"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "10+ characters, including uppercase, lowercase, a number and a symbol."
						})
					] }),
					confirming && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "confirmation-code",
							children: "Verification code"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "confirmation-code",
							value: code,
							onChange: (e) => setCode(e.target.value),
							autoComplete: "one-time-code",
							inputMode: "numeric",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "hero",
						className: "w-full",
						disabled: busy,
						children: busy ? "Please wait…" : confirming ? "Verify and sign in" : "Create account"
					}),
					confirming && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						className: "w-full",
						disabled: busy,
						onClick: () => {
							setBusy(true);
							authService.resendConfirmationCode(email).then(() => toast.success("A new code has been sent.")).catch((error) => toast.error(error instanceof Error ? error.message : "Could not resend the code.")).finally(() => setBusy(false));
						},
						children: "Resend code"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-sm text-muted-foreground",
						children: [
							"Already have an account?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "font-medium text-primary",
								children: "Sign in"
							})
						]
					})
				]
			})
		]
	});
}
export { RegisterPage as component };
