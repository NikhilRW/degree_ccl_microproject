import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as productService } from "./awsProductService-VU2HHCXI.mjs";
import { C as ArrowRight, S as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { S as currency, l as EmptyState, u as ErrorState } from "./router-Couj4mWN.mjs";
import { t as ProductGrid } from "./ProductGrid-34LfjVZO.mjs";
// node_modules/.nitro/vite/services/ssr/assets/routes-BuBnGJ4Z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var edits = [
	{
		id: "desk",
		label: "For your desk",
		description: "A better setup, one good find at a time.",
		categories: [
			"computing",
			"gaming",
			"accessories"
		]
	},
	{
		id: "move",
		label: "On the move",
		description: "A little company for the everyday journey.",
		categories: [
			"electronics",
			"smart",
			"accessories",
			"fashion"
		]
	},
	{
		id: "home",
		label: "At home",
		description: "Small upgrades for your favourite place.",
		categories: [
			"home",
			"smart",
			"books"
		]
	}
];
function HomePage() {
	const [products, setProducts] = (0, import_react.useState)([]);
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	const [editIndex, setEditIndex] = (0, import_react.useState)(0);
	const edit = edits[editIndex] ?? edits[0];
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		Promise.all([productService.list(), productService.getCategories()]).then(([items, departments]) => {
			if (!cancelled) {
				setProducts(items);
				setCategories(departments);
			}
		}).catch((e) => {
			if (!cancelled) setError(e instanceof Error ? e.message : "Could not load the collection");
		}).finally(() => {
			if (!cancelled) setLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const picks = products.filter((product) => edit.categories.includes(product.categoryId)).slice(0, 4);
	const spotlight = products.find((product) => product.featured) ?? products[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "retail-hero",
			"aria-labelledby": "storefront-title",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hero-picture",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/headphones-yellow.jpg",
					alt: "Black over-ear headphones on a sun-yellow background",
					width: 1600,
					height: 1067,
					fetchPriority: "high"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container hero-layout",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hero-copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							id: "storefront-title",
							children: [
								"For your",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								" everyday."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Electronics, desk essentials and good finds for the way you work, play and live." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ink",
							size: "xl",
							className: "hero-action",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/shop",
								children: ["Shop the collection ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { "aria-hidden": true })]
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hero-caption",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "A little less searching. A little more finding." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/shop",
						children: ["Explore the collection ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
							className: "h-4 w-4",
							"aria-hidden": true
						})]
					})]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "shop-section site-container",
			"aria-labelledby": "edit-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "edit-title",
						children: "A few good finds"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: edit.description })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						className: "text-link",
						children: "View the whole collection"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "edit-controls",
					role: "group",
					"aria-label": "Shop by your everyday routine",
					children: edits.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": editIndex === index,
						"aria-controls": "everyday-products",
						onClick: () => setEditIndex(index),
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "everyday-products",
					"aria-live": "polite",
					"aria-busy": loading,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, {
						products: picks,
						loading,
						error
					}, edit.id)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "departments shop-section",
			"aria-labelledby": "departments-title",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "departments-title",
						children: "Find your department"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "From a new setup to your next page-turner." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/categories",
						className: "text-link",
						children: "Explore departments"
					})]
				}), error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: error }) : !loading && !categories.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "Our collection is on its way",
					description: "Check back soon for new products and departments."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "department-list",
					children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/shop",
						search: { category: category.id },
						className: "department-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: category.image,
								alt: "",
								width: 88,
								height: 88,
								loading: "lazy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: category.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: category.description })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
								className: "h-5 w-5",
								strokeWidth: 1.5,
								"aria-hidden": true
							})
						]
					}, category.id))
				})]
			})
		}),
		spotlight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "shop-section site-container",
			"aria-labelledby": "audio-title",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "audio-feature",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "audio-picture",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: spotlight.images[0],
						alt: spotlight.name,
						width: 1600,
						height: 1067,
						loading: "lazy"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "audio-copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "audio-title",
							children: "Worth a closer look"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: spotlight.name }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "audio-facts",
							children: spotlight.highlights.slice(0, 2).map((highlight) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: highlight }) }, highlight))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "audio-price",
							children: [currency(spotlight.price), spotlight.originalPrice > spotlight.price && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("del", { children: currency(spotlight.originalPrice) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ink",
							size: "xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/product/$id",
								params: { id: spotlight.id },
								children: "Take a closer look"
							})
						})
					]
				})]
			})
		})
	] });
}
export { HomePage as component };
