import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { O as confirmSignUpFn, k as resendCodeFn, r as Route$1 } from "./router-Couj4mWN.mjs";
import { t as Input } from "./input-BbR4Ntsy.mjs";
import { t as Label } from "./label-Cvda4mU8.mjs";
// node_modules/.nitro/vite/services/ssr/assets/verify-email-DVxZIJzB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VerifyEmail() {
	const initial = Route$1.useSearch();
	const [email, setEmail] = (0, import_react.useState)(initial.email);
	const [code, setCode] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	const submit = async (event) => {
		event.preventDefault();
		setBusy(true);
		try {
			await confirmSignUpFn({ data: {
				email,
				code
			} });
			toast.success("Email verified. You can sign in.");
			navigate({ to: "/login" });
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Verification failed");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md px-4 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "Verify your email"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "mt-6 space-y-4 rounded-xl border border-border p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "verification-email",
					children: "Email"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "verification-email",
					type: "email",
					required: true,
					value: email,
					onChange: (event) => setEmail(event.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "verification-code",
					children: "Six-digit code"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "verification-code",
					inputMode: "numeric",
					pattern: "[0-9]{6}",
					required: true,
					value: code,
					onChange: (event) => setCode(event.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: "Verify"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					disabled: busy,
					onClick: () => {
						setBusy(true);
						resendCodeFn({ data: { email } }).then(() => toast.success("Verification code requested"), (error) => toast.error(error.message)).finally(() => setBusy(false));
					},
					children: "Resend code"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					className: "block text-sm text-primary",
					children: "Back to sign in"
				})
			]
		})]
	});
}
export { VerifyEmail as component };
