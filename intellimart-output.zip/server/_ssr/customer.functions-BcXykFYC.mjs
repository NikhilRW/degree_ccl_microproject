import { i as boolean, l as object } from "../_libs/zod.mjs";
import { C as fileSchema, E as orderSchema, L as uploadSchema, v as analyticsSchema, w as idSchema, y as cartChangeSchema } from "./ssr.mjs";
import { a as getServerFnById, f as createMiddleware, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./server-CiMkYVYO.mjs";
import { r as requireSession } from "./session.server-rd_-hBLH.mjs";
import { n as rpc } from "./rpc.server-DnC90LS4.mjs";
// node_modules/.nitro/vite/services/ssr/assets/customer.functions-BcXykFYC.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var customerMiddleware = createMiddleware({ type: "function" }).server(async ({ next }) => {
	return next({ context: { authentication: await rpc(requireSession) } });
});
var cartFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).handler(createSsrRpc("1f360aed66aea3ffe684bcd7092db8065f53a049ce239f7a3bf5a52bf7b6875c"));
var changeCartFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(cartChangeSchema).handler(createSsrRpc("9625c4fb4b12bab5c4b2df38549cb6fcd2267f4c436c072486f61a5dff458cb3"));
var wishlistFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).handler(createSsrRpc("61dae6f715aeb50de915695a0ce7d7b39de185cdc6d699da6b02ee9c2f02f20c"));
var changeWishlistFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(object({
	productId: idSchema,
	remove: boolean()
})).handler(createSsrRpc("233d1ebc6d23a66c924785670dde0239aae426187b8d26c429acaab534673df2"));
var ordersFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).handler(createSsrRpc("41016c64398d7f8cb5ec417d2c80867f8d046aaf1df87281cefbada7372153f9"));
var orderFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(idSchema).handler(createSsrRpc("d90e7c34afa3c3162a112ac20bf3c7c1c22c223075aa132bbd7e9d95320211a1"));
var createOrderFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(orderSchema).handler(createSsrRpc("a949326553dc18263601b6c6b0b3b86ba055b8674e5bd1aa7b0804e590d9d6c5"));
var cancelOrderFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(idSchema).handler(createSsrRpc("9a5d81c0a39cd5ca7ae15c83bf7d7d4a9dc119c2b14418448dc8a0082390ff2c"));
createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(uploadSchema).handler(createSsrRpc("2965128db8f0f47443f5031123e4e46832b14b857fed3571f118ce6f96336652"));
createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(fileSchema).handler(createSsrRpc("042a8eac2dd455caabb9367546696b3ab9c5cd04c9b5eb1a9b6ad2ce49bf827c"));
createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(analyticsSchema).handler(createSsrRpc("dfc6156fecdbb42dca037475ac390930343c2734fee36a127b2f7c99241787e9"));
export { createOrderFn as a, orderFn as c, changeWishlistFn as i, ordersFn as l, cartFn as n, createSsrRpc as o, changeCartFn as r, customerMiddleware as s, cancelOrderFn as t, wishlistFn as u };
