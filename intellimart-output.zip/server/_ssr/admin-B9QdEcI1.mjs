import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as productImageTypes, D as orderStatusSchema, I as updatePriceSchema, M as productUploadSchema, O as orderStatuses, _ as adminOrdersSchema, g as adminOrderStatusSchema, x as createProductSchema } from "./ssr.mjs";
import { r as createServerFn } from "./server-CiMkYVYO.mjs";
import { o as createSsrRpc } from "./customer.functions-BcXykFYC.mjs";
import { A as ServiceError, E as useAuth, M as isCurrentAuthGeneration, N as unwrap, S as currency, f as LoadingState, j as authGeneration, u as ErrorState, w as formatDate } from "./router-Couj4mWN.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-layOOVP4.mjs";
import { t as Input } from "./input-BbR4Ntsy.mjs";
import { t as Label } from "./label-Cvda4mU8.mjs";
import { t as Textarea } from "./textarea-CKL1fZto.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-IldXxGe8.mjs";
// node_modules/.nitro/vite/services/ssr/assets/admin-B9QdEcI1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var adminAccessFn = createServerFn({ method: "POST" }).handler(createSsrRpc("0dbfb6c04afd9f775feff16148bbecddf73e66fd4c5531d8a11f4a526fcc4daa"));
var adminProductsFn = createServerFn({ method: "POST" }).handler(createSsrRpc("375aad0f59e4678193d42aba4caa5dd0d2b5dbb7e59bb4bb1a9ec3a4923fdfe3"));
var adminUploadFn = createServerFn({ method: "POST" }).validator(productUploadSchema).handler(createSsrRpc("3dd07b1384833b2326f02d69359d8ee9fabd0cf64c982d4219a3d4e9a5cbfb82"));
var adminCreateProductFn = createServerFn({ method: "POST" }).validator(createProductSchema).handler(createSsrRpc("597b72d7fbb1489ac3a1b100e79f400a43eb2c47ecb3b4e28bdb7da9f7494a01"));
var adminUpdatePriceFn = createServerFn({ method: "POST" }).validator(updatePriceSchema).handler(createSsrRpc("5ec8c2c82c18c3799ecfde6330cb93d5a563e19331473b0360fbf2415acdf92a"));
var adminOrdersFn = createServerFn({ method: "POST" }).validator(adminOrdersSchema).handler(createSsrRpc("42d9c54e7d83fc2a96f0316cfa4b4c9a3e93618c2c475120afca32d684091b6f"));
var adminOrderStatusFn = createServerFn({ method: "POST" }).validator(adminOrderStatusSchema).handler(createSsrRpc("27b3460dc2631c782a9a3b328210fbf1a89b24dcb9f8ef448313e39f7e456422"));
var adminService = {
	access: () => unwrap(() => adminAccessFn()),
	list: () => unwrap(() => adminProductsFn()),
	listOrders: (data = {}) => unwrap(() => adminOrdersFn({ data })),
	updateOrderStatus: (data) => unwrap(() => adminOrderStatusFn({ data })),
	create: (data) => unwrap(() => adminCreateProductFn({ data })),
	updatePrice: (data) => unwrap(() => adminUpdatePriceFn({ data })),
	async uploadImage(file) {
		const generation = authGeneration();
		const data = productUploadSchema.parse({
			contentType: file.type,
			size: file.size
		});
		const policy = await unwrap(() => adminUploadFn({ data }));
		const form = new FormData();
		for (const [name, value] of Object.entries(policy.fields)) form.append(name, value);
		form.append("file", file);
		const response = await fetch(policy.url, {
			method: "POST",
			body: form,
			credentials: "omit"
		});
		if (!isCurrentAuthGeneration(generation)) throw new ServiceError("Your account changed during the upload.", 409, "AUTH_CHANGED");
		if (!response.ok) throw new Error(`Image upload failed (${response.status}). Select the image again to retry.`);
		return policy.key;
	}
};
var orderKey = (order) => `${order.ownerId}:${order.id}`;
var statusLabel = (status) => status[0].toUpperCase() + status.slice(1);
function uniqueOrders(orders) {
	return [...new Map(orders.map((order) => [orderKey(order), order])).values()];
}
function OrderStatusManager() {
	const [orders, setOrders] = (0, import_react.useState)([]);
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const [pages, setPages] = (0, import_react.useState)(1);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [loaded, setLoaded] = (0, import_react.useState)(false);
	const [updating, setUpdating] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [success, setSuccess] = (0, import_react.useState)("");
	const active = (0, import_react.useRef)(true);
	const request = (0, import_react.useRef)(0);
	const reload = (0, import_react.useCallback)(async (pageCount) => {
		const generation = authGeneration();
		const sequence = ++request.current;
		const current = () => active.current && sequence === request.current && isCurrentAuthGeneration(generation);
		setLoading(true);
		setError("");
		try {
			let next = null;
			const refreshed = [];
			let fetched = 0;
			do {
				const page = await adminService.listOrders(next ? { cursor: next } : {});
				if (!current()) return false;
				refreshed.push(...page.orders);
				next = page.nextCursor;
				fetched++;
			} while (next && fetched < pageCount);
			if (current()) {
				setOrders(uniqueOrders(refreshed));
				setCursor(next);
				setPages(fetched);
				setLoaded(true);
			}
			return true;
		} catch (error) {
			if (current()) setError(error instanceof Error ? error.message : "Could not load orders.");
			return false;
		} finally {
			if (current()) setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		active.current = true;
		reload(1);
		return () => {
			active.current = false;
			request.current++;
		};
	}, [reload]);
	const loadMore = async () => {
		if (!cursor || loading || updating) return;
		const generation = authGeneration();
		const sequence = ++request.current;
		const current = () => active.current && sequence === request.current && isCurrentAuthGeneration(generation);
		setLoading(true);
		setError("");
		try {
			const page = await adminService.listOrders({ cursor });
			if (current()) {
				setOrders((previous) => uniqueOrders([...previous, ...page.orders]));
				setCursor(page.nextCursor);
				setPages((previous) => previous + 1);
			}
		} catch (error) {
			if (current()) setError(error instanceof Error ? error.message : "Could not load more orders.");
		} finally {
			if (current()) setLoading(false);
		}
	};
	const update = async (order, status) => {
		if (loading || updating) return;
		const generation = authGeneration();
		const current = () => active.current && isCurrentAuthGeneration(generation);
		const data = adminOrderStatusSchema.parse({
			ownerId: order.ownerId,
			orderId: order.id,
			expectedStatus: order.status,
			status
		});
		setUpdating(orderKey(order));
		setError("");
		setSuccess("");
		try {
			const saved = await adminService.updateOrderStatus(data);
			if (!current()) return;
			setOrders((previous) => previous.map((item) => orderKey(item) === orderKey(saved) ? saved : item));
			setSuccess(`${saved.id} is now ${saved.status}.`);
			const refreshed = await reload(pages);
			if (current() && !refreshed) setError("The status was saved, but the order list could not be refreshed. Use Refresh orders to load the latest data.");
		} catch (error) {
			if (!current()) return;
			const message = error instanceof Error ? error.message : "Could not update the order status.";
			if (error instanceof ServiceError && error.status === 409) await reload(pages);
			if (current()) setError(message);
		} finally {
			if (current()) setUpdating(null);
		}
	};
	const busy = loading || updating !== null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		"aria-labelledby": "admin-orders",
		"aria-busy": busy,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "admin-orders",
					className: "text-lg font-semibold",
					children: "Orders"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Change processing, shipped, delivered or cancelled status. Mark delivered only after receipt is confirmed. Payment status is not changed."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: busy,
					onClick: () => {
						setSuccess("");
						reload(pages);
					},
					children: loading && loaded ? "Refreshing…" : "Refresh orders"
				})]
			}),
			success && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "mt-4 text-sm",
				children: success
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-destructive",
					children: error
				}), !loaded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					variant: "outline",
					disabled: busy,
					onClick: () => void reload(1),
					children: "Try again"
				})]
			}),
			!loaded && loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading orders" }) : loaded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					role: "status",
					className: "mt-5 text-sm text-muted-foreground",
					children: [
						"Showing ",
						orders.length,
						" order",
						orders.length === 1 ? "" : "s",
						cursor ? " · More orders available" : " · All orders loaded",
						". Newly placed orders may take a moment to appear in the index."
					]
				}),
				!orders.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 bg-surface p-6 text-sm",
					children: "No orders yet."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-4",
					children: orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderStatusRow, {
						order,
						disabled: busy,
						saving: updating === orderKey(order),
						onSave: (status) => void update(order, status)
					}, `${orderKey(order)}:${order.status}`))
				}),
				cursor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: busy,
						onClick: () => void loadMore(),
						children: loading ? "Loading…" : "Load more orders"
					})
				})
			] })
		]
	});
}
function OrderStatusRow({ order, disabled, saving, onSave }) {
	const [status, setStatus] = (0, import_react.useState)(order.status);
	const controlId = `order-status-${order.ownerId}-${order.id}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "bg-surface p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "break-all text-sm font-semibold",
						children: order.id
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm",
						children: [
							order.customerName,
							" · ",
							formatDate(order.createdAt)
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base font-medium tabular-nums",
						children: currency(order.total)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: statusLabel(order.status)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-2 text-sm",
				children: order.items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						item.quantity,
						" × ",
						item.name
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "shrink-0 text-right tabular-nums",
						children: [currency(item.price), " each"]
					})]
				}, `${item.productId}:${index}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 flex flex-wrap items-end gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					onSave(status);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full space-y-2 sm:w-56",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: controlId,
						children: "Order status"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: status,
						disabled,
						onValueChange: (value) => setStatus(orderStatusSchema.parse(value)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							id: controlId,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: orderStatuses.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value,
							children: statusLabel(value)
						}, value)) })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "outline",
					disabled: disabled || status === order.status,
					children: saving ? "Saving…" : "Save status"
				})]
			}),
			status !== order.status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: status === "cancelled" ? "Cancelling restores all ordered quantities to stock once." : order.status === "cancelled" ? "Reopening reserves the ordered quantities again. The change is refused if any product has insufficient stock." : "Only order status changes; stock, historical prices and payment status stay the same."
			})
		]
	});
}
function AdminPage() {
	const { user, loading: authLoading } = useAuth();
	const navigate = useNavigate();
	const [loaded, setLoaded] = (0, import_react.useState)(null);
	const [failure, setFailure] = (0, import_react.useState)(null);
	const [retry, setRetry] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!authLoading && !user) navigate({
			to: "/login",
			search: { redirect: "/admin" },
			replace: true
		});
	}, [
		authLoading,
		user,
		navigate
	]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setLoaded(null);
		setFailure(null);
		if (!user || authLoading) return;
		const userId = user.id;
		adminService.access().then(() => adminService.list()).then((data) => {
			if (!cancelled) setLoaded({
				userId,
				...data
			});
		}).catch((error) => {
			if (!cancelled) setFailure({
				userId,
				message: error instanceof Error ? error.message : "Could not load products.",
				denied: error instanceof ServiceError && error.status === 403
			});
		});
		return () => {
			cancelled = true;
		};
	}, [
		user?.id,
		authLoading,
		retry
	]);
	if (authLoading || !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Checking sign-in" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container py-10 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Admin"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "IntelliMart · Manage products, prices and order status."
			}),
			failure?.userId === user.id ? failure.denied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 bg-surface p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Access denied"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: failure.message
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/account",
							children: "Your account"
						})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
					message: failure.message,
					onRetry: () => setRetry((value) => value + 1)
				})
			}) : loaded?.userId === user.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "products",
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "products",
						children: "Products"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "orders",
						children: "Orders"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "products",
						forceMount: true,
						className: "data-[state=inactive]:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductWorkspace, {
							initialProducts: loaded.products,
							categories: loaded.categories
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "orders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderStatusManager, {})
					})
				]
			}, user.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Checking administrator access" })
		]
	});
}
function ProductWorkspace({ initialProducts, categories }) {
	const [products, setProducts] = (0, import_react.useState)(initialProducts);
	const [search, setSearch] = (0, import_react.useState)("");
	const [categoryId, setCategoryId] = (0, import_react.useState)("");
	const [images, setImages] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [success, setSuccess] = (0, import_react.useState)("");
	const fileInput = (0, import_react.useRef)(null);
	const alive = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		alive.current = true;
		return () => {
			alive.current = false;
		};
	}, []);
	const upload = async (files) => {
		const generation = authGeneration();
		setError(null);
		setSuccess("");
		setImages([]);
		if (!files.length) {
			setProgress("");
			return;
		}
		if (files.length > 6 || files.some((file) => !productImageTypes.some((type) => type === file.type) || file.size < 1 || file.size > 5242880)) {
			setError("Choose 1–6 JPEG, PNG, WebP or AVIF images, each no larger than 5 MiB.");
			setProgress("");
			return;
		}
		setUploading(true);
		const uploaded = [];
		try {
			for (const [index, file] of files.entries()) {
				if (!alive.current || !isCurrentAuthGeneration(generation)) return;
				setProgress(`Uploading image ${index + 1} of ${files.length}…`);
				const key = await adminService.uploadImage(file);
				uploaded.push({
					key,
					name: file.name
				});
			}
			if (alive.current && isCurrentAuthGeneration(generation)) {
				setImages(uploaded);
				setProgress(`${uploaded.length} image${uploaded.length === 1 ? "" : "s"} uploaded.`);
			}
		} catch (error) {
			if (alive.current && isCurrentAuthGeneration(generation)) {
				setError(error instanceof Error ? error.message : "Image upload failed.");
				setProgress("Upload incomplete. Select the images again to retry.");
			}
		} finally {
			if (alive.current && isCurrentAuthGeneration(generation)) setUploading(false);
		}
	};
	const create = async (event) => {
		event.preventDefault();
		const form = event.currentTarget;
		const fields = new FormData(form);
		const parsed = createProductSchema.safeParse({
			name: fields.get("name"),
			categoryId,
			description: fields.get("description"),
			price: Number(fields.get("price")),
			originalPrice: fields.get("originalPrice") ? Number(fields.get("originalPrice")) : void 0,
			stock: Number(fields.get("stock")),
			images: images.map((image) => image.key)
		});
		setError(null);
		setSuccess("");
		if (!parsed.success) {
			setError(parsed.error.issues.map((issue) => issue.message).join(" "));
			return;
		}
		const generation = authGeneration();
		setBusy(true);
		try {
			const product = await adminService.create(parsed.data);
			if (alive.current && isCurrentAuthGeneration(generation)) {
				setProducts((current) => [product, ...current]);
				form.reset();
				setCategoryId("");
				setImages([]);
				setProgress("");
				setSuccess(`${product.name} was added to the shop.`);
			}
		} catch (error) {
			if (alive.current && isCurrentAuthGeneration(generation)) setError(error instanceof Error ? error.message : "Could not add the product.");
		} finally {
			if (alive.current && isCurrentAuthGeneration(generation)) setBusy(false);
		}
	};
	const shown = products.filter((product) => `${product.name} ${product.category}`.toLowerCase().includes(search.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 grid items-start gap-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0 bg-surface p-5 sm:p-6",
			"aria-labelledby": "add-product",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "add-product",
					className: "text-lg font-semibold",
					children: "Add product"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Prices are in whole Indian rupees. Stock is the quantity available to order."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => void create(event),
					className: "mt-6 space-y-4",
					"aria-busy": busy || uploading,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							disabled: busy || uploading,
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "product-name",
										children: "Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "product-name",
										name: "name",
										required: true,
										maxLength: 200
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "product-category",
										children: "Category"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: categoryId,
										onValueChange: setCategoryId,
										required: true,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											id: "product-category",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a category" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: category.id,
											children: category.name
										}, category.id)) })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "product-description",
										children: "Description"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "product-description",
										name: "description",
										required: true,
										maxLength: 5e3,
										rows: 4
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "product-price",
											children: "Selling price (₹)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "product-price",
											name: "price",
											type: "number",
											min: 1,
											max: 1e8,
											step: 1,
											required: true
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "product-list-price",
											children: "List price (₹, optional)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "product-list-price",
											name: "originalPrice",
											type: "number",
											min: 1,
											max: 1e8,
											step: 1
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "product-stock",
										children: "Stock quantity"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "product-stock",
										name: "stock",
										type: "number",
										min: 0,
										max: 1e6,
										step: 1,
										required: true
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "product-images",
									children: "Product images"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									ref: fileInput,
									id: "product-images",
									type: "file",
									multiple: true,
									accept: productImageTypes.join(","),
									disabled: busy || uploading,
									onChange: (event) => void upload(Array.from(event.target.files ?? [])),
									"aria-describedby": "image-help image-progress"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									id: "image-help",
									className: "text-sm text-muted-foreground",
									children: "1–6 images · JPEG, PNG, WebP or AVIF · Up to 5 MiB each. Uploads can be used for one product within an hour."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									id: "image-progress",
									role: "status",
									className: "text-sm",
									children: progress
								}),
								!!images.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-1 text-sm",
									children: images.map((image) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "break-words",
										children: image.name
									}, image.key))
								})
							]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "text-sm text-destructive",
							children: error
						}),
						success && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "status",
							className: "text-sm",
							children: success
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy || uploading || !images.length || !categories.length,
							children: busy ? "Adding product…" : "Add product"
						}),
						!categories.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: "No existing categories are available. Ask the catalogue operator to configure them."
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			"aria-labelledby": "product-prices",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "product-prices",
					className: "text-lg font-semibold",
					children: "Product prices"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Price changes do not change stock, reviews or past orders."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "price-search",
						children: "Find a product"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "price-search",
						type: "search",
						value: search,
						onChange: (event) => setSearch(event.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: [
						shown.length,
						" of ",
						products.length,
						" products"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-4",
					children: shown.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceEditor, {
						product,
						onSaved: (prices) => setProducts((current) => current.map((item) => item.id === prices.productId ? {
							...item,
							...prices
						} : item))
					}, product.id))
				}),
				!shown.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 bg-surface p-6 text-sm",
					children: products.length ? "No products match your search." : "No products yet. Add the first product using the form."
				})
			]
		})]
	});
}
function PriceEditor({ product, onSaved }) {
	const [price, setPrice] = (0, import_react.useState)(String(product.price));
	const [original, setOriginal] = (0, import_react.useState)(String(product.originalPrice));
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)(false);
	const changed = Number(price) !== product.price || Number(original) !== product.originalPrice;
	const save = async (event) => {
		event.preventDefault();
		setError("");
		setSaved(false);
		const parsed = updatePriceSchema.safeParse({
			productId: product.id,
			price: Number(price),
			originalPrice: Number(original),
			expectedPrice: product.price,
			expectedOriginalPrice: product.originalPrice
		});
		if (!parsed.success) {
			setError(parsed.error.issues.map((issue) => issue.message).join(" "));
			return;
		}
		const generation = authGeneration();
		setBusy(true);
		try {
			const result = await adminService.updatePrice(parsed.data);
			if (isCurrentAuthGeneration(generation)) {
				setSaved(true);
				onSaved(result);
			}
		} catch (error) {
			if (isCurrentAuthGeneration(generation)) setError(error instanceof ServiceError && error.status === 409 ? "This price changed elsewhere. Reload the page before editing it again." : error instanceof Error ? error.message : "Could not save the price.");
		} finally {
			if (isCurrentAuthGeneration(generation)) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => void save(event),
		className: "bg-surface p-5",
		"aria-busy": busy,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: product.images[0],
					alt: "",
					className: "h-12 w-12 object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold",
						children: product.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							product.category,
							" · Current ",
							currency(product.price)
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: `price-${product.id}`,
						children: "Selling price (₹)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: `price-${product.id}`,
						type: "number",
						min: 1,
						max: 1e8,
						step: 1,
						required: true,
						value: price,
						disabled: busy,
						className: "text-right tabular-nums",
						onChange: (event) => setPrice(event.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: `list-${product.id}`,
						children: "List price (₹)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: `list-${product.id}`,
						type: "number",
						min: 1,
						max: 1e8,
						step: 1,
						required: true,
						value: original,
						disabled: busy,
						className: "text-right tabular-nums",
						onChange: (event) => setOriginal(event.target.value)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground",
					role: "status",
					children: changed ? "Unsaved price changes" : saved ? "Saved" : "No changes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "outline",
					disabled: busy || !changed,
					children: busy ? "Saving…" : "Save prices"
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-3 text-sm text-destructive",
				children: error
			})
		]
	});
}
export { AdminPage as component };
