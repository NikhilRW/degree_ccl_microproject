import { l as TransactionCanceledException } from "../_libs/@aws-sdk/client-dynamodb+[...].mjs";
import { r as TransactWriteCommand } from "../_libs/@aws-sdk/lib-dynamodb+[...].mjs";
import { P as reviewSchema, a as getItem, d as queryItems, i as db, m as HttpError, p as table, u as product, w as idSchema } from "./ssr.mjs";
import { r as createServerFn } from "./server-CiMkYVYO.mjs";
import { t as authenticated } from "./rpc.server-DnC90LS4.mjs";
import { s as customerMiddleware } from "./customer.functions-BcXykFYC.mjs";
import { t as createServerRpc } from "./createServerRpc-F9KTd2Fz.mjs";
import { randomUUID } from "node:crypto";
// node_modules/.nitro/vite/services/ssr/assets/reviews.functions-BGGS1KJP.js
var reviewKey = (user, productId) => ({
	pk: `PRODUCT#${productId}`,
	sk: `REVIEW#USER#${user.id}`
});
async function ownReview(user, productId) {
	const key = reviewKey(user, productId);
	return (await getItem(key.pk, key.sk))?.data ?? null;
}
async function deliveredPurchase(user, productId) {
	return (await queryItems(`USER#${user.id}`, "ORDER#")).find((order) => order.entity === "order" && order.data.userId === user.id && order.data.status === "delivered" && order.data.items.some((item) => item.productId === productId && item.quantity > 0));
}
async function eligibility(user, productId) {
	await product(productId);
	const review = await ownReview(user, productId);
	if (review) return {
		canReview: false,
		reason: "You have already reviewed this product.",
		review
	};
	const order = await deliveredPurchase(user, productId);
	return {
		canReview: !!order,
		reason: order ? "Your delivered purchase is eligible for a review." : "Reviews open after an order for this product is recorded as delivered. An estimated delivery date does not confirm receipt.",
		review: null
	};
}
async function submitReview(user, input) {
	const key = reviewKey(user, input.productId);
	const review = {
		id: randomUUID(),
		productId: input.productId,
		author: user.name,
		rating: input.rating,
		title: input.title,
		body: input.body,
		verifiedPurchase: true,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	for (let attempt = 0; attempt < 4; attempt++) {
		if (await ownReview(user, input.productId)) throw new HttpError(409, "You have already reviewed this product.", "ALREADY_REVIEWED");
		const order = await deliveredPurchase(user, input.productId);
		if (!order) throw new HttpError(403, "Only your own delivered purchase can be reviewed.", "DELIVERED_PURCHASE_REQUIRED");
		const itemIndex = order.data.items.findIndex((item) => item.productId === input.productId && item.quantity > 0);
		const entry = await getItem("CATALOG", `PRODUCT#${input.productId}`);
		if (!entry) throw new HttpError(404, "Product not found.");
		const p = entry.data;
		const total = (entry.ratingTotal ?? Math.round(p.rating * p.reviewCount * 1e6) / 1e6) + input.rating;
		const count = p.reviewCount + 1;
		try {
			await db.send(new TransactWriteCommand({ TransactItems: [
				{ ConditionCheck: {
					TableName: table,
					Key: {
						pk: `USER#${user.id}`,
						sk: order.sk
					},
					ConditionExpression: `#entity = :entity AND #data.#user = :user AND #data.#status = :delivered AND #data.#items[${itemIndex}].#product = :product AND #data.#items[${itemIndex}].#quantity > :zero`,
					ExpressionAttributeNames: {
						"#entity": "entity",
						"#data": "data",
						"#user": "userId",
						"#status": "status",
						"#items": "items",
						"#product": "productId",
						"#quantity": "quantity"
					},
					ExpressionAttributeValues: {
						":entity": "order",
						":user": user.id,
						":delivered": "delivered",
						":product": input.productId,
						":zero": 0
					}
				} },
				{ Put: {
					TableName: table,
					Item: {
						...key,
						userId: user.id,
						data: review
					},
					ConditionExpression: "attribute_not_exists(pk)"
				} },
				{ Update: {
					TableName: table,
					Key: {
						pk: "CATALOG",
						sk: `PRODUCT#${input.productId}`
					},
					UpdateExpression: "SET #data.#rating = :rating, #data.#count = :count, ratingTotal = :total",
					ConditionExpression: `attribute_exists(pk) AND #data.#rating = :oldRating AND #data.#count = :oldCount AND ${entry.ratingTotal === void 0 ? "attribute_not_exists(ratingTotal)" : "ratingTotal = :oldTotal"}`,
					ExpressionAttributeNames: {
						"#data": "data",
						"#rating": "rating",
						"#count": "reviewCount"
					},
					ExpressionAttributeValues: {
						":rating": Number((total / count).toFixed(6)),
						":count": count,
						":total": total,
						":oldRating": p.rating,
						":oldCount": p.reviewCount,
						...entry.ratingTotal === void 0 ? {} : { ":oldTotal": entry.ratingTotal }
					}
				} }
			] }));
			return {
				review,
				rating: Number((total / count).toFixed(6)),
				reviewCount: count
			};
		} catch (error) {
			if (!(error instanceof TransactionCanceledException)) throw error;
			const reasons = error.CancellationReasons;
			if (reasons?.[1]?.Code === "ConditionalCheckFailed") throw new HttpError(409, "You have already reviewed this product.", "ALREADY_REVIEWED");
			if (reasons?.[2]?.Code !== "ConditionalCheckFailed" && !reasons?.some((reason) => reason.Code === "TransactionConflict")) throw error;
			if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, 30 * (attempt + 1)));
		}
	}
	throw new HttpError(409, "Reviews changed while saving. Please try again.", "REVIEW_CONFLICT");
}
var reviewEligibilityFn_createServerFn_handler = createServerRpc({
	id: "0813518870d3af07768222d322fcdc31956f17f836e9007896dd8b05ea87f553",
	name: "reviewEligibilityFn",
	filename: "src/functions/reviews.functions.ts"
}, (opts) => reviewEligibilityFn.__executeServer(opts));
var reviewEligibilityFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(idSchema).handler(reviewEligibilityFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => eligibility(user, data)));
var submitReviewFn_createServerFn_handler = createServerRpc({
	id: "b71b19576944faac5f2f200f9265ef79c28afd5175bb6fee59b5b305655677db",
	name: "submitReviewFn",
	filename: "src/functions/reviews.functions.ts"
}, (opts) => submitReviewFn.__executeServer(opts));
var submitReviewFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(reviewSchema).handler(submitReviewFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => submitReview(user, data)));
export { reviewEligibilityFn_createServerFn_handler, submitReviewFn_createServerFn_handler };
