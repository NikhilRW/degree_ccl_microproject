import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as productService } from "./awsProductService-VU2HHCXI.mjs";
import { S as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { f as LoadingState, l as EmptyState, u as ErrorState } from "./router-Couj4mWN.mjs";
// node_modules/.nitro/vite/services/ssr/assets/categories-pJ8kW1wX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CategoryCard({ category }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/shop",
		search: { category: category.id },
		className: "category-tile group block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "aspect-[4/3] overflow-clip bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: category.image,
				alt: category.name,
				loading: "lazy",
				width: 800,
				height: 600,
				className: "h-full w-full object-cover"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-4 py-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xl font-medium",
				children: category.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[14px]",
				children: category.description
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
				className: "mt-1 h-5 w-5 shrink-0 transition-smooth group-hover:-translate-y-1 group-hover:translate-x-1",
				strokeWidth: 1.5,
				"aria-hidden": true
			})]
		})]
	});
}
function CategoriesPage() {
	const [categories, setCategories] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		productService.getCategories().then(setCategories).catch((error) => {
			setError(error instanceof Error ? error.message : "Could not load departments.");
			setCategories([]);
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container pb-24 pt-10 sm:pt-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl font-medium sm:text-7xl",
				children: "Departments"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-xl text-base",
				children: "Find your next good thing. Start with what you love."
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: error })
			}) : !categories ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading categories" }) : !categories.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No departments yet",
					description: "Our collection will be available here soon."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4",
				children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryCard, { category: c }, c.id))
			})
		]
	});
}
export { CategoriesPage as component };
