import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { g as Link, l as useLocation } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as productService } from "./awsProductService-VU2HHCXI.mjs";
import { t as orderService } from "./awsOrderService-gOrj1Wb6.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as useAuth, S as currency, f as LoadingState, l as EmptyState, p as useWishlist, u as ErrorState, w as formatDate } from "./router-Couj4mWN.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-layOOVP4.mjs";
// node_modules/.nitro/vite/services/ssr/assets/account-CE96UowY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AccountPage() {
	const { hash } = useLocation();
	const [tab, setTab] = (0, import_react.useState)(hash === "wishlist" ? "wishlist" : "orders");
	const { user, loading: authLoading, signOut } = useAuth();
	const { items: wishlist, remove } = useWishlist();
	const [orders, setOrders] = (0, import_react.useState)([]);
	const [wishlistProducts, setWishlistProducts] = (0, import_react.useState)([]);
	const [ordersLoading, setOrdersLoading] = (0, import_react.useState)(false);
	const [wishlistLoading, setWishlistLoading] = (0, import_react.useState)(false);
	const [ordersError, setOrdersError] = (0, import_react.useState)(null);
	const [wishlistError, setWishlistError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setTab(hash === "wishlist" ? "wishlist" : "orders");
	}, [hash]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setOrders([]);
		setOrdersError(null);
		if (!user) return;
		setOrdersLoading(true);
		orderService.list().then((value) => {
			if (!cancelled) setOrders(value);
		}).catch((error) => {
			if (!cancelled) setOrdersError(error instanceof Error ? error.message : "Could not load your orders.");
		}).finally(() => {
			if (!cancelled) setOrdersLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, [user?.id]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setWishlistProducts([]);
		setWishlistError(null);
		setWishlistLoading(false);
		if (!user || !wishlist.length) return;
		setWishlistLoading(true);
		Promise.all(wishlist.map((item) => productService.getById(item.productId))).then((items) => {
			if (!cancelled) setWishlistProducts(items.filter((item) => item !== null));
		}).catch((error) => {
			if (!cancelled) setWishlistError(error instanceof Error ? error.message : "Could not load your wishlist.");
		}).finally(() => {
			if (!cancelled) setWishlistLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, [
		wishlist,
		user?.id,
		user
	]);
	if (authLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading your account" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-3xl px-4 py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "You're signed out",
			description: "Sign in to view your profile, orders and wishlist.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "hero",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					children: "Sign in"
				})
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container pb-24 pt-10 sm:pt-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "font-display text-4xl font-medium sm:text-6xl",
				children: ["Hi, ", user.name.split(" ")[0]]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: user.email
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void signOut(),
				children: "Sign out"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			value: tab,
			onValueChange: setTab,
			className: "mt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "orders",
						children: "Orders"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "wishlist",
						children: "Wishlist"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "profile",
						children: "Profile"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "orders",
					id: "orders",
					className: "mt-6 space-y-4",
					children: ordersLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading orders" }) : ordersError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: ordersError }) : orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No orders yet",
						description: "Your completed orders will appear here.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								children: "Start shopping"
							})
						})
					}) : orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "bg-surface p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-semibold",
									children: o.id
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"Placed ",
										formatDate(o.createdAt),
										" · ",
										o.status
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-semibold tabular-nums",
									children: currency(o.totals.total)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 flex flex-wrap gap-3",
								children: o.items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2 rounded-xl border border-border p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: i.image,
										alt: "",
										className: "h-10 w-10 rounded-lg object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs",
										children: [
											i.name,
											" × ",
											i.quantity
										]
									})]
								}, i.productId))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-3",
								children: [
									["pending", "processing"].includes(o.status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											if (window.confirm(`Cancel ${o.id}?`)) orderService.cancel(o.id).then((value) => setOrders((current) => current.map((item) => item.id === value.id ? value : item)), (error) => toast.error(error.message));
										},
										children: "Cancel order"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: ["Payment: ", o.payment.method === "cod" ? "Cash on delivery" : o.payment.status === "mocked" ? "Mock-approved · no money charged" : o.payment.status]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "sm",
										variant: "ghost",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/order-confirmation",
											search: { id: o.id },
											children: "Order details"
										})
									})
								]
							})
						]
					}, o.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "wishlist",
					className: "mt-6",
					children: wishlistLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading wishlist" }) : wishlistError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: wishlistError }) : wishlistProducts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "Your wishlist is empty",
						description: "Tap the heart on any product to save it.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								children: "Browse products"
							})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-4 sm:grid-cols-2",
						children: wishlistProducts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-4 bg-surface p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: p.images[0],
									alt: "",
									className: "h-16 w-16 rounded-xl object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/product/$id",
										params: { id: p.id },
										className: "text-sm font-semibold hover:underline",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted-foreground tabular-nums",
										children: currency(p.price)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => remove(p.id),
									children: "Remove"
								})
							]
						}, p.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "profile",
					className: "mt-6 space-y-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid gap-5 bg-surface p-6 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-muted-foreground",
							children: "Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-2 text-base",
							children: user.name
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-muted-foreground",
							children: "Email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-2 text-base",
							children: user.email
						})] })]
					})
				})
			]
		})]
	});
}
export { AccountPage as component };
