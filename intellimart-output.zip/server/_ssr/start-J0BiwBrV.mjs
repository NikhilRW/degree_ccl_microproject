import { R as renderErrorPage } from "./ssr.mjs";
import { c as getRequest, f as createMiddleware, n as createCsrfMiddleware, u as setResponseHeader } from "./server-CiMkYVYO.mjs";
import { t as getRuntimeConfig } from "./runtime.server-Ct22IyCc.mjs";
// node_modules/.nitro/vite/services/ssr/assets/start-J0BiwBrV.js
function dedupeSerializationAdapters(deduped, serializationAdapters) {
	for (let i = 0, len = serializationAdapters.length; i < len; i++) {
		const current = serializationAdapters[i];
		if (!deduped.has(current)) {
			deduped.add(current);
			if (current.extends) dedupeSerializationAdapters(deduped, current.extends);
		}
	}
}
var createStart = (getOptions) => {
	return {
		getOptions: async () => {
			const options = await getOptions();
			if (options.serializationAdapters) {
				const deduped = /* @__PURE__ */ new Set();
				dedupeSerializationAdapters(deduped, options.serializationAdapters);
				options.serializationAdapters = Array.from(deduped);
			}
			return options;
		},
		createMiddleware
	};
};
var errorMiddleware = createMiddleware().server(async ({ next }) => {
	setResponseHeader("Cache-Control", "no-store");
	setResponseHeader("X-Content-Type-Options", "nosniff");
	setResponseHeader("Referrer-Policy", "strict-origin-when-cross-origin");
	const request = getRequest();
	if (![
		"GET",
		"HEAD",
		"OPTIONS"
	].includes(request.method) && !new URL(request.url).pathname.startsWith("/webhooks/")) {
		const origin = request.headers.get("origin");
		const config = getRuntimeConfig();
		if (config.mode === "cloud" && origin !== config.appUrl) return new Response("Invalid request origin", { status: 403 });
	}
	try {
		return await next();
	} catch (error) {
		if (error != null && typeof error === "object" && "statusCode" in error) throw error;
		console.error(JSON.stringify({
			event: "request.failed",
			code: error instanceof Error ? error.name : "unknown"
		}));
		return new Response(renderErrorPage(), {
			status: 500,
			headers: { "content-type": "text/html; charset=utf-8" }
		});
	}
});
var matchTrustedOrigin = (origin, ctx) => {
	const config = getRuntimeConfig();
	return origin === (config.mode === "cloud" ? config.appUrl : new URL(ctx.request.url).origin);
};
var csrfMiddleware = createCsrfMiddleware({
	filter: (ctx) => ctx.handlerType === "serverFn",
	origin: (origin, ctx) => matchTrustedOrigin(origin, ctx) === true
});
var startInstance = createStart(() => ({ requestMiddleware: [errorMiddleware, csrfMiddleware] }));
export { startInstance };
