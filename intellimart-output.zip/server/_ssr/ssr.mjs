import { r as __exportAll } from "../_runtime.mjs";
import { a as GetUserCommand, d as CognitoIdentityProviderClient } from "../_libs/@aws-sdk/client-cognito-identity-provider+[...].mjs";
import { a as S3Client, r as GetObjectCommand } from "../_libs/@aws-sdk/client-s3+[...].mjs";
import { c as DynamoDBClient } from "../_libs/@aws-sdk/client-dynamodb+[...].mjs";
import { i as QueryCommand, o as GetCommand, t as DynamoDBDocumentClient } from "../_libs/@aws-sdk/lib-dynamodb+[...].mjs";
import { t as getSignedUrl } from "../_libs/aws-sdk__s3-request-presigner.mjs";
import { a as discriminatedUnion, c as number, d as string, f as union, i as boolean, l as object, n as _null, o as email$1, p as uuid, r as array, s as literal, t as _enum, u as record } from "../_libs/zod.mjs";
// node_modules/.nitro/vite/services/ssr/index.js
var ssr_exports = /* @__PURE__ */ __exportAll({
	A: () => productImageTypes,
	C: () => fileSchema,
	D: () => orderStatusSchema,
	E: () => orderSchema,
	F: () => signupSchema,
	I: () => updatePriceSchema,
	L: () => uploadSchema,
	M: () => productUploadSchema,
	N: () => resetSchema,
	O: () => orderStatuses,
	P: () => reviewSchema,
	R: () => renderErrorPage,
	S: () => emailSchema,
	T: () => loginSchema,
	_: () => adminOrdersSchema,
	a: () => getItem,
	b: () => confirmationSchema,
	c: () => imageUrl,
	d: () => queryItems,
	default: () => server_default,
	f: () => s3,
	g: () => adminOrderStatusSchema,
	h: () => adminOrderCursorSchema,
	i: () => db,
	j: () => productQuerySchema,
	k: () => productImageMaxBytes,
	l: () => presentProduct,
	m: () => HttpError,
	n: () => clientId,
	o: () => getUser,
	p: () => table,
	r: () => cognito,
	s: () => id,
	t: () => bucket,
	u: () => product,
	v: () => analyticsSchema,
	w: () => idSchema,
	x: () => createProductSchema,
	y: () => cartChangeSchema
});
function renderErrorPage() {
	return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body { font: 15px/1.5 system-ui, -apple-system, sans-serif; background: #fafafa; color: #111; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 28rem; width: 100%; text-align: center; padding: 2rem; }
      h1 { font-size: 1.25rem; margin: 0 0 0.5rem; }
      p { color: #4b5563; margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.5rem 1rem; border-radius: 0.375rem; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: #111; color: #fff; }
      .secondary { background: #fff; color: #111; border-color: #d1d5db; }
    </style>
  </head>
  <body>
    <div class="card">
      <h1>This page didn't load</h1>
      <p>Something went wrong on our end. You can try refreshing or head back home.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Go home</a>
      </div>
    </div>
  </body>
</html>`;
}
var HttpError = class extends Error {
	status;
	code;
	constructor(status, message, code = "REQUEST_FAILED") {
		super(message);
		this.status = status;
		this.code = code;
	}
};
var idSchema = string().regex(/^[a-zA-Z0-9_-]{1,100}$/);
var email = email$1().max(254);
var password = string().min(10).max(256);
var code = string().min(4).max(12);
var loginSchema = object({
	email,
	password: string().min(1).max(256)
});
var signupSchema = object({
	name: string().trim().min(1).max(100),
	email,
	password
});
var emailSchema = object({ email });
var confirmationSchema = object({
	email,
	code
});
var resetSchema = object({
	email,
	code,
	password
});
var productQuerySchema = object({
	search: string().max(200).optional(),
	categories: array(idSchema).max(100).optional(),
	minPrice: number().finite().nonnegative().optional(),
	maxPrice: number().finite().nonnegative().optional(),
	minRating: number().min(0).max(5).optional(),
	sort: _enum([
		"featured",
		"price-asc",
		"price-desc",
		"rating",
		"newest"
	]).optional(),
	featured: boolean().optional(),
	limit: number().int().min(1).max(100).optional()
});
var cartChangeSchema = discriminatedUnion("action", [
	object({
		action: literal("add"),
		productId: idSchema,
		quantity: number().int().min(1).max(99)
	}),
	object({
		action: literal("quantity"),
		productId: idSchema,
		quantity: number().int().min(0).max(99)
	}),
	object({
		action: literal("remove"),
		productId: idSchema
	}),
	object({
		action: literal("saved"),
		productId: idSchema
	}),
	object({ action: literal("clear") })
]);
var orderSchema = object({
	address: object({
		fullName: string().trim().min(1).max(100),
		phone: string().trim().min(7).max(25),
		address: string().trim().min(1).max(300),
		apartment: string().max(200).optional(),
		city: string().trim().min(1).max(100),
		state: string().trim().min(1).max(100),
		postalCode: string().trim().min(3).max(15),
		country: string().refine((value) => value === "India", "Delivery is available in India only.")
	}),
	delivery: _enum(["standard", "express"]),
	method: _enum([
		"card",
		"upi",
		"cod"
	]),
	expectedTotal: number().int().nonnegative(),
	idempotencyKey: uuid()
});
var uploadSchema = object({
	name: string().min(1).max(200),
	contentType: string().max(100).refine((value) => [
		"image/jpeg",
		"image/png",
		"image/webp",
		"image/avif",
		"application/pdf"
	].includes(value), "Unsupported file type."),
	size: number().int().min(1).max(5242880)
});
var fileSchema = object({
	key: string().min(1).max(1024),
	remove: boolean()
});
var analyticsSchema = object({
	event: string().regex(/^[a-zA-Z0-9_.-]{1,80}$/),
	properties: record(string().max(100), union([
		string().max(500),
		number().finite(),
		boolean(),
		_null()
	])).optional()
});
var rupees = number().int().min(1).max(1e8);
var productImageTypes = [
	"image/jpeg",
	"image/png",
	"image/webp",
	"image/avif"
];
var productImageMaxBytes = 5242880;
var productUploadSchema = object({
	contentType: _enum(productImageTypes),
	size: number().int().min(1).max(productImageMaxBytes)
}).strict();
var createProductSchema = object({
	name: string().trim().min(1).max(200),
	categoryId: idSchema,
	description: string().trim().min(1).max(5e3),
	price: rupees,
	originalPrice: rupees.optional(),
	stock: number().int().min(0).max(1e6),
	images: array(string().min(1).max(300)).min(1).max(6)
}).strict().refine((value) => (value.originalPrice ?? value.price) >= value.price, {
	message: "List price must be at least the selling price.",
	path: ["originalPrice"]
}).refine((value) => new Set(value.images).size === value.images.length, {
	message: "Each product image must be different.",
	path: ["images"]
});
var updatePriceSchema = object({
	productId: idSchema,
	price: rupees,
	originalPrice: rupees,
	expectedPrice: rupees,
	expectedOriginalPrice: rupees
}).strict().refine((value) => value.originalPrice >= value.price, {
	message: "List price must be at least the selling price.",
	path: ["originalPrice"]
});
var reviewSchema = object({
	productId: idSchema,
	rating: number().int().min(1).max(5),
	title: string().trim().min(1).max(120),
	body: string().trim().min(1).max(2e3)
}).strict();
var orderStatuses = [
	"processing",
	"shipped",
	"delivered",
	"cancelled"
];
var orderStatusSchema = _enum(orderStatuses);
var adminOrderCursorSchema = object({
	ownerId: idSchema,
	orderId: idSchema
}).strict();
var adminOrdersSchema = object({ cursor: adminOrderCursorSchema.optional() }).strict();
var adminOrderStatusSchema = object({
	ownerId: idSchema,
	orderId: idSchema,
	expectedStatus: orderStatusSchema,
	status: orderStatusSchema
}).strict();
var config = {
	...process.env["AWS_REGION"] ? { region: process.env["AWS_REGION"] } : {},
	maxAttempts: 3
};
var db = DynamoDBDocumentClient.from(new DynamoDBClient(config), { marshallOptions: { removeUndefinedValues: true } });
var s3 = new S3Client(config);
var cognito = new CognitoIdentityProviderClient(config);
var table = process.env["TABLE_NAME"];
var bucket = process.env["MEDIA_BUCKET"];
var clientId = process.env["COGNITO_CLIENT_ID"];
async function getUser(token) {
	const result = await cognito.send(new GetUserCommand({ AccessToken: token }));
	const attributes = new Map((result.UserAttributes ?? []).map((a) => [a.Name, a.Value]));
	const sub = attributes.get("sub");
	const email = attributes.get("email");
	if (!sub || !email || attributes.get("email_verified") !== "true") throw new HttpError(403, "Verify your email before placing an order.");
	return {
		id: sub,
		name: attributes.get("name") ?? email,
		email,
		addresses: []
	};
}
async function getItem(pk, sk) {
	return (await db.send(new GetCommand({
		TableName: table,
		Key: {
			pk,
			sk
		},
		ConsistentRead: true
	}))).Item;
}
async function queryItems(pk, prefix) {
	const items = [];
	let cursor;
	do {
		const page = await db.send(new QueryCommand({
			TableName: table,
			KeyConditionExpression: "pk = :pk AND begins_with(sk, :prefix)",
			ExpressionAttributeValues: {
				":pk": pk,
				":prefix": prefix
			},
			ExclusiveStartKey: cursor,
			ConsistentRead: true
		}));
		items.push(...page.Items ?? []);
		cursor = page.LastEvaluatedKey;
	} while (cursor);
	return items;
}
function id(value) {
	const result = idSchema.safeParse(value);
	if (!result.success) throw new HttpError(400, "Invalid item identifier.");
	return result.data;
}
async function product(idValue) {
	const item = await getItem("CATALOG", `PRODUCT#${id(idValue)}`);
	if (!item) throw new HttpError(404, "Product not found.");
	return item.data;
}
async function imageUrl(key) {
	if (!key.startsWith("s3://")) return key;
	const objectKey = key.replace(`s3://${bucket}/`, "");
	if (objectKey === key) throw new HttpError(500, "Product image bucket is not configured correctly.");
	return getSignedUrl(s3, new GetObjectCommand({
		Bucket: bucket,
		Key: objectKey
	}), { expiresIn: 900 });
}
async function presentProduct(p) {
	return {
		...p,
		images: await Promise.all(p.images.map(imageUrl))
	};
}
async function staticAsset(request) {
	const bucket = process.env["ASSET_BUCKET"];
	if (!bucket || !["GET", "HEAD"].includes(request.method)) return void 0;
	const path = new URL(request.url).pathname;
	if (!path.startsWith("/assets/") && !path.startsWith("/images/") && ![
		"/favicon.ico",
		"/favicon.svg",
		"/robots.txt"
	].includes(path)) return void 0;
	try {
		const result = await s3.send(new GetObjectCommand({
			Bucket: bucket,
			Key: decodeURIComponent(path.slice(1))
		}));
		const headers = new Headers({
			"Content-Type": result.ContentType ?? "application/octet-stream",
			"Cache-Control": path.startsWith("/assets/") ? "public, max-age=31536000, immutable" : "public, max-age=300",
			"X-Content-Type-Options": "nosniff"
		});
		if (result.ETag) headers.set("ETag", result.ETag);
		const bytes = await result.Body?.transformToByteArray();
		return new Response(request.method === "HEAD" || !bytes ? null : new Uint8Array(bytes).buffer, { headers });
	} catch (error) {
		if (error instanceof Error && ["NoSuchKey", "NotFound"].includes(error.name)) return new Response("Not found", { status: 404 });
		throw error;
	}
}
var serverEntryPromise;
async function getServerEntry() {
	if (!serverEntryPromise) serverEntryPromise = import("./server-CiMkYVYO.mjs").then((n) => n.t).then((m) => m.default ?? m);
	return serverEntryPromise;
}
async function normalizeCatastrophicSsrResponse(response) {
	if (response.status < 500) return response;
	if (!(response.headers.get("content-type") ?? "").includes("application/json")) return response;
	if (!isH3SwallowedErrorBody(await response.clone().text())) return response;
	console.error(JSON.stringify({
		event: "ssr.failed",
		code: "HTTPError"
	}));
	return new Response(renderErrorPage(), {
		status: 500,
		headers: { "content-type": "text/html; charset=utf-8" }
	});
}
function isH3SwallowedErrorBody(body) {
	try {
		const payload = JSON.parse(body);
		return payload.unhandled === true && payload.message === "HTTPError";
	} catch {
		return false;
	}
}
var server_default = { async fetch(request, env, ctx) {
	try {
		const asset = await staticAsset(request);
		if (asset) return asset;
		return await normalizeCatastrophicSsrResponse(await (await getServerEntry()).fetch(request, env, ctx));
	} catch (error) {
		console.error(JSON.stringify({
			event: "runtime.failed",
			code: error instanceof Error ? error.name : "unknown"
		}));
		return new Response(renderErrorPage(), {
			status: 500,
			headers: {
				"content-type": "text/html; charset=utf-8",
				"cache-control": "no-store"
			}
		});
	}
} };
export { productImageTypes as A, fileSchema as C, orderStatusSchema as D, orderSchema as E, signupSchema as F, updatePriceSchema as I, uploadSchema as L, productUploadSchema as M, resetSchema as N, orderStatuses as O, reviewSchema as P, renderErrorPage as R, emailSchema as S, loginSchema as T, adminOrdersSchema as _, getItem as a, confirmationSchema as b, imageUrl as c, queryItems as d, server_default as default, s3 as f, adminOrderStatusSchema as g, adminOrderCursorSchema as h, db as i, productQuerySchema as j, productImageMaxBytes as k, presentProduct as l, HttpError as m, clientId as n, getUser as o, table as p, cognito as r, id as s, bucket as t, product as u, analyticsSchema as v, idSchema as w, createProductSchema as x, cartChangeSchema as y, ssr_exports as z };
