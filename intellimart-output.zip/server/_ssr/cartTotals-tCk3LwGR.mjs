// node_modules/.nitro/vite/services/ssr/assets/cartTotals-tCk3LwGR.js
/** Display estimates and authoritative server totals share the same pricing rules. */
function calculateCartTotals(cart, delivery = "standard") {
	const active = cart.items.filter((item) => !item.savedForLater);
	const subtotal = active.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
	const discount = active.reduce((sum, item) => sum + Math.max(0, item.product.originalPrice - item.product.price) * item.quantity, 0);
	const shipping = subtotal === 0 ? 0 : delivery === "express" ? 499 : subtotal > 2e4 ? 0 : 199;
	const tax = Math.round(subtotal * .18);
	return {
		subtotal,
		discount,
		shipping,
		tax,
		total: subtotal + shipping + tax
	};
}
export { calculateCartTotals as t };
