import { a as relatedFn, i as productsFn, n as priceRangeFn, o as reviewsFn, r as productFn, t as categoriesFn } from "./catalogue.functions-DBDE1qea.mjs";
import { N as unwrap } from "./router-Couj4mWN.mjs";
// node_modules/.nitro/vite/services/ssr/assets/awsProductService-VU2HHCXI.js
var productService = {
	list: (query = {}) => unwrap(() => productsFn({ data: query }), false),
	getById: (id) => unwrap(() => productFn({ data: id }), false),
	getFeatured: (limit = 8) => unwrap(() => productsFn({ data: {
		featured: true,
		limit
	} }), false),
	getRelated: (id, limit = 4) => unwrap(() => relatedFn({ data: {
		id,
		limit
	} }), false),
	getCategories: () => unwrap(() => categoriesFn(), false),
	getReviews: (id) => unwrap(() => reviewsFn({ data: id }), false),
	getPriceRange: () => unwrap(() => priceRangeFn(), false)
};
export { productService as t };
