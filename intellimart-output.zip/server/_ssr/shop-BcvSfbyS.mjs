import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as CheckboxIndicator, p as require_jsx_runtime, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as cn, t as Button } from "./button-DUF1Y1qY.mjs";
import { t as productService } from "./awsProductService-VU2HHCXI.mjs";
import { b as Check, o as SlidersHorizontal } from "../_libs/lucide-react.mjs";
import { S as currency, _ as SheetHeader, g as SheetContent, h as Sheet, i as Route$2, m as SearchBar, v as SheetTitle, y as SheetTrigger } from "./router-Couj4mWN.mjs";
import { t as Label } from "./label-Cvda4mU8.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-IldXxGe8.mjs";
import { t as ProductGrid } from "./ProductGrid-34LfjVZO.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/radix-ui__react-slider.mjs";
// node_modules/.nitro/vite/services/ssr/assets/shop-BcvSfbyS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" })]
}));
Slider.displayName = Slider$1.displayName;
function ProductFilters({ categories, state, onChange, priceRange, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-base font-medium",
				children: "Department"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3",
				children: categories.map((c) => {
					const checked = state.categories.includes(c.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							id: `cat-${c.id}`,
							checked,
							onCheckedChange: () => onChange({
								...state,
								categories: checked ? state.categories.filter((x) => x !== c.id) : [...state.categories, c.id]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `cat-${c.id}`,
							className: "cursor-pointer text-sm font-normal",
							children: c.name
						})]
					}, c.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-base font-medium",
				children: "Budget"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					value: [state.maxPrice],
					min: priceRange.min,
					max: priceRange.max,
					step: 500,
					onValueChange: ([v]) => onChange({
						...state,
						maxPrice: v ?? priceRange.max
					}),
					"aria-label": "Maximum price"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex justify-between text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currency(priceRange.min) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-foreground",
						children: currency(state.maxPrice)
					})]
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-base font-medium",
				children: "Rating"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3",
				children: [
					0,
					4,
					4.5
				].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "radio",
						id: `rating-${r}`,
						name: "rating",
						checked: state.minRating === r,
						onChange: () => onChange({
							...state,
							minRating: r
						}),
						className: "h-4 w-4 accent-[var(--primary)]"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: `rating-${r}`,
						className: "cursor-pointer text-sm font-normal",
						children: r === 0 ? "Any rating" : `${r} stars and above`
					})]
				}, r))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "subtle",
				className: "w-full",
				onClick: onReset,
				children: "Reset filters"
			})
		]
	});
}
function ShopPage() {
	const { category, sale } = Route$2.useSearch();
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [products, setProducts] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	const [sort, setSort] = (0, import_react.useState)("featured");
	const [priceRange, setPriceRange] = (0, import_react.useState)({
		min: 0,
		max: 0
	});
	const [priceReady, setPriceReady] = (0, import_react.useState)(false);
	const [filters, setFilters] = (0, import_react.useState)({
		categories: category ? [category] : [],
		maxPrice: 0,
		minRating: 0
	});
	(0, import_react.useEffect)(() => {
		setFilters((f) => ({
			...f,
			categories: category ? [category] : []
		}));
	}, [category]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		Promise.all([productService.getCategories(), productService.getPriceRange()]).then(([departments, range]) => {
			if (cancelled) return;
			setCategories(departments);
			setPriceRange(range);
			setFilters((value) => ({
				...value,
				maxPrice: range.max
			}));
			setPriceReady(true);
		}).catch((error) => {
			if (!cancelled) {
				setError(error instanceof Error ? error.message : "Could not load the catalogue.");
				setLoading(false);
			}
		});
		return () => {
			cancelled = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!priceReady) return;
		let cancelled = false;
		setLoading(true);
		setError(null);
		productService.list({
			categories: filters.categories,
			maxPrice: filters.maxPrice,
			minRating: filters.minRating,
			sort
		}).then((list) => !cancelled && setProducts(sale ? list.filter((p) => p.originalPrice > p.price) : list)).catch((e) => !cancelled && setError(e instanceof Error ? e.message : "Failed to load products")).finally(() => !cancelled && setLoading(false));
		return () => {
			cancelled = true;
		};
	}, [
		filters,
		sort,
		sale,
		priceReady
	]);
	const reset = () => setFilters({
		categories: [],
		maxPrice: priceRange.max,
		minRating: 0
	});
	const filterPanel = (0, import_react.useMemo)(() => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductFilters, {
		categories,
		state: filters,
		onChange: setFilters,
		priceRange: {
			min: priceRange.min,
			max: Math.max(priceRange.max, priceRange.min + 1)
		},
		onReset: reset
	}), [
		categories,
		filters,
		priceRange.max,
		priceRange.min,
		reset
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container pb-24 pt-10 sm:pt-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-12 sm:mb-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl font-medium tracking-tight sm:text-7xl",
				children: sale ? "The good deals" : "The collection"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-base",
				children: sale ? "Good finds. Even better prices." : "For your desk, your downtime and everything in between."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-[200px_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sticky top-24",
					children: filterPanel
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-52 flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "lg:hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { "aria-hidden": true }), " Filters"]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
							side: "left",
							className: "w-80 overflow-y-auto",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
								className: "font-display",
								children: "Filters"
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-4 pb-8",
								children: filterPanel
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: sort,
							onValueChange: (v) => setSort(v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "w-48",
								"aria-label": "Sort products",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Sort" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "featured",
									children: "Featured"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "price-asc",
									children: "Price: Low to High"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "price-desc",
									children: "Price: High to Low"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "rating",
									children: "Highest Rated"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "newest",
									children: "Newest"
								})
							] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm text-muted-foreground",
					"aria-live": "polite",
					children: loading ? "Loading products…" : `${products.length} products`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, {
					products,
					loading,
					error,
					className: "catalogue-grid"
				})
			] })]
		})]
	});
}
export { ShopPage as component };
