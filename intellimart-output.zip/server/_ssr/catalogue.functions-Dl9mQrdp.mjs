import { c as number, d as string, l as object } from "../_libs/zod.mjs";
import { j as productQuerySchema, w as idSchema } from "./ssr.mjs";
import { r as createServerFn } from "./server-CiMkYVYO.mjs";
import { n as rpc } from "./rpc.server-DnC90LS4.mjs";
import { t as createServerRpc } from "./createServerRpc-F9KTd2Fz.mjs";
import { a as related, i as priceRange, n as detail, o as reviews, r as list, s as suggestions, t as categories } from "./catalogue.server-CW6i4Fm8.mjs";
// node_modules/.nitro/vite/services/ssr/assets/catalogue.functions-Dl9mQrdp.js
var productsFn_createServerFn_handler = createServerRpc({
	id: "505034f6c1509072c9b72795c5951f9cfa306c998d82ddc744ae3a75529a69d8",
	name: "productsFn",
	filename: "src/functions/catalogue.functions.ts"
}, (opts) => productsFn.__executeServer(opts));
var productsFn = createServerFn({ method: "GET" }).validator(productQuerySchema).handler(productsFn_createServerFn_handler, ({ data }) => rpc(() => list(data)));
var productFn_createServerFn_handler = createServerRpc({
	id: "c087471c6121e41c9d35167fffbc5ff18678392d67430a9bcb89e0f75b31e205",
	name: "productFn",
	filename: "src/functions/catalogue.functions.ts"
}, (opts) => productFn.__executeServer(opts));
var productFn = createServerFn({ method: "GET" }).validator(idSchema).handler(productFn_createServerFn_handler, ({ data }) => rpc(() => detail(data)));
var categoriesFn_createServerFn_handler = createServerRpc({
	id: "31fcc8d20701a93edecf6b2813cee9db316064ce5356852c680b4e193943a22d",
	name: "categoriesFn",
	filename: "src/functions/catalogue.functions.ts"
}, (opts) => categoriesFn.__executeServer(opts));
var categoriesFn = createServerFn({ method: "GET" }).handler(categoriesFn_createServerFn_handler, () => rpc(categories));
var reviewsFn_createServerFn_handler = createServerRpc({
	id: "0a57ea703e25e959586c6f30d63196c9cdef45974498456bcf26b85802632ffa",
	name: "reviewsFn",
	filename: "src/functions/catalogue.functions.ts"
}, (opts) => reviewsFn.__executeServer(opts));
var reviewsFn = createServerFn({ method: "GET" }).validator(idSchema).handler(reviewsFn_createServerFn_handler, ({ data }) => rpc(() => reviews(data)));
var relatedFn_createServerFn_handler = createServerRpc({
	id: "d39ba7cf46f2596a149586f31c055eadad477ce900f15635139c867dc5c5d891",
	name: "relatedFn",
	filename: "src/functions/catalogue.functions.ts"
}, (opts) => relatedFn.__executeServer(opts));
var relatedFn = createServerFn({ method: "GET" }).validator(object({
	id: idSchema,
	limit: number().int().min(1).max(100)
})).handler(relatedFn_createServerFn_handler, ({ data }) => rpc(() => related(data.id, data.limit)));
var priceRangeFn_createServerFn_handler = createServerRpc({
	id: "6bfe4e6b6cc0434a447a4c104dc38a4add00cc56323e2a06dd7ed361d0649133",
	name: "priceRangeFn",
	filename: "src/functions/catalogue.functions.ts"
}, (opts) => priceRangeFn.__executeServer(opts));
var priceRangeFn = createServerFn({ method: "GET" }).handler(priceRangeFn_createServerFn_handler, () => rpc(priceRange));
var suggestionsFn_createServerFn_handler = createServerRpc({
	id: "bcd37277638b8aa16f12025069395b727ffcd52a8d33963d4987ce20923bf1fa",
	name: "suggestionsFn",
	filename: "src/functions/catalogue.functions.ts"
}, (opts) => suggestionsFn.__executeServer(opts));
var suggestionsFn = createServerFn({ method: "GET" }).validator(string().max(200)).handler(suggestionsFn_createServerFn_handler, ({ data }) => rpc(() => suggestions(data)));
export { categoriesFn_createServerFn_handler, priceRangeFn_createServerFn_handler, productFn_createServerFn_handler, productsFn_createServerFn_handler, relatedFn_createServerFn_handler, reviewsFn_createServerFn_handler, suggestionsFn_createServerFn_handler };
