import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/about-CsHFoRmB.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container grid gap-12 pb-24 pt-10 sm:pt-16 lg:grid-cols-2 lg:gap-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "font-display text-5xl font-medium leading-[1.05] sm:text-7xl",
				children: [
					"Good things.",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"Every day."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 max-w-lg space-y-5 text-base leading-relaxed",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "IntelliMart brings together electronics, computing and smart devices for everyday work and play. From audio and gaming to smart home gear, explore the products that fit your routine." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Find your next upgrade at your own pace. Browse by category, narrow your search by brand or budget, and explore product specifications and reviews before adding something to your cart." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Spotted something you like? Save it to your wishlist for another look, or head to our deals page to discover discounted products. Your account keeps your profile, wishlist and order history together in one place." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex flex-wrap items-center gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "hero",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						children: "Start shopping"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/deals",
					className: "text-link",
					children: "Explore deals"
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-4 self-start lg:pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/watch.jpg",
					alt: "A simple white watch for everyday wear",
					width: 800,
					height: 1e3,
					className: "aspect-[4/5] w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/keyboard.jpg",
					alt: "A compact keyboard for your desk",
					width: 800,
					height: 1e3,
					className: "mt-12 aspect-[4/5] w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/backpack.jpg",
					alt: "An everyday backpack",
					width: 800,
					height: 1e3,
					loading: "lazy",
					className: "aspect-[4/5] w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/speaker.jpg",
					alt: "A speaker for your favourite listening spot",
					width: 800,
					height: 1e3,
					loading: "lazy",
					className: "mt-12 aspect-[4/5] w-full object-cover"
				})
			]
		})]
	});
}
export { AboutPage as component };
