import { i as DeleteObjectCommand, r as GetObjectCommand } from "../_libs/@aws-sdk/client-s3+[...].mjs";
import { a as PutCommand, n as UpdateCommand, r as TransactWriteCommand, s as DeleteCommand } from "../_libs/@aws-sdk/lib-dynamodb+[...].mjs";
import { t as getSignedUrl } from "../_libs/aws-sdk__s3-request-presigner.mjs";
import { i as boolean, l as object } from "../_libs/zod.mjs";
import { C as fileSchema, E as orderSchema, L as uploadSchema, a as getItem, c as imageUrl, d as queryItems, f as s3, i as db, l as presentProduct, m as HttpError, p as table, s as id, t as bucket, u as product, v as analyticsSchema, w as idSchema, y as cartChangeSchema } from "./ssr.mjs";
import { f as createMiddleware, r as createServerFn } from "./server-CiMkYVYO.mjs";
import { r as requireSession } from "./session.server-rd_-hBLH.mjs";
import { n as rpc, t as authenticated } from "./rpc.server-DnC90LS4.mjs";
import { t as calculateCartTotals } from "./cartTotals-tCk3LwGR.mjs";
import { t as createServerRpc } from "./createServerRpc-F9KTd2Fz.mjs";
import { t as createPresignedPost } from "../_libs/aws-sdk__s3-presigned-post.mjs";
import { randomUUID } from "node:crypto";
// node_modules/.nitro/vite/services/ssr/assets/customer.functions-DOHfxEjx.js
async function readCart(pk) {
	const stored = await queryItems(pk, "CART#");
	return {
		cart: {
			items: await Promise.all(stored.map(async (item) => ({
				productId: item.productId,
				quantity: item.quantity,
				savedForLater: item.savedForLater,
				product: await product(item.productId)
			}))),
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		},
		stored
	};
}
async function presentCart(pk) {
	const { cart } = await readCart(pk);
	return {
		...cart,
		items: await Promise.all(cart.items.map(async (item) => ({
			...item,
			product: await presentProduct(item.product)
		})))
	};
}
async function orderFor(pk, orderId) {
	const entry = await getItem(pk, `ORDER#${id(orderId)}`);
	if (!entry) throw new HttpError(404, "Order not found.");
	return entry;
}
async function presentOrder(order) {
	return {
		...order,
		items: await Promise.all(order.items.map(async (item) => ({
			...item,
			image: await imageUrl(item.image)
		})))
	};
}
async function getCart(user) {
	return presentCart(`USER#${user.id}`);
}
async function changeCart(user, input) {
	const pk = `USER#${user.id}`;
	if (input.action === "clear") {
		const items = await queryItems(pk, "CART#");
		for (let offset = 0; offset < items.length; offset += 25) await db.send(new TransactWriteCommand({ TransactItems: items.slice(offset, offset + 25).map((item) => ({ Delete: {
			TableName: table,
			Key: {
				pk,
				sk: item.sk
			},
			ConditionExpression: "revision = :revision",
			ExpressionAttributeValues: { ":revision": item.revision }
		} })) }));
		return presentCart(pk);
	}
	{
		const productId = input.productId;
		const key = {
			pk,
			sk: `CART#${productId}`
		};
		if (input.action === "remove") await db.send(new DeleteCommand({
			TableName: table,
			Key: key
		}));
		else if (input.action === "saved") {
			const current = await getItem(pk, key.sk);
			if (!current) throw new HttpError(404, "Cart item not found.");
			await db.send(new UpdateCommand({
				TableName: table,
				Key: key,
				UpdateExpression: "SET savedForLater = :saved, revision = :next",
				ConditionExpression: "revision = :revision",
				ExpressionAttributeValues: {
					":saved": !current.savedForLater,
					":next": randomUUID(),
					":revision": current.revision
				}
			}));
		} else {
			const { quantity } = input;
			const p = await product(productId);
			const current = await getItem(pk, key.sk);
			const nextQuantity = input.action === "add" ? (current?.quantity ?? 0) + quantity : quantity;
			if (nextQuantity > p.stock || nextQuantity > 99) throw new HttpError(409, "Not enough stock for that quantity.");
			if (!current && (await queryItems(pk, "CART#")).length >= 25) throw new HttpError(400, "Your bag can contain up to 25 different products.");
			if (nextQuantity === 0) {
				if (current) await db.send(new DeleteCommand({
					TableName: table,
					Key: key,
					ConditionExpression: "revision = :revision",
					ExpressionAttributeValues: { ":revision": current.revision }
				}));
			} else await db.send(new PutCommand({
				TableName: table,
				Item: {
					...key,
					productId,
					quantity: nextQuantity,
					savedForLater: input.action === "add" ? false : current?.savedForLater ?? false,
					revision: randomUUID()
				},
				ConditionExpression: current ? "revision = :revision" : "attribute_not_exists(pk)",
				...current ? { ExpressionAttributeValues: { ":revision": current.revision } } : {}
			}));
		}
		return presentCart(pk);
	}
}
async function listWishlist(user) {
	return (await queryItems(`USER#${user.id}`, "WISH#")).map((item) => item.data);
}
async function changeWishlist(user, productId, remove) {
	const pk = `USER#${user.id}`;
	const key = {
		pk,
		sk: `WISH#${productId}`
	};
	if (remove) await db.send(new DeleteCommand({
		TableName: table,
		Key: key
	}));
	else {
		await product(productId);
		await db.send(new PutCommand({
			TableName: table,
			Item: {
				...key,
				data: {
					productId,
					addedAt: (/* @__PURE__ */ new Date()).toISOString()
				}
			}
		}));
	}
	return (await queryItems(pk, "WISH#")).map((item) => item.data);
}
async function listOrders(user) {
	const pk = `USER#${user.id}`;
	return Promise.all((await queryItems(pk, "ORDER#")).map((item) => item.data).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(presentOrder));
}
async function createOrder(user, input) {
	const userId = user.id;
	const pk = `USER#${userId}`;
	const requestKey = `REQUEST#${input.idempotencyKey}`;
	const previous = await getItem(pk, requestKey);
	if (previous) return presentOrder((await orderFor(pk, previous.orderId)).data);
	const { cart, stored } = await readCart(pk);
	const active = cart.items.filter((item) => !item.savedForLater);
	if (!active.length) throw new HttpError(400, "Your bag is empty.");
	if (active.length > 25) throw new HttpError(400, "Place orders with no more than 25 different products.");
	const totals = calculateCartTotals(cart, input.delivery);
	if (totals.total !== input.expectedTotal) throw new HttpError(409, "Prices have changed. Refresh your bag and review the updated total.");
	const now = /* @__PURE__ */ new Date();
	const order = {
		id: `IM-${now.getFullYear()}-${randomUUID()}`,
		userId,
		address: input.address,
		delivery: input.delivery,
		items: active.map((item) => {
			const image = item.product.images[0];
			if (!image) throw new HttpError(409, "A product image is missing. Contact the store administrator.");
			return {
				productId: item.productId,
				quantity: item.quantity,
				name: item.product.name,
				price: item.product.price,
				image
			};
		}),
		totals,
		payment: {
			id: randomUUID(),
			method: input.method,
			status: input.method === "cod" ? "pending" : "mocked",
			amount: totals.total,
			...input.method === "cod" ? {} : { simulated: true }
		},
		status: "processing",
		createdAt: now.toISOString(),
		estimatedDelivery: new Date(now.getTime() + (input.delivery === "express" ? 2 : 6) * 864e5).toISOString()
	};
	const changes = [];
	for (const item of active) {
		const revision = stored.find((entry) => entry.productId === item.productId).revision;
		changes.push({ Update: {
			TableName: table,
			Key: {
				pk: "CATALOG",
				sk: `PRODUCT#${item.productId}`
			},
			UpdateExpression: "SET #data.#stock = #data.#stock - :quantity",
			ConditionExpression: "#data.#stock >= :quantity AND #data.#price = :price",
			ExpressionAttributeNames: {
				"#data": "data",
				"#stock": "stock",
				"#price": "price"
			},
			ExpressionAttributeValues: {
				":quantity": item.quantity,
				":price": item.product.price
			}
		} });
		changes.push({ Delete: {
			TableName: table,
			Key: {
				pk,
				sk: `CART#${item.productId}`
			},
			ConditionExpression: "revision = :revision",
			ExpressionAttributeValues: { ":revision": revision }
		} });
	}
	changes.push({ Put: {
		TableName: table,
		Item: {
			pk,
			sk: `ORDER#${order.id}`,
			entity: "order",
			recipient: user.email,
			data: order
		},
		ConditionExpression: "attribute_not_exists(pk)"
	} });
	changes.push({ Put: {
		TableName: table,
		Item: {
			pk,
			sk: requestKey,
			orderId: order.id,
			expiresAt: Math.floor(Date.now() / 1e3) + 604800
		},
		ConditionExpression: "attribute_not_exists(pk)"
	} });
	try {
		await db.send(new TransactWriteCommand({ TransactItems: changes }));
	} catch (error) {
		const completed = await getItem(pk, requestKey);
		if (completed) return presentOrder((await orderFor(pk, completed.orderId)).data);
		throw error;
	}
	return presentOrder(order);
}
async function getOrder(user, orderId) {
	return presentOrder((await orderFor(`USER#${user.id}`, orderId)).data);
}
async function cancelOrder(user, orderId) {
	const pk = `USER#${user.id}`;
	const entry = await orderFor(pk, orderId);
	if (entry.data.status === "cancelled") return presentOrder(entry.data);
	if (entry.data.status !== "processing") throw new HttpError(409, "This order can no longer be cancelled.");
	await db.send(new TransactWriteCommand({ TransactItems: [{ Update: {
		TableName: table,
		Key: {
			pk,
			sk: entry.sk
		},
		UpdateExpression: "SET #data.#status = :cancelled",
		ConditionExpression: "#data.#status = :processing",
		ExpressionAttributeNames: {
			"#data": "data",
			"#status": "status"
		},
		ExpressionAttributeValues: {
			":cancelled": "cancelled",
			":processing": "processing"
		}
	} }, ...entry.data.items.map((item) => ({ Update: {
		TableName: table,
		Key: {
			pk: "CATALOG",
			sk: `PRODUCT#${item.productId}`
		},
		UpdateExpression: "SET #data.#stock = #data.#stock + :quantity",
		ConditionExpression: "attribute_exists(pk)",
		ExpressionAttributeNames: {
			"#data": "data",
			"#stock": "stock"
		},
		ExpressionAttributeValues: { ":quantity": item.quantity }
	} }))] }));
	return presentOrder({
		...entry.data,
		status: "cancelled"
	});
}
async function uploadFile(user, input) {
	const userId = user.id;
	const name = input.name.replace(/[^a-zA-Z0-9._-]/g, "_");
	const key = `customers/${userId}/${randomUUID()}-${name}`;
	return {
		...await createPresignedPost(s3, {
			Bucket: bucket,
			Key: key,
			Expires: 300,
			Fields: { "Content-Type": input.contentType },
			Conditions: [[
				"content-length-range",
				1,
				input.size
			], [
				"eq",
				"$Content-Type",
				input.contentType
			]]
		}),
		key,
		fileUrl: await getSignedUrl(s3, new GetObjectCommand({
			Bucket: bucket,
			Key: key
		}), { expiresIn: 900 })
	};
}
async function accessFile(user, input) {
	const userId = user.id;
	if (!input.key.startsWith(`customers/${userId}/`)) throw new HttpError(403, "You cannot access this file.");
	if (input.remove) {
		await s3.send(new DeleteObjectCommand({
			Bucket: bucket,
			Key: input.key
		}));
		return {
			url: "",
			deleted: true
		};
	}
	return { url: await getSignedUrl(s3, new GetObjectCommand({
		Bucket: bucket,
		Key: input.key
	}), { expiresIn: 900 }) };
}
async function recordAnalytics(user, input) {
	const pk = `USER#${user.id}`;
	if (JSON.stringify(input).length > 8192) throw new HttpError(400, "Analytics payload is too large.");
	await db.send(new PutCommand({
		TableName: table,
		Item: {
			pk,
			sk: `EVENT#${Date.now()}#${randomUUID()}`,
			data: input,
			expiresAt: Math.floor(Date.now() / 1e3) + 2592e3
		}
	}));
	return { recorded: true };
}
var customerMiddleware = createMiddleware({ type: "function" }).server(async ({ next }) => {
	return next({ context: { authentication: await rpc(requireSession) } });
});
var cartFn_createServerFn_handler = createServerRpc({
	id: "1f360aed66aea3ffe684bcd7092db8065f53a049ce239f7a3bf5a52bf7b6875c",
	name: "cartFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => cartFn.__executeServer(opts));
var cartFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).handler(cartFn_createServerFn_handler, ({ context }) => authenticated(context.authentication, getCart));
var changeCartFn_createServerFn_handler = createServerRpc({
	id: "9625c4fb4b12bab5c4b2df38549cb6fcd2267f4c436c072486f61a5dff458cb3",
	name: "changeCartFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => changeCartFn.__executeServer(opts));
var changeCartFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(cartChangeSchema).handler(changeCartFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => changeCart(user, data)));
var wishlistFn_createServerFn_handler = createServerRpc({
	id: "61dae6f715aeb50de915695a0ce7d7b39de185cdc6d699da6b02ee9c2f02f20c",
	name: "wishlistFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => wishlistFn.__executeServer(opts));
var wishlistFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).handler(wishlistFn_createServerFn_handler, ({ context }) => authenticated(context.authentication, listWishlist));
var changeWishlistFn_createServerFn_handler = createServerRpc({
	id: "233d1ebc6d23a66c924785670dde0239aae426187b8d26c429acaab534673df2",
	name: "changeWishlistFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => changeWishlistFn.__executeServer(opts));
var changeWishlistFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(object({
	productId: idSchema,
	remove: boolean()
})).handler(changeWishlistFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => changeWishlist(user, data.productId, data.remove)));
var ordersFn_createServerFn_handler = createServerRpc({
	id: "41016c64398d7f8cb5ec417d2c80867f8d046aaf1df87281cefbada7372153f9",
	name: "ordersFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => ordersFn.__executeServer(opts));
var ordersFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).handler(ordersFn_createServerFn_handler, ({ context }) => authenticated(context.authentication, listOrders));
var orderFn_createServerFn_handler = createServerRpc({
	id: "d90e7c34afa3c3162a112ac20bf3c7c1c22c223075aa132bbd7e9d95320211a1",
	name: "orderFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => orderFn.__executeServer(opts));
var orderFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(idSchema).handler(orderFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => getOrder(user, data)));
var createOrderFn_createServerFn_handler = createServerRpc({
	id: "a949326553dc18263601b6c6b0b3b86ba055b8674e5bd1aa7b0804e590d9d6c5",
	name: "createOrderFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => createOrderFn.__executeServer(opts));
var createOrderFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(orderSchema).handler(createOrderFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => createOrder(user, data)));
var cancelOrderFn_createServerFn_handler = createServerRpc({
	id: "9a5d81c0a39cd5ca7ae15c83bf7d7d4a9dc119c2b14418448dc8a0082390ff2c",
	name: "cancelOrderFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => cancelOrderFn.__executeServer(opts));
var cancelOrderFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(idSchema).handler(cancelOrderFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => cancelOrder(user, data)));
var uploadFn_createServerFn_handler = createServerRpc({
	id: "2965128db8f0f47443f5031123e4e46832b14b857fed3571f118ce6f96336652",
	name: "uploadFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => uploadFn.__executeServer(opts));
var uploadFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(uploadSchema).handler(uploadFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => uploadFile(user, data)));
var fileFn_createServerFn_handler = createServerRpc({
	id: "042a8eac2dd455caabb9367546696b3ab9c5cd04c9b5eb1a9b6ad2ce49bf827c",
	name: "fileFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => fileFn.__executeServer(opts));
var fileFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(fileSchema).handler(fileFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => accessFile(user, data)));
var analyticsFn_createServerFn_handler = createServerRpc({
	id: "dfc6156fecdbb42dca037475ac390930343c2734fee36a127b2f7c99241787e9",
	name: "analyticsFn",
	filename: "src/functions/customer.functions.ts"
}, (opts) => analyticsFn.__executeServer(opts));
var analyticsFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(analyticsSchema).handler(analyticsFn_createServerFn_handler, ({ context, data }) => authenticated(context.authentication, (user) => recordAnalytics(user, data)));
export { analyticsFn_createServerFn_handler, cancelOrderFn_createServerFn_handler, cartFn_createServerFn_handler, changeCartFn_createServerFn_handler, changeWishlistFn_createServerFn_handler, createOrderFn_createServerFn_handler, fileFn_createServerFn_handler, orderFn_createServerFn_handler, ordersFn_createServerFn_handler, uploadFn_createServerFn_handler, wishlistFn_createServerFn_handler };
