import { c as ConfirmSignUpCommand, i as InitiateAuthCommand, l as ConfirmForgotPasswordCommand, r as ResendConfirmationCodeCommand, s as ForgotPasswordCommand, t as SignUpCommand } from "../_libs/@aws-sdk/client-cognito-identity-provider+[...].mjs";
import { F as signupSchema, N as resetSchema, S as emailSchema, T as loginSchema, b as confirmationSchema, m as HttpError, n as clientId, r as cognito } from "./ssr.mjs";
import { r as createServerFn } from "./server-CiMkYVYO.mjs";
import { i as signOut, n as currentSession, t as createSession } from "./session.server-rd_-hBLH.mjs";
import { n as rpc } from "./rpc.server-DnC90LS4.mjs";
import { t as createServerRpc } from "./createServerRpc-F9KTd2Fz.mjs";
// node_modules/.nitro/vite/services/ssr/assets/auth.functions-DtiWkfxW.js
async function signIn(input) {
	const result = await cognito.send(new InitiateAuthCommand({
		ClientId: clientId,
		AuthFlow: "USER_PASSWORD_AUTH",
		AuthParameters: {
			USERNAME: input.email,
			PASSWORD: input.password
		}
	}));
	const tokens = result.AuthenticationResult;
	if (!tokens?.AccessToken || !tokens.RefreshToken) throw new HttpError(400, "Your account requires an additional sign-in step. Contact the store administrator.", result.ChallengeName ?? "AUTH_CHALLENGE");
	return createSession(tokens.AccessToken, tokens.RefreshToken, tokens.ExpiresIn ?? 1800);
}
async function signUp(input) {
	await cognito.send(new SignUpCommand({
		ClientId: clientId,
		Username: input.email,
		Password: input.password,
		UserAttributes: [{
			Name: "email",
			Value: input.email
		}, {
			Name: "name",
			Value: input.name
		}]
	}));
	return { confirmationRequired: true };
}
async function confirmSignUp(input) {
	await cognito.send(new ConfirmSignUpCommand({
		ClientId: clientId,
		Username: input.email,
		ConfirmationCode: input.code
	}));
	return { confirmed: true };
}
async function resendCode(input) {
	await cognito.send(new ResendConfirmationCodeCommand({
		ClientId: clientId,
		Username: input.email
	}));
	return { sent: true };
}
async function forgotPassword(input) {
	await cognito.send(new ForgotPasswordCommand({
		ClientId: clientId,
		Username: input.email
	}));
	return { sent: true };
}
async function resetPassword(input) {
	await cognito.send(new ConfirmForgotPasswordCommand({
		ClientId: clientId,
		Username: input.email,
		ConfirmationCode: input.code,
		Password: input.password
	}));
	return { reset: true };
}
var signInFn_createServerFn_handler = createServerRpc({
	id: "c17e4ea028b58d83775aa13c11a0817d139052c5f9efaef1f9091fae641f89fb",
	name: "signInFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => signInFn.__executeServer(opts));
var signInFn = createServerFn({ method: "POST" }).validator(loginSchema).handler(signInFn_createServerFn_handler, ({ data }) => rpc(() => signIn(data)));
var signUpFn_createServerFn_handler = createServerRpc({
	id: "7f725e2091a0739c15e2abad26cebe0999b608f23b0115b08ae2cad015ceda8f",
	name: "signUpFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => signUpFn.__executeServer(opts));
var signUpFn = createServerFn({ method: "POST" }).validator(signupSchema).handler(signUpFn_createServerFn_handler, ({ data }) => rpc(() => signUp(data)));
var confirmSignUpFn_createServerFn_handler = createServerRpc({
	id: "5073a6da6d1f4d3dda3712b9fee30a94f595f1b96b000e52c9f4a271b8c6b3ff",
	name: "confirmSignUpFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => confirmSignUpFn.__executeServer(opts));
var confirmSignUpFn = createServerFn({ method: "POST" }).validator(confirmationSchema).handler(confirmSignUpFn_createServerFn_handler, ({ data }) => rpc(() => confirmSignUp(data)));
var resendCodeFn_createServerFn_handler = createServerRpc({
	id: "61d889fa5b951751adf2d7bfc5ed8828432ed2285e929c18819c01d8c48a5a71",
	name: "resendCodeFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => resendCodeFn.__executeServer(opts));
var resendCodeFn = createServerFn({ method: "POST" }).validator(emailSchema).handler(resendCodeFn_createServerFn_handler, ({ data }) => rpc(() => resendCode(data)));
var forgotPasswordFn_createServerFn_handler = createServerRpc({
	id: "079a1390262f9d9bb31158eb7e0b161e570b47e67afe28755156446b7dc8b305",
	name: "forgotPasswordFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => forgotPasswordFn.__executeServer(opts));
var forgotPasswordFn = createServerFn({ method: "POST" }).validator(emailSchema).handler(forgotPasswordFn_createServerFn_handler, ({ data }) => rpc(() => forgotPassword(data)));
var resetPasswordFn_createServerFn_handler = createServerRpc({
	id: "042fe8bef62a4cae11fe757be8e044b8a3e4027bd796123dba5e5f3350792d78",
	name: "resetPasswordFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => resetPasswordFn.__executeServer(opts));
var resetPasswordFn = createServerFn({ method: "POST" }).validator(resetSchema).handler(resetPasswordFn_createServerFn_handler, ({ data }) => rpc(() => resetPassword(data)));
var signOutFn_createServerFn_handler = createServerRpc({
	id: "abd88ab174072b5cd556ef06e35ac1a6e5c1321022cd1903d7994ffc2921068f",
	name: "signOutFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => signOutFn.__executeServer(opts));
var signOutFn = createServerFn({ method: "POST" }).handler(signOutFn_createServerFn_handler, () => rpc(signOut));
var sessionFn_createServerFn_handler = createServerRpc({
	id: "ed7f103ceadee95beb54a0b0944322afe8f88b91bed5dfe9981d0c4f26ccdd76",
	name: "sessionFn",
	filename: "src/functions/auth.functions.ts"
}, (opts) => sessionFn.__executeServer(opts));
var sessionFn = createServerFn({ method: "POST" }).handler(sessionFn_createServerFn_handler, () => rpc(currentSession));
export { confirmSignUpFn_createServerFn_handler, forgotPasswordFn_createServerFn_handler, resendCodeFn_createServerFn_handler, resetPasswordFn_createServerFn_handler, sessionFn_createServerFn_handler, signInFn_createServerFn_handler, signOutFn_createServerFn_handler, signUpFn_createServerFn_handler };
