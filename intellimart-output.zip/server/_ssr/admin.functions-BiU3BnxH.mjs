import { u as AdminListGroupsForUserCommand } from "../_libs/@aws-sdk/client-cognito-identity-provider+[...].mjs";
import { n as HeadObjectCommand } from "../_libs/@aws-sdk/client-s3+[...].mjs";
import { l as TransactionCanceledException } from "../_libs/@aws-sdk/client-dynamodb+[...].mjs";
import { a as PutCommand, i as QueryCommand, n as UpdateCommand, r as TransactWriteCommand } from "../_libs/@aws-sdk/lib-dynamodb+[...].mjs";
import { A as productImageTypes, D as orderStatusSchema, I as updatePriceSchema, M as productUploadSchema, _ as adminOrdersSchema, a as getItem, d as queryItems, f as s3, g as adminOrderStatusSchema, h as adminOrderCursorSchema, i as db, l as presentProduct, m as HttpError, p as table, r as cognito, t as bucket, w as idSchema, x as createProductSchema } from "./ssr.mjs";
import { r as createServerFn } from "./server-CiMkYVYO.mjs";
import { r as requireSession } from "./session.server-rd_-hBLH.mjs";
import { n as rpc } from "./rpc.server-DnC90LS4.mjs";
import { t as createServerRpc } from "./createServerRpc-F9KTd2Fz.mjs";
import { t as categories } from "./catalogue.server-CW6i4Fm8.mjs";
import { t as createPresignedPost } from "../_libs/aws-sdk__s3-presigned-post.mjs";
import { randomUUID } from "node:crypto";
// node_modules/.nitro/vite/services/ssr/assets/admin.functions-BiU3BnxH.js
var poolId = process.env["COGNITO_USER_POOL_ID"];
var groupName = "Admins";
async function requireAdmin() {
	const { user } = await requireSession();
	let nextToken;
	do {
		const page = await cognito.send(new AdminListGroupsForUserCommand({
			UserPoolId: poolId,
			Username: user.id,
			NextToken: nextToken
		}));
		if (page.Groups?.some((group) => group.GroupName === groupName)) return user;
		nextToken = page.NextToken;
	} while (nextToken);
	throw new HttpError(403, "This account does not have administrator access.", "ADMIN_REQUIRED");
}
async function access() {
	await requireAdmin();
	return { allowed: true };
}
async function listProducts() {
	await requireAdmin();
	return {
		products: await Promise.all((await queryItems("CATALOG", "PRODUCT#")).map((item) => presentProduct(item.data))),
		categories: await categories()
	};
}
async function uploadImage(input) {
	const user = await requireAdmin();
	const extension = {
		"image/jpeg": "jpg",
		"image/png": "png",
		"image/webp": "webp",
		"image/avif": "avif"
	}[input.contentType];
	const key = `products/admin/${user.id}/${randomUUID()}.${extension}`;
	const expiresAt = Math.floor(Date.now() / 1e3) + 3600;
	await db.send(new PutCommand({
		TableName: table,
		Item: {
			pk: `ADMINUPLOAD#${user.id}`,
			sk: key,
			...input,
			expiresAt
		},
		ConditionExpression: "attribute_not_exists(pk)"
	}));
	return {
		...await createPresignedPost(s3, {
			Bucket: bucket,
			Key: key,
			Expires: 300,
			Fields: { "Content-Type": input.contentType },
			Conditions: [
				[
					"eq",
					"$key",
					key
				],
				[
					"eq",
					"$Content-Type",
					input.contentType
				],
				[
					"content-length-range",
					input.size,
					input.size
				]
			]
		}),
		key
	};
}
async function createProduct(input) {
	const user = await requireAdmin();
	const category = await getItem("CATALOG", `CATEGORY#${input.categoryId}`);
	if (!category || category.data.id !== input.categoryId) throw new HttpError(400, "Choose an existing category.");
	const nowSeconds = Math.floor(Date.now() / 1e3);
	for (const key of input.images) {
		if (!key.startsWith(`products/admin/${user.id}/`) || !/^products\/admin\/[a-zA-Z0-9_-]+\/[a-f0-9-]{36}\.(jpg|png|webp|avif)$/.test(key)) throw new HttpError(400, "Use images uploaded through this administrator account.");
		const receipt = await getItem(`ADMINUPLOAD#${user.id}`, key);
		if (!receipt || receipt.expiresAt <= nowSeconds) throw new HttpError(400, "This image upload expired or was already used. Upload it again.");
		let object;
		try {
			object = await s3.send(new HeadObjectCommand({
				Bucket: bucket,
				Key: key
			}));
		} catch (error) {
			if (error instanceof Error && ["NotFound", "NoSuchKey"].includes(error.name)) throw new HttpError(400, "Finish uploading every image before adding the product.");
			throw error;
		}
		if (!productImageTypes.some((type) => type === object.ContentType) || object.ContentType !== receipt.contentType || object.ContentLength !== receipt.size || receipt.size < 1 || receipt.size > 5242880) throw new HttpError(400, "An uploaded image has an invalid type or size.");
	}
	const id = randomUUID();
	const data = {
		id,
		slug: `${input.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80) || "product"}-${id}`,
		name: input.name,
		categoryId: category.data.id,
		category: category.data.name,
		description: input.description,
		price: input.price,
		originalPrice: input.originalPrice ?? input.price,
		stock: input.stock,
		images: input.images.map((key) => `s3://${bucket}/${key}`),
		rating: 0,
		reviewCount: 0,
		highlights: [],
		specifications: {},
		tags: [],
		featured: false,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	await db.send(new TransactWriteCommand({ TransactItems: [
		{ Put: {
			TableName: table,
			Item: {
				pk: "CATALOG",
				sk: `PRODUCT#${id}`,
				data,
				ratingTotal: 0
			},
			ConditionExpression: "attribute_not_exists(pk)"
		} },
		{ Update: {
			TableName: table,
			Key: {
				pk: "CATALOG",
				sk: `CATEGORY#${category.data.id}`
			},
			UpdateExpression: "SET #data.#count = if_not_exists(#data.#count, :zero) + :one",
			ConditionExpression: "attribute_exists(pk) AND #data.#name = :name",
			ExpressionAttributeNames: {
				"#data": "data",
				"#count": "productCount",
				"#name": "name"
			},
			ExpressionAttributeValues: {
				":zero": 0,
				":one": 1,
				":name": category.data.name
			}
		} },
		...input.images.map((key) => ({ Delete: {
			TableName: table,
			Key: {
				pk: `ADMINUPLOAD#${user.id}`,
				sk: key
			},
			ConditionExpression: "attribute_exists(pk) AND expiresAt > :now",
			ExpressionAttributeValues: { ":now": nowSeconds }
		} }))
	] }));
	return presentProduct(data);
}
async function updatePrice(input) {
	await requireAdmin();
	await db.send(new UpdateCommand({
		TableName: table,
		Key: {
			pk: "CATALOG",
			sk: `PRODUCT#${input.productId}`
		},
		UpdateExpression: "SET #data.#price = :price, #data.#original = :original, updatedAt = :now",
		ConditionExpression: "attribute_exists(pk) AND #data.#price = :expectedPrice AND #data.#original = :expectedOriginal",
		ExpressionAttributeNames: {
			"#data": "data",
			"#price": "price",
			"#original": "originalPrice"
		},
		ExpressionAttributeValues: {
			":price": input.price,
			":original": input.originalPrice,
			":expectedPrice": input.expectedPrice,
			":expectedOriginal": input.expectedOriginalPrice,
			":now": (/* @__PURE__ */ new Date()).toISOString()
		}
	}));
	return {
		productId: input.productId,
		price: input.price,
		originalPrice: input.originalPrice
	};
}
var indexName = "OrdersByEntity";
var pageSize = 25;
function cursorFor(pk, sk) {
	if (typeof pk !== "string" || !pk.startsWith("USER#") || typeof sk !== "string" || !sk.startsWith("ORDER#")) throw new HttpError(500, "An indexed order has an invalid key. Contact the store operator.");
	return adminOrderCursorSchema.parse({
		ownerId: pk.slice(5),
		orderId: sk.slice(6)
	});
}
function checkedOrder(entry, ownerId, orderId) {
	if (!entry || entry.entity !== "order") throw new HttpError(404, "Order not found.");
	if (entry.data.userId !== ownerId || entry.data.id !== orderId || !orderStatusSchema.safeParse(entry.data.status).success) throw new HttpError(409, "The stored order identity or status is invalid. Contact the store operator.");
	return entry.data;
}
function summarize(order) {
	return {
		id: order.id,
		ownerId: order.userId,
		customerName: order.address.fullName,
		createdAt: order.createdAt,
		total: order.totals.total,
		status: order.status,
		items: order.items.map(({ productId, name, quantity, price }) => ({
			productId,
			name,
			quantity,
			price
		}))
	};
}
async function listOrders(input) {
	await requireAdmin();
	const page = await db.send(new QueryCommand({
		TableName: table,
		IndexName: indexName,
		KeyConditionExpression: "#entity = :order",
		ExpressionAttributeNames: { "#entity": "entity" },
		ExpressionAttributeValues: { ":order": "order" },
		Limit: pageSize,
		ScanIndexForward: false,
		...input.cursor ? { ExclusiveStartKey: {
			pk: `USER#${input.cursor.ownerId}`,
			sk: `ORDER#${input.cursor.orderId}`,
			entity: "order"
		} } : {}
	}));
	return {
		orders: await Promise.all((page.Items ?? []).map(async (row) => {
			const { ownerId, orderId } = cursorFor(row["pk"], row["sk"]);
			return summarize(checkedOrder(await getItem(`USER#${ownerId}`, `ORDER#${orderId}`), ownerId, orderId));
		})),
		nextCursor: page.LastEvaluatedKey ? cursorFor(page.LastEvaluatedKey["pk"], page.LastEvaluatedKey["sk"]) : null
	};
}
async function updateOrderStatus(input) {
	const actor = await requireAdmin();
	const key = {
		pk: `USER#${input.ownerId}`,
		sk: `ORDER#${input.orderId}`
	};
	const order = checkedOrder(await getItem(key.pk, key.sk), input.ownerId, input.orderId);
	if (order.status === input.status) return summarize(order);
	if (order.status !== input.expectedStatus) throw new HttpError(409, "This order changed elsewhere. Refresh it before changing its status.", "ORDER_STATUS_CONFLICT");
	const releasing = input.status === "cancelled";
	const reserving = order.status === "cancelled";
	const quantities = /* @__PURE__ */ new Map();
	if (releasing || reserving) {
		if (!Array.isArray(order.items) || order.items.length < 1 || order.items.length > 25) throw new HttpError(409, "This order has invalid inventory lines. Contact the store operator.");
		for (const item of order.items) {
			if (!idSchema.safeParse(item.productId).success || !Number.isSafeInteger(item.quantity) || item.quantity < 1 || item.quantity > 99) throw new HttpError(409, "This order has invalid inventory quantities. Contact the store operator.");
			quantities.set(item.productId, (quantities.get(item.productId) ?? 0) + item.quantity);
		}
	}
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const changes = [{ Update: {
		TableName: table,
		Key: key,
		UpdateExpression: `SET #data.#status = :next, statusUpdatedAt = :now, statusUpdatedBy = :actor${input.status === "delivered" ? ", deliveredAt = :now" : ""}`,
		ConditionExpression: "#entity = :order AND #data.#status = :old AND #data = :snapshot",
		ExpressionAttributeNames: {
			"#entity": "entity",
			"#data": "data",
			"#status": "status"
		},
		ExpressionAttributeValues: {
			":order": "order",
			":next": input.status,
			":old": order.status,
			":snapshot": order,
			":now": now,
			":actor": actor.id
		}
	} }];
	for (const [productId, quantity] of quantities) changes.push({ Update: {
		TableName: table,
		Key: {
			pk: "CATALOG",
			sk: `PRODUCT#${productId}`
		},
		UpdateExpression: `SET #data.#stock = #data.#stock ${releasing ? "+" : "-"} :quantity`,
		ConditionExpression: `attribute_exists(pk) AND #data.#stock >= ${reserving ? ":quantity" : ":zero"}`,
		ExpressionAttributeNames: {
			"#data": "data",
			"#stock": "stock"
		},
		ExpressionAttributeValues: {
			":quantity": quantity,
			...reserving ? {} : { ":zero": 0 }
		}
	} });
	try {
		await db.send(new TransactWriteCommand({ TransactItems: changes }));
	} catch (error) {
		if (!(error instanceof TransactionCanceledException)) throw error;
		const current = checkedOrder(await getItem(key.pk, key.sk), input.ownerId, input.orderId);
		if (current.status === input.status) return summarize(current);
		if (current.status !== order.status || error.CancellationReasons?.[0]?.Code === "ConditionalCheckFailed") throw new HttpError(409, "This order changed elsewhere. Refresh it before changing its status.", "ORDER_STATUS_CONFLICT");
		if (error.CancellationReasons?.slice(1).some((reason) => reason.Code === "ConditionalCheckFailed")) throw new HttpError(409, reserving ? "Cannot reopen this order: a product is missing or does not have enough stock. No status or inventory was changed." : "Cannot cancel this order: a product is missing or its stock is invalid. No status or inventory was changed.", "ORDER_INVENTORY_CONFLICT");
		throw new HttpError(409, "This order or its stock is being updated. Refresh and try again.", "ORDER_STATUS_CONFLICT");
	}
	return summarize({
		...order,
		status: input.status
	});
}
var adminAccessFn_createServerFn_handler = createServerRpc({
	id: "0dbfb6c04afd9f775feff16148bbecddf73e66fd4c5531d8a11f4a526fcc4daa",
	name: "adminAccessFn",
	filename: "src/functions/admin.functions.ts"
}, (opts) => adminAccessFn.__executeServer(opts));
var adminAccessFn = createServerFn({ method: "POST" }).handler(adminAccessFn_createServerFn_handler, () => rpc(access));
var adminProductsFn_createServerFn_handler = createServerRpc({
	id: "375aad0f59e4678193d42aba4caa5dd0d2b5dbb7e59bb4bb1a9ec3a4923fdfe3",
	name: "adminProductsFn",
	filename: "src/functions/admin.functions.ts"
}, (opts) => adminProductsFn.__executeServer(opts));
var adminProductsFn = createServerFn({ method: "POST" }).handler(adminProductsFn_createServerFn_handler, () => rpc(listProducts));
var adminUploadFn_createServerFn_handler = createServerRpc({
	id: "3dd07b1384833b2326f02d69359d8ee9fabd0cf64c982d4219a3d4e9a5cbfb82",
	name: "adminUploadFn",
	filename: "src/functions/admin.functions.ts"
}, (opts) => adminUploadFn.__executeServer(opts));
var adminUploadFn = createServerFn({ method: "POST" }).validator(productUploadSchema).handler(adminUploadFn_createServerFn_handler, ({ data }) => rpc(() => uploadImage(data)));
var adminCreateProductFn_createServerFn_handler = createServerRpc({
	id: "597b72d7fbb1489ac3a1b100e79f400a43eb2c47ecb3b4e28bdb7da9f7494a01",
	name: "adminCreateProductFn",
	filename: "src/functions/admin.functions.ts"
}, (opts) => adminCreateProductFn.__executeServer(opts));
var adminCreateProductFn = createServerFn({ method: "POST" }).validator(createProductSchema).handler(adminCreateProductFn_createServerFn_handler, ({ data }) => rpc(() => createProduct(data)));
var adminUpdatePriceFn_createServerFn_handler = createServerRpc({
	id: "5ec8c2c82c18c3799ecfde6330cb93d5a563e19331473b0360fbf2415acdf92a",
	name: "adminUpdatePriceFn",
	filename: "src/functions/admin.functions.ts"
}, (opts) => adminUpdatePriceFn.__executeServer(opts));
var adminUpdatePriceFn = createServerFn({ method: "POST" }).validator(updatePriceSchema).handler(adminUpdatePriceFn_createServerFn_handler, ({ data }) => rpc(() => updatePrice(data)));
var adminOrdersFn_createServerFn_handler = createServerRpc({
	id: "42d9c54e7d83fc2a96f0316cfa4b4c9a3e93618c2c475120afca32d684091b6f",
	name: "adminOrdersFn",
	filename: "src/functions/admin.functions.ts"
}, (opts) => adminOrdersFn.__executeServer(opts));
var adminOrdersFn = createServerFn({ method: "POST" }).validator(adminOrdersSchema).handler(adminOrdersFn_createServerFn_handler, ({ data }) => rpc(() => listOrders(data)));
var adminOrderStatusFn_createServerFn_handler = createServerRpc({
	id: "27b3460dc2631c782a9a3b328210fbf1a89b24dcb9f8ef448313e39f7e456422",
	name: "adminOrderStatusFn",
	filename: "src/functions/admin.functions.ts"
}, (opts) => adminOrderStatusFn.__executeServer(opts));
var adminOrderStatusFn = createServerFn({ method: "POST" }).validator(adminOrderStatusSchema).handler(adminOrderStatusFn_createServerFn_handler, ({ data }) => rpc(() => updateOrderStatus(data)));
export { adminAccessFn_createServerFn_handler, adminCreateProductFn_createServerFn_handler, adminOrderStatusFn_createServerFn_handler, adminOrdersFn_createServerFn_handler, adminProductsFn_createServerFn_handler, adminUpdatePriceFn_createServerFn_handler, adminUploadFn_createServerFn_handler };
