import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as productsFn, s as suggestionsFn } from "./catalogue.functions-DBDE1qea.mjs";
import { l as SearchX } from "../_libs/lucide-react.mjs";
import { N as unwrap, a as Route$3, l as EmptyState, m as SearchBar } from "./router-Couj4mWN.mjs";
import { t as ProductGrid } from "./ProductGrid-34LfjVZO.mjs";
// node_modules/.nitro/vite/services/ssr/assets/search-DEqdyrcR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var searchService = {
	search: (term) => unwrap(() => productsFn({ data: { search: term } }), false),
	suggest: (term) => unwrap(() => suggestionsFn({ data: term }), false)
};
function SearchPage() {
	const { q } = Route$3.useSearch();
	const [results, setResults] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setLoading(true);
		searchService.search(q).then((r) => !cancelled && setResults(r)).catch((e) => !cancelled && setError(e instanceof Error ? e.message : "Search failed")).finally(() => !cancelled && setLoading(false));
		return () => {
			cancelled = true;
		};
	}, [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold sm:text-3xl",
				children: q ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Search results for “",
					q,
					"”"
				] }) : "Search"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				"aria-live": "polite",
				children: loading ? "Searching…" : `${results.length} ${results.length === 1 ? "result" : "results"}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 max-w-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, { initialValue: q })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: !loading && !error && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchX, {
						className: "h-5 w-5",
						"aria-hidden": true
					}),
					title: `No matches for "${q}"`,
					description: "Check the spelling, try a broader term, or browse the full catalogue.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/shop",
							children: "Browse all products"
						})
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, {
					products: results,
					loading,
					error
				})
			})
		]
	});
}
export { SearchPage as component };
