import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as cn, t as Button } from "./button-DUF1Y1qY.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as reviewSchema, w as idSchema } from "./ssr.mjs";
import { r as createServerFn } from "./server-CiMkYVYO.mjs";
import { o as createSsrRpc, s as customerMiddleware } from "./customer.functions-BcXykFYC.mjs";
import { t as productService } from "./awsProductService-VU2HHCXI.mjs";
import { a as Star, h as Heart, s as ShoppingBag } from "../_libs/lucide-react.mjs";
import { A as ServiceError, C as discountPercent, E as useAuth, M as isCurrentAuthGeneration, N as unwrap, S as currency, T as stockLabel, b as QuantitySelector, f as LoadingState, j as authGeneration, n as Route, p as useWishlist, u as ErrorState, w as formatDate, x as useCart } from "./router-Couj4mWN.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-layOOVP4.mjs";
import { t as Input } from "./input-BbR4Ntsy.mjs";
import { t as Label } from "./label-Cvda4mU8.mjs";
import { t as Textarea } from "./textarea-CKL1fZto.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-IldXxGe8.mjs";
import { t as ProductGrid } from "./ProductGrid-34LfjVZO.mjs";
// node_modules/.nitro/vite/services/ssr/assets/product._id-AW1Bkj_I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PriceDisplay({ price, originalPrice, size = "md", className }) {
	const pct = originalPrice ? discountPercent(price, originalPrice) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-wrap items-baseline gap-2", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-display font-semibold tracking-tight", {
				sm: "text-sm",
				md: "text-lg",
				lg: "text-3xl"
			}[size]),
			children: currency(price)
		}), pct > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted-foreground line-through",
			children: currency(originalPrice)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-sm text-success",
			children: [
				"Save ",
				pct,
				"%"
			]
		})] })]
	});
}
function RatingStars({ rating, reviewCount, size = "sm", className }) {
	const px = size === "sm" ? "h-3.5 w-3.5" : "h-4.5 w-4.5";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-1.5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-0.5",
				"aria-hidden": true,
				children: [
					1,
					2,
					3,
					4,
					5
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn(px, i <= Math.round(rating) ? "fill-highlight text-highlight" : "text-border") }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm text-muted-foreground",
				children: [rating.toFixed(1), reviewCount !== void 0 && ` (${reviewCount.toLocaleString()})`]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: `Rated ${rating} out of 5${reviewCount ? ` from ${reviewCount} reviews` : ""}`
			})
		]
	});
}
var reviewEligibilityFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(idSchema).handler(createSsrRpc("0813518870d3af07768222d322fcdc31956f17f836e9007896dd8b05ea87f553"));
var submitReviewFn = createServerFn({ method: "POST" }).middleware([customerMiddleware]).validator(reviewSchema).handler(createSsrRpc("b71b19576944faac5f2f200f9265ef79c28afd5175bb6fee59b5b305655677db"));
var reviewService = {
	eligibility: (productId) => unwrap(() => reviewEligibilityFn({ data: productId })),
	submit: (data) => unwrap(() => submitReviewFn({ data }))
};
function ProductReviewForm({ productId, onSubmitted }) {
	const { user, loading } = useAuth();
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "status",
		className: "mb-6 text-sm",
		children: "Checking sign-in…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mb-6 bg-surface p-6 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/login",
			className: "underline underline-offset-4",
			children: "Sign in"
		}), " to review a product you ordered and received."]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedInReviewForm, {
		productId,
		onSubmitted
	}, `${user.id}:${productId}`);
}
function SignedInReviewForm({ productId, onSubmitted }) {
	const [eligibility, setEligibility] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [retry, setRetry] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [rating, setRating] = (0, import_react.useState)("");
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const active = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		active.current = true;
		return () => {
			active.current = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setEligibility(null);
		setError("");
		reviewService.eligibility(productId).then((value) => {
			if (!cancelled) setEligibility(value);
		}).catch((error) => {
			if (!cancelled) setError(error instanceof Error ? error.message : "Could not check review eligibility.");
		});
		return () => {
			cancelled = true;
		};
	}, [productId, retry]);
	const submit = async (event) => {
		event.preventDefault();
		setError("");
		const form = new FormData(event.currentTarget);
		const parsed = reviewSchema.safeParse({
			productId,
			rating: Number(rating),
			title: form.get("title"),
			body: form.get("body")
		});
		if (!parsed.success) {
			setError(parsed.error.issues.map((issue) => issue.message).join(" "));
			return;
		}
		const generation = authGeneration();
		setBusy(true);
		try {
			const result = await reviewService.submit(parsed.data);
			if (active.current && isCurrentAuthGeneration(generation)) {
				setEligibility({
					canReview: false,
					reason: "You have already reviewed this product.",
					review: result.review
				});
				setSubmitted(true);
				onSubmitted(result);
			}
		} catch (error) {
			if (active.current && isCurrentAuthGeneration(generation)) {
				if (error instanceof ServiceError && error.code === "ALREADY_REVIEWED") setRetry((value) => value + 1);
				else setError(error instanceof Error ? error.message : "Could not save your review.");
			}
		} finally {
			if (active.current && isCurrentAuthGeneration(generation)) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-6 max-w-3xl bg-surface p-6",
		"aria-labelledby": "write-review",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "write-review",
				className: "text-lg font-semibold",
				children: "Your review"
			}),
			!eligibility && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "mt-3 text-sm",
				children: "Checking your delivered purchases…"
			}),
			eligibility && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "mt-3 text-sm",
				children: submitted ? "Thank you. Your verified purchase review is published." : eligibility.reason
			}),
			eligibility?.review && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						eligibility.review.rating,
						"/5 · ",
						eligibility.review.title
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 whitespace-pre-wrap",
					children: eligibility.review.body
				})]
			}),
			eligibility?.canReview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => void submit(event),
				className: "mt-5 space-y-4",
				"aria-busy": busy,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						disabled: busy,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-xs space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "review-rating",
									children: "Rating"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: rating,
									onValueChange: setRating,
									required: true,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										id: "review-rating",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a rating" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
										5,
										4,
										3,
										2,
										1
									].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(value),
										children: [value, " out of 5"]
									}, value)) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "review-title",
									children: "Title"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "review-title",
									name: "title",
									maxLength: 120,
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "review-body",
									children: "Your experience"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "review-body",
									name: "body",
									rows: 4,
									maxLength: 2e3,
									required: true
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "One review per product. Your account name is shown publicly, not your email or customer ID."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						children: busy ? "Publishing…" : "Publish review"
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-destructive",
					children: error
				}), !eligibility && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "mt-3",
					onClick: () => setRetry((value) => value + 1),
					children: "Check again"
				})]
			})
		]
	});
}
function ProductPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const { add, setDrawerOpen } = useCart();
	const wishlist = useWishlist();
	const [product, setProduct] = (0, import_react.useState)(null);
	const [related, setRelated] = (0, import_react.useState)([]);
	const [reviews, setReviews] = (0, import_react.useState)([]);
	const [image, setImage] = (0, import_react.useState)(0);
	const [qty, setQty] = (0, import_react.useState)(1);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setLoading(true);
		setError(null);
		setImage(0);
		setQty(1);
		productService.getById(id).then(async (p) => {
			if (cancelled) return;
			if (p) {
				const [related, reviews] = await Promise.all([productService.getRelated(p.id, 4), productService.getReviews(p.id)]);
				if (cancelled) return;
				setRelated(related);
				setReviews(reviews);
			}
			if (!cancelled) setProduct(p);
		}).catch((e) => !cancelled && setError(e instanceof Error ? e.message : "Failed to load product")).finally(() => !cancelled && setLoading(false));
		return () => {
			cancelled = true;
		};
	}, [id]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading product" });
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: error })
	});
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold",
			children: "Product not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/shop",
				children: "Back to shop"
			})
		})]
	});
	const outOfStock = product.stock === 0;
	const buyNow = async () => {
		if (!await add(product.id, qty)) return;
		setDrawerOpen(false);
		navigate({ to: "/checkout" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container pb-24 pt-8 sm:pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Breadcrumb",
				className: "mb-8 text-[14px] text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-primary",
						children: "Home"
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "/"
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						className: "hover:text-primary",
						children: "Shop"
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "/"
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: product.name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-clip bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.images[image],
						alt: product.name,
						width: 1200,
						height: 1200,
						className: "aspect-square w-full object-cover"
					}, image)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex gap-3",
					children: product.images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setImage(i),
						"aria-label": `View image ${i + 1}`,
						"aria-current": i === image,
						className: cn("h-20 w-20 overflow-hidden transition-smooth", i === image ? "outline-2 outline-offset-4 outline-primary" : "opacity-65 hover:opacity-100"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src,
							alt: "",
							loading: "lazy",
							className: "h-full w-full object-cover"
						})
					}, src))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-[32px] font-medium leading-[1.1] sm:text-5xl",
						children: product.name.replace("Wireless Noise Cancelling", "Noise-cancelling")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted-foreground",
						children: product.category
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingStars, {
							rating: product.rating,
							reviewCount: product.reviewCount,
							size: "md"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceDisplay, {
							price: product.price,
							originalPrice: product.originalPrice,
							size: "lg"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-3 text-sm font-medium", outOfStock ? "text-destructive" : product.stock <= 10 ? "text-warning" : "text-success"),
						children: stockLabel(product.stock)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-2 text-base",
						children: product.highlights.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: h }, h))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuantitySelector, {
								value: qty,
								max: Math.max(product.stock, 1),
								onChange: setQty
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								disabled: outOfStock,
								onClick: () => void add(product.id, qty),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { "aria-hidden": true }), " Add to bag"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								disabled: outOfStock,
								onClick: () => void buyNow(),
								children: "Buy now"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "icon",
								"aria-label": "Toggle wishlist",
								"aria-pressed": wishlist.has(product.id),
								onClick: () => wishlist.toggle(product.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
									className: cn(wishlist.has(product.id) && "fill-destructive text-destructive"),
									"aria-hidden": true
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 space-y-5 bg-surface p-6",
						children: [{
							title: "Shipping",
							body: "Free standard shipping over ₹20,000."
						}, {
							title: "Delivery options",
							body: "Choose standard or express at checkout."
						}].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-medium",
							children: b.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: b.body
						})] }, b.title))
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "description",
				className: "mt-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "description",
							children: "Description"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "specifications",
							children: "Specifications"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "reviews",
							children: "Reviews"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "description",
						className: "max-w-3xl pt-6 text-base leading-relaxed",
						children: product.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "specifications",
						className: "pt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "max-w-2xl divide-y divide-border rounded-xl border border-border",
							children: Object.entries(product.specifications).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-4 px-4 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium",
									children: v
								})]
							}, k))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "reviews",
						className: "pt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductReviewForm, {
								productId: product.id,
								onSubmitted: ({ review, rating, reviewCount }) => {
									setReviews((current) => [review, ...current.filter((item) => item.id !== review.id)]);
									setProduct((current) => current?.id === review.productId ? {
										...current,
										rating,
										reviewCount
									} : current);
								}
							}),
							!reviews.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-5 text-sm text-muted-foreground",
								children: "No reviews yet."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "max-w-3xl space-y-5",
								children: reviews.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "bg-surface p-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-semibold",
												children: r.author
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted-foreground",
												children: formatDate(r.createdAt)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingStars, { rating: r.rating }), r.verifiedPurchase === true && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-xs text-muted-foreground",
												children: "Verified purchase"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 text-sm font-semibold",
											children: r.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-muted-foreground",
											children: r.body
										})
									]
								}, r.id))
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-medium sm:text-4xl",
					children: "You might also like"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: related })
				})]
			})
		]
	});
}
export { ProductPage as component };
