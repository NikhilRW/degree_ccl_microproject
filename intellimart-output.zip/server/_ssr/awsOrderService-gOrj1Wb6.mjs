import { a as createOrderFn, c as orderFn, l as ordersFn, t as cancelOrderFn } from "./customer.functions-BcXykFYC.mjs";
import { A as ServiceError, N as unwrap } from "./router-Couj4mWN.mjs";
// node_modules/.nitro/vite/services/ssr/assets/awsOrderService-gOrj1Wb6.js
var orderService = {
	list: () => unwrap(() => ordersFn()),
	async getById(id) {
		try {
			return await unwrap(() => orderFn({ data: id }));
		} catch (error) {
			if (error instanceof ServiceError && error.status === 404) return null;
			throw error;
		}
	},
	create: (input) => unwrap(() => createOrderFn({ data: input })),
	cancel: (id) => unwrap(() => cancelOrderFn({ data: id }))
};
export { orderService as t };
