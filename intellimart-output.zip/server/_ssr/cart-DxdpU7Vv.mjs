import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as ShoppingBag } from "../_libs/lucide-react.mjs";
import { S as currency, c as CartItemRow, f as LoadingState, l as EmptyState, x as useCart } from "./router-Couj4mWN.mjs";
// node_modules/.nitro/vite/services/ssr/assets/cart-DxdpU7Vv.js
var import_jsx_runtime = require_jsx_runtime();
function CartPage() {
	const { cart, loading, totals } = useCart();
	const active = cart.items.filter((i) => !i.savedForLater);
	const saved = cart.items.filter((i) => i.savedForLater);
	const t = totals();
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading your cart" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container pb-24 pt-10 sm:pt-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl font-medium sm:text-7xl",
			children: "Your bag"
		}), active.length === 0 && saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
					className: "h-5 w-5",
					"aria-hidden": true
				}),
				title: "Your cart is empty",
				description: "Once you add products they'll show up here.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						children: "Continue shopping"
					})
				})
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-10 lg:grid-cols-[1fr_340px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5",
				children: [active.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartItemRow, { item: i }, i.productId)), active.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-sm text-muted-foreground",
					children: "No active items."
				})]
			}), saved.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Saved for later"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-5",
					children: saved.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartItemRow, { item: i }, i.productId))
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "lg:sticky lg:top-24 lg:self-start",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-surface p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-semibold",
							children: "Order summary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-5 space-y-3 text-sm",
							children: [[
								["Subtotal", currency(t.subtotal)],
								["Discount applied", `−${currency(t.discount)}`],
								["Shipping", t.shipping === 0 ? "Free" : currency(t.shipping)],
								["Tax (18%)", currency(t.tax)]
							].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums",
									children: v
								})]
							}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between pt-4 text-lg font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums",
									children: currency(t.total)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "hero",
								size: "lg",
								disabled: active.length === 0,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/checkout",
									children: "Proceed to checkout"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/shop",
									children: "Continue shopping"
								})
							})]
						})
					]
				})
			})]
		})]
	});
}
export { CartPage as component };
