import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-DUF1Y1qY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as productService } from "./awsProductService-VU2HHCXI.mjs";
import { C as discountPercent } from "./router-Couj4mWN.mjs";
import { t as ProductGrid } from "./ProductGrid-34LfjVZO.mjs";
// node_modules/.nitro/vite/services/ssr/assets/deals-C9d-Xmm7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DealsPage() {
	const [products, setProducts] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		productService.list().then((list) => setProducts(list.filter((p) => p.originalPrice > p.price).sort((a, b) => discountPercent(b.price, b.originalPrice) - discountPercent(a.price, a.originalPrice)))).catch((e) => setError(e instanceof Error ? e.message : "Failed to load deals")).finally(() => setLoading(false));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-ink text-ink-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "site-container flex flex-wrap items-end justify-between gap-8 py-16 sm:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl font-medium sm:text-7xl",
				children: "The good deals"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-lg text-base",
				children: "Good finds. Even better prices. Biggest savings first."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "onDark",
				size: "xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					children: "Browse everything"
				})
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "site-container py-16 sm:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, {
			products,
			loading,
			error,
			emptyTitle: "No active deals right now"
		})
	})] });
}
export { DealsPage as component };
