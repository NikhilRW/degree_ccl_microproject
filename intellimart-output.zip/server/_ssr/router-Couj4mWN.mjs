import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, t as Button } from "./button-DUF1Y1qY.mjs";
import { _ as useNavigate, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as signupSchema, N as resetSchema, S as emailSchema, T as loginSchema, b as confirmationSchema } from "./ssr.mjs";
import { d as __exportAll, r as createServerFn } from "./server-CiMkYVYO.mjs";
import { i as changeWishlistFn, n as cartFn, o as createSsrRpc, r as changeCartFn, u as wishlistFn } from "./customer.functions-BcXykFYC.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as calculateCartTotals } from "./cartTotals-tCk3LwGR.mjs";
import { c as Search, d as Plus, f as PackageOpen, i as Trash2, m as Menu, n as User, p as Minus, r as TriangleAlert, s as ShoppingBag, t as X, u as RefreshCw, x as Bookmark } from "../_libs/lucide-react.mjs";
import { t as getRuntimeConfig } from "./runtime.server-Ct22IyCc.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/rpc-DqCMaDgC.js
var ServiceError = class extends Error {
	status;
	code;
	constructor(message, status, code) {
		super(message);
		this.status = status;
		this.code = code;
	}
};
function clientAuthState() {
	if (typeof window === "undefined") return void 0;
	const clientWindow = window;
	return clientWindow.__intellimartAuthState ??= {
		generation: 0,
		transitioning: false,
		invalidated: false
	};
}
var authGeneration = () => clientAuthState()?.generation;
var isCurrentAuthGeneration = (generation) => generation === authGeneration();
function beginAuthTransition() {
	const state = clientAuthState();
	if (!state) return void 0;
	state.transitioning = true;
	state.invalidated = false;
	return ++state.generation;
}
function finishAuthTransition(generation) {
	const state = clientAuthState();
	if (!state) return true;
	if (state.generation !== generation) return false;
	state.generation++;
	state.transitioning = false;
	state.invalidated = false;
	return true;
}
function invalidateSession(generation) {
	const state = clientAuthState();
	if (!state || state.generation !== generation || state.transitioning || state.invalidated) return;
	state.invalidated = true;
	state.generation++;
	window.dispatchEvent(new CustomEvent("intellimart:signed-out", { detail: state.generation }));
}
async function unwrap(invoke, sessionScoped = true) {
	const generation = authGeneration();
	const response = await invoke();
	if (sessionScoped && (!isCurrentAuthGeneration(generation) || clientAuthState()?.transitioning)) throw new ServiceError("Your account changed while the request was in progress.", 409, "AUTH_CHANGED");
	if (!response.ok) {
		if (sessionScoped && response.error.status === 401) invalidateSession(generation);
		throw new ServiceError(response.error.message, response.error.status, response.error.code);
	}
	return response.value;
}
// node_modules/.nitro/vite/services/ssr/assets/auth.functions-C5yLlkOw.js
var signInFn = createServerFn({ method: "POST" }).validator(loginSchema).handler(createSsrRpc("c17e4ea028b58d83775aa13c11a0817d139052c5f9efaef1f9091fae641f89fb"));
var signUpFn = createServerFn({ method: "POST" }).validator(signupSchema).handler(createSsrRpc("7f725e2091a0739c15e2abad26cebe0999b608f23b0115b08ae2cad015ceda8f"));
var confirmSignUpFn = createServerFn({ method: "POST" }).validator(confirmationSchema).handler(createSsrRpc("5073a6da6d1f4d3dda3712b9fee30a94f595f1b96b000e52c9f4a271b8c6b3ff"));
var resendCodeFn = createServerFn({ method: "POST" }).validator(emailSchema).handler(createSsrRpc("61d889fa5b951751adf2d7bfc5ed8828432ed2285e929c18819c01d8c48a5a71"));
var forgotPasswordFn = createServerFn({ method: "POST" }).validator(emailSchema).handler(createSsrRpc("079a1390262f9d9bb31158eb7e0b161e570b47e67afe28755156446b7dc8b305"));
var resetPasswordFn = createServerFn({ method: "POST" }).validator(resetSchema).handler(createSsrRpc("042fe8bef62a4cae11fe757be8e044b8a3e4027bd796123dba5e5f3350792d78"));
var signOutFn = createServerFn({ method: "POST" }).handler(createSsrRpc("abd88ab174072b5cd556ef06e35ac1a6e5c1321022cd1903d7994ffc2921068f"));
var sessionFn = createServerFn({ method: "POST" }).handler(createSsrRpc("ed7f103ceadee95beb54a0b0944322afe8f88b91bed5dfe9981d0c4f26ccdd76"));
// node_modules/.nitro/vite/services/ssr/assets/awsAuthService-B6U3EqQD.js
var authService = {
	signIn: (email, password) => unwrap(() => signInFn({ data: {
		email,
		password
	} }), false),
	async signUp(name, email, password) {
		await unwrap(() => signUpFn({ data: {
			name,
			email,
			password
		} }), false);
	},
	async confirmSignUp(email, code) {
		await unwrap(() => confirmSignUpFn({ data: {
			email,
			code
		} }), false);
	},
	async resendConfirmationCode(email) {
		await unwrap(() => resendCodeFn({ data: { email } }), false);
	},
	async signOut() {
		await unwrap(() => signOutFn(), false);
	},
	async getCurrentUser() {
		return (await unwrap(() => sessionFn()))?.user ?? null;
	},
	getSession: () => unwrap(() => sessionFn()),
	async requestPasswordReset(email) {
		await unwrap(() => forgotPasswordFn({ data: { email } }), false);
	},
	async confirmPasswordReset(email, code, password) {
		await unwrap(() => resetPasswordFn({ data: {
			email,
			code,
			password
		} }), false);
	}
};
// node_modules/.nitro/vite/services/ssr/assets/useAuth-DlYb6k1G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AuthContext = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let active = true;
		const generation = authGeneration();
		const onSession = (event) => {
			if (!(event instanceof CustomEvent)) return;
			const invalidatedGeneration = event.detail;
			if (active && typeof invalidatedGeneration === "number" && isCurrentAuthGeneration(invalidatedGeneration)) {
				setUser(null);
				setLoading(false);
			}
		};
		window.addEventListener("intellimart:signed-out", onSession);
		authService.getCurrentUser().then((value) => {
			if (active && isCurrentAuthGeneration(generation)) setUser(value);
		}).catch((error) => {
			if (active && isCurrentAuthGeneration(generation)) toast.error(error instanceof Error ? error.message : "Could not restore your session.");
		}).finally(() => {
			if (active && isCurrentAuthGeneration(generation)) setLoading(false);
		});
		return () => {
			active = false;
			window.removeEventListener("intellimart:signed-out", onSession);
		};
	}, []);
	const signIn = (0, import_react.useCallback)(async (email, password) => {
		const generation = beginAuthTransition();
		setLoading(true);
		try {
			const session = await authService.signIn(email, password);
			if (finishAuthTransition(generation)) {
				setUser(session.user);
				setLoading(false);
			}
		} catch (error) {
			if (finishAuthTransition(generation)) setLoading(false);
			throw error;
		}
	}, []);
	const signUp = (0, import_react.useCallback)(async (name, email, password) => {
		await authService.signUp(name, email, password);
	}, []);
	const signOut = (0, import_react.useCallback)(async () => {
		const generation = beginAuthTransition();
		setUser(null);
		setLoading(true);
		try {
			await authService.signOut();
		} catch (error) {
			if (isCurrentAuthGeneration(generation)) toast.error(error instanceof Error ? error.message : "Could not revoke your session.");
		} finally {
			if (finishAuthTransition(generation)) setLoading(false);
		}
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		user,
		loading,
		signIn,
		signUp,
		signOut
	}), [
		user,
		loading,
		signIn,
		signUp,
		signOut
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value,
		children
	});
}
function useAuth() {
	const value = (0, import_react.useContext)(AuthContext);
	if (!value) throw new Error("useAuth must be used inside AuthProvider");
	return value;
}
// node_modules/.nitro/vite/services/ssr/assets/format-DNVW_4F_.js
var currency = (value) => new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	minimumFractionDigits: 0,
	maximumFractionDigits: 2
}).format(value);
var discountPercent = (price, original) => original > price ? Math.round((original - price) / original * 100) : 0;
var formatDate = (iso) => new Date(iso).toLocaleDateString("en-IN", {
	day: "numeric",
	month: "short",
	year: "numeric"
});
var stockLabel = (stock) => stock === 0 ? "Out of stock" : stock <= 10 ? `Only ${stock} left` : "In stock";
// node_modules/.nitro/vite/services/ssr/assets/useCart-DAs1iZUN.js
var cartService = {
	getCart: () => unwrap(() => cartFn()),
	addItem: (productId, quantity = 1) => unwrap(() => changeCartFn({ data: {
		action: "add",
		productId,
		quantity
	} })),
	updateQuantity: (productId, quantity) => unwrap(() => changeCartFn({ data: {
		action: "quantity",
		productId,
		quantity
	} })),
	removeItem: (productId) => unwrap(() => changeCartFn({ data: {
		action: "remove",
		productId
	} })),
	toggleSaveForLater: (productId) => unwrap(() => changeCartFn({ data: {
		action: "saved",
		productId
	} })),
	clear: () => unwrap(() => changeCartFn({ data: { action: "clear" } })),
	calculateTotals: calculateCartTotals
};
var CartContext = (0, import_react.createContext)(null);
var empty = {
	items: [],
	updatedAt: ""
};
function CartProvider({ children }) {
	const { user, loading: authLoading } = useAuth();
	const navigate = useNavigate();
	const [cart, setCart] = (0, import_react.useState)(empty);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [drawerOpen, setDrawerOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (authLoading) return;
		let cancelled = false;
		const generation = authGeneration();
		setCart(empty);
		setDrawerOpen(false);
		if (!user) {
			setLoading(false);
			return;
		}
		setLoading(true);
		cartService.getCart().then((value) => {
			if (!cancelled && isCurrentAuthGeneration(generation)) setCart(value);
		}).catch((error) => {
			if (!cancelled && isCurrentAuthGeneration(generation)) toast.error(error instanceof Error ? error.message : "Could not load your bag.");
		}).finally(() => {
			if (!cancelled && isCurrentAuthGeneration(generation)) setLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, [user?.id, authLoading]);
	const mutate = (0, import_react.useCallback)(async (operation, message) => {
		if (!user) {
			toast("Sign in to use your shopping bag.");
			navigate({ to: "/login" });
			return false;
		}
		const generation = authGeneration();
		try {
			const value = await operation();
			if (!isCurrentAuthGeneration(generation)) return false;
			setCart(value);
			if (message) toast.success(message);
			return true;
		} catch (error) {
			if (isCurrentAuthGeneration(generation)) toast.error(error instanceof Error ? error.message : "Could not update your bag.");
			return false;
		}
	}, [user?.id, navigate]);
	const add = (0, import_react.useCallback)(async (id, quantity = 1) => {
		const success = await mutate(() => cartService.addItem(id, quantity), "Added to bag");
		if (success) setDrawerOpen(true);
		return success;
	}, [mutate]);
	const update = (0, import_react.useCallback)(async (id, quantity) => {
		await mutate(() => cartService.updateQuantity(id, quantity));
	}, [mutate]);
	const remove = (0, import_react.useCallback)(async (id) => {
		await mutate(() => cartService.removeItem(id), "Removed from bag");
	}, [mutate]);
	const toggleSaveForLater = (0, import_react.useCallback)(async (id) => {
		await mutate(() => cartService.toggleSaveForLater(id));
	}, [mutate]);
	const clear = (0, import_react.useCallback)(async () => {
		await mutate(() => cartService.clear());
	}, [mutate]);
	const refresh = (0, import_react.useCallback)(async () => {
		await mutate(() => cartService.getCart());
	}, [mutate]);
	const value = (0, import_react.useMemo)(() => ({
		cart,
		loading,
		count: cart.items.filter((item) => !item.savedForLater).reduce((sum, item) => sum + item.quantity, 0),
		add,
		update,
		remove,
		toggleSaveForLater,
		clear,
		refresh,
		totals: (delivery = "standard") => cartService.calculateTotals(cart, delivery),
		drawerOpen,
		setDrawerOpen
	}), [
		cart,
		loading,
		add,
		update,
		remove,
		toggleSaveForLater,
		clear,
		refresh,
		drawerOpen
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartContext.Provider, {
		value,
		children
	});
}
function useCart() {
	const value = (0, import_react.useContext)(CartContext);
	if (!value) throw new Error("useCart must be used inside CartProvider");
	return value;
}
// node_modules/.nitro/vite/services/ssr/assets/QuantitySelector-CaDudEDT.js
function QuantitySelector({ value, onChange, max = 99, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("inline-flex items-center rounded-lg border border-border bg-card", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Decrease quantity",
				className: "flex h-9 w-9 items-center justify-center rounded-l-lg text-muted-foreground transition-smooth hover:bg-surface hover:text-foreground disabled:opacity-40",
				onClick: () => onChange(Math.max(1, value - 1)),
				disabled: value <= 1,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
					className: "h-4 w-4",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-live": "polite",
				className: "w-10 text-center text-sm font-semibold tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Increase quantity",
				className: "flex h-9 w-9 items-center justify-center rounded-r-lg text-muted-foreground transition-smooth hover:bg-surface hover:text-foreground disabled:opacity-40",
				onClick: () => onChange(Math.min(max, value + 1)),
				disabled: value >= max,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "h-4 w-4",
					"aria-hidden": true
				})
			})
		]
	});
}
// node_modules/.nitro/vite/services/ssr/assets/router-Couj4mWN.js
var styles_default = "/assets/styles-B_DuRwGP.css";
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function SearchBar({ className, initialValue = "", autoFocus = false }) {
	const id = (0, import_react.useId)();
	const [value, setValue] = (0, import_react.useState)(initialValue);
	const navigate = useNavigate();
	const submit = (e) => {
		e.preventDefault();
		const q = value.trim();
		if (!q) return;
		navigate({
			to: "/search",
			search: { q }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		role: "search",
		onSubmit: submit,
		className: cn("search-form", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: id,
				className: "sr-only",
				children: "Search products"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "h-4 w-4 shrink-0",
				strokeWidth: 1.5,
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				type: "search",
				value,
				onChange: (e) => setValue(e.target.value),
				placeholder: "Find your next favourite",
				autoFocus
			})
		]
	});
}
function Logo({ className, onDark = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: cn("brand-wordmark", onDark && "text-ink-foreground", className),
		"aria-label": "IntelliMart home",
		children: "intellimart"
	});
}
var wishlistService = {
	list: () => unwrap(() => wishlistFn()),
	save: (productId) => unwrap(() => changeWishlistFn({ data: {
		productId,
		remove: false
	} })),
	remove: (productId) => unwrap(() => changeWishlistFn({ data: {
		productId,
		remove: true
	} }))
};
var WishlistContext = (0, import_react.createContext)(null);
function WishlistProvider({ children }) {
	const { user, loading } = useAuth();
	const navigate = useNavigate();
	const [items, setItems] = (0, import_react.useState)([]);
	const pending = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const generation = authGeneration();
		pending.current = /* @__PURE__ */ new Set();
		setItems([]);
		if (!user || loading) return;
		wishlistService.list().then((value) => {
			if (!cancelled && isCurrentAuthGeneration(generation)) setItems(value);
		}).catch((error) => {
			if (!cancelled && isCurrentAuthGeneration(generation)) toast.error(error instanceof Error ? error.message : "Could not load your wishlist.");
		});
		return () => {
			cancelled = true;
		};
	}, [user?.id, loading]);
	const change = (0, import_react.useCallback)(async (id, save) => {
		if (!user) {
			toast("Sign in to save your favourites.");
			navigate({ to: "/login" });
			return;
		}
		const generation = authGeneration();
		const pendingRequests = pending.current;
		if (pendingRequests.has(id)) return;
		pendingRequests.add(id);
		try {
			const value = await (save ? wishlistService.save(id) : wishlistService.remove(id));
			if (!isCurrentAuthGeneration(generation)) return;
			setItems(value);
			toast(save ? "Saved to wishlist" : "Removed from wishlist");
		} catch (error) {
			if (isCurrentAuthGeneration(generation)) toast.error(error instanceof Error ? error.message : "Could not update your wishlist.");
		} finally {
			pendingRequests.delete(id);
		}
	}, [user?.id, navigate]);
	const value = (0, import_react.useMemo)(() => ({
		items,
		has: (id) => items.some((item) => item.productId === id),
		toggle: (id) => {
			change(id, !items.some((item) => item.productId === id));
		},
		remove: (id) => {
			change(id, false);
		}
	}), [items, change]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WishlistContext.Provider, {
		value,
		children
	});
}
function useWishlist() {
	const value = (0, import_react.useContext)(WishlistContext);
	if (!value) throw new Error("useWishlist must be used inside WishlistProvider");
	return value;
}
var links = [
	{
		to: "/shop",
		label: "Shop all"
	},
	{
		to: "/categories",
		label: "Departments"
	},
	{
		to: "/deals",
		label: "The good deals"
	},
	{
		to: "/about",
		label: "Our store"
	}
];
function Navbar() {
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [mobileSearch, setMobileSearch] = (0, import_react.useState)(false);
	const { count, setDrawerOpen } = useCart();
	const { user } = useAuth();
	const wishlist = useWishlist();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "site-header",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "site-container nav-main",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Main",
					className: "nav-links",
					children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: "nav-link",
						children: link.label
					}, link.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nav-search",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nav-actions",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "sm:hidden",
							"aria-label": "Search products",
							"aria-expanded": mobileSearch,
							"aria-controls": "mobile-search",
							onClick: () => setMobileSearch(!mobileSearch),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								strokeWidth: 1.5,
								"aria-hidden": true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							size: "icon",
							className: "hidden sm:inline-flex",
							"aria-label": "My account",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: user ? "/account" : "/login",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, {
									strokeWidth: 1.5,
									"aria-hidden": true
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "gap-2 px-2",
							"aria-label": `Open shopping bag, ${count} items`,
							onClick: () => setDrawerOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
								strokeWidth: 1.5,
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "cart-counter",
								children: [
									"(",
									count,
									")"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
							open: mobileOpen,
							onOpenChange: setMobileOpen,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									className: "min-[1100px]:hidden",
									"aria-label": "Open menu",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
										strokeWidth: 1.5,
										"aria-hidden": true
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
								side: "right",
								className: "w-80 max-w-[90vw]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Explore IntelliMart" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
									"aria-label": "Mobile",
									className: "flex flex-col gap-2 px-6 pb-8",
									children: [
										links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: link.to,
											onClick: () => setMobileOpen(false),
											className: "py-3 text-xl tracking-tight hover:underline",
											children: link.label
										}, link.to)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: user ? "/account" : "/login",
											onClick: () => setMobileOpen(false),
											className: "mt-6 py-3 text-base",
											children: user ? "My account" : "Sign in"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/account",
											hash: "wishlist",
											onClick: () => setMobileOpen(false),
											className: "py-3 text-base",
											children: [
												"Wishlist (",
												wishlist.items.length,
												")"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/cart",
											onClick: () => setMobileOpen(false),
											className: "py-3 text-base",
											children: [
												"Shopping bag (",
												count,
												")"
											]
										})
									]
								})]
							})]
						})
					]
				})
			]
		}), mobileSearch && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "mobile-search",
			className: "site-container pb-5 sm:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, { autoFocus: true })
		})]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "site-footer",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "site-container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "footer-brand",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "footer-logo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "footer-intro",
							children: "Electronics and everyday essentials for work, play and everything in between."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "footer-nav",
						"aria-label": "Shop",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Shop" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								children: "All products"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/categories",
								children: "Departments"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/deals",
								children: "Deals & offers"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/about",
								children: "About IntelliMart"
							}) })
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "footer-nav",
						"aria-label": "Your account",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Your account" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/account",
								children: "My account"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/account",
								hash: "wishlist",
								children: "My wishlist"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/cart",
								children: "Shopping bag"
							}) })
						] })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" IntelliMart"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "India · INR ₹" })]
			})]
		})
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
function LoadingSkeleton({ count = 8, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("product-grid", className),
		"aria-busy": "true",
		"aria-live": "polite",
		children: [Array.from({ length: count }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-square w-full rounded-xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-3/4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-1/2" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-9 w-full rounded-lg" })
			]
		}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Loading products"
		})]
	});
}
function LoadingState({ label = "Loading" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center gap-3 py-20 text-muted-foreground",
		"aria-live": "polite",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
			className: "h-5 w-5 animate-spin",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: [label, "…"]
		})]
	});
}
function EmptyState({ title, description, action, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center bg-surface px-6 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex h-12 w-12 items-center justify-center text-foreground",
				children: icon ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageOpen, {
					className: "h-5 w-5",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-2xl font-medium",
				children: title
			}),
			description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-base",
				children: description
			}),
			action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: action
			})
		]
	});
}
function ErrorState({ message, onRetry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "alert",
		className: "flex flex-col items-center justify-center rounded-2xl border border-destructive/25 bg-destructive/5 px-6 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "mb-4 h-6 w-6 text-destructive",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-md text-sm text-muted-foreground",
				children: message ?? "We couldn't complete that request. Please try again."
			}),
			onRetry && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-6",
				variant: "outline",
				onClick: onRetry,
				children: "Try again"
			})
		]
	});
}
function CartItemRow({ item, compact = false }) {
	const { update, remove, toggleSaveForLater } = useCart();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/product/$id",
			params: { id: item.productId },
			className: compact ? "h-20 w-20 shrink-0 overflow-hidden bg-surface" : "h-24 w-24 shrink-0 overflow-hidden bg-surface sm:h-32 sm:w-32",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: item.product.images[0],
				alt: item.product.name,
				className: "h-full w-full object-cover",
				loading: "lazy"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/product/$id",
						params: { id: item.productId },
						className: "line-clamp-2 text-sm font-semibold hover:text-primary",
						children: item.product.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted-foreground",
						children: item.product.category
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shrink-0 text-sm font-semibold tabular-nums",
					children: currency(item.product.price * item.quantity)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuantitySelector, {
						value: item.quantity,
						max: Math.max(item.product.stock, 1),
						onChange: (q) => void update(item.productId, q)
					}),
					!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void toggleSaveForLater(item.productId),
						className: "inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground transition-smooth hover:text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
							className: "h-3.5 w-3.5",
							"aria-hidden": true
						}), item.savedForLater ? "Move to cart" : "Save for later"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void remove(item.productId),
						className: "inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground transition-smooth hover:text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "h-3.5 w-3.5",
							"aria-hidden": true
						}), "Remove"]
					})
				]
			})]
		})]
	});
}
function CartDrawer() {
	const { cart, drawerOpen, setDrawerOpen, totals, count } = useCart();
	const active = cart.items.filter((i) => !i.savedForLater);
	const t = totals();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: drawerOpen,
		onOpenChange: setDrawerOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "flex w-full flex-col gap-0 sm:max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
					className: "font-display text-2xl font-medium",
					children: [
						"Your bag (",
						count,
						")"
					]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto px-4",
					children: active.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "Your cart is empty",
						description: "Browse the catalogue and add something you like.",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
							className: "h-5 w-5",
							"aria-hidden": true
						}),
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							onClick: () => setDrawerOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								children: "Start shopping"
							})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-5",
						children: active.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartItemRow, {
							item,
							compact: true
						}, item.productId))
					})
				}),
				active.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetFooter, {
					className: "bg-surface p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Subtotal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold tabular-nums",
									children: currency(t.subtotal)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Shipping and taxes are calculated at checkout."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "hero",
									onClick: () => setDrawerOpen(false),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/checkout",
										children: "Checkout"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									onClick: () => setDrawerOpen(false),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/cart",
										children: "View cart"
									})
								})]
							})
						]
					})
				})
			]
		})
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		console.error("IntelliMart page error", error);
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$17 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "IntelliMart — Smarter Finds for Everyday Life" },
			{
				name: "description",
				content: "Discover electronics, computing gear and smart devices at IntelliMart. Browse categories, explore deals and find your next everyday upgrade."
			},
			{
				name: "author",
				content: "IntelliMart"
			},
			{
				property: "og:title",
				content: "IntelliMart — Smarter Finds for Everyday Life"
			},
			{
				property: "og:description",
				content: "Electronics, computing gear and smart devices for work, play and everyday life."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$17.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WishlistProvider, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-screen flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#main",
						className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-100 focus:rounded-md focus:bg-card focus:px-4 focus:py-2 focus:shadow-lift",
						children: "Skip to content"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						id: "main",
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartDrawer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, { position: "bottom-right" })
		] }) }) })
	});
}
var $$splitComponentImporter$15 = () => import("./routes-BuBnGJ4Z.mjs");
var Route$16 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "IntelliMart — Good Things for Your Everyday" },
		{
			name: "description",
			content: "A considered collection of electronics, desk essentials and everyday finds. Shop for the way you work, play and live."
		},
		{
			property: "og:title",
			content: "IntelliMart — Good Things for Your Everyday"
		},
		{
			property: "og:description",
			content: "Electronics, desk essentials and everyday finds. Find something good at IntelliMart."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./about-CsHFoRmB.mjs");
var Route$15 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "About IntelliMart — Smarter Finds for Everyday Life" },
		{
			name: "description",
			content: "Get to know IntelliMart, your place to explore electronics, computing gear and smart devices for work, play and everyday life."
		},
		{
			property: "og:title",
			content: "About IntelliMart"
		},
		{
			property: "og:description",
			content: "Discover everyday upgrades in audio, computing, gaming and smart home gear."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./account-CE96UowY.mjs");
var Route$14 = createFileRoute("/account")({
	head: () => ({ meta: [
		{ title: "Your account — IntelliMart" },
		{
			name: "description",
			content: "Manage your IntelliMart profile, review past orders and revisit your wishlist."
		},
		{
			name: "robots",
			content: "noindex"
		},
		{
			property: "og:title",
			content: "Your account — IntelliMart"
		},
		{
			property: "og:description",
			content: "Profile, orders and wishlist in one place."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./admin-B9QdEcI1.mjs");
var Route$13 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Admin — IntelliMart" }, {
		name: "robots",
		content: "noindex, nofollow"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./cart-DxdpU7Vv.mjs");
var Route$12 = createFileRoute("/cart")({
	head: () => ({ meta: [
		{ title: "Your cart — IntelliMart" },
		{
			name: "description",
			content: "Review the items in your IntelliMart cart, update quantities and continue to checkout."
		},
		{
			property: "og:title",
			content: "Your cart — IntelliMart"
		},
		{
			property: "og:description",
			content: "Review items, update quantities and continue to checkout."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./categories-pJ8kW1wX.mjs");
var Route$11 = createFileRoute("/categories")({
	head: () => ({ meta: [
		{ title: "All categories — IntelliMart" },
		{
			name: "description",
			content: "Browse IntelliMart departments: electronics, computing, home, fashion, gaming, books and smart devices."
		},
		{
			property: "og:title",
			content: "All categories — IntelliMart"
		},
		{
			property: "og:description",
			content: "Eight departments, one curated catalogue."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./checkout-JCND1PhK.mjs");
var Route$10 = createFileRoute("/checkout")({
	head: () => ({ meta: [
		{ title: "Checkout — IntelliMart" },
		{
			name: "description",
			content: "Shipping, delivery and order review."
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./deals-C9d-Xmm7.mjs");
var Route$9 = createFileRoute("/deals")({
	head: () => ({ meta: [
		{ title: "Today's deals — IntelliMart" },
		{
			name: "description",
			content: "Live markdowns across headphones, monitors, gaming gear and smart devices at IntelliMart."
		},
		{
			property: "og:title",
			content: "Today's deals — IntelliMart"
		},
		{
			property: "og:description",
			content: "Every product currently marked down, sorted by biggest saving."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./forgot-password-DpM1Di0a.mjs");
var Route$8 = createFileRoute("/forgot-password")({
	head: () => ({ meta: [{ title: "Reset password — IntelliMart" }, {
		name: "description",
		content: "Reset your IntelliMart account password."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var Route$7 = createFileRoute("/health")({ server: { handlers: { GET: () => {
	getRuntimeConfig();
	return Response.json({
		status: "ok",
		application: "IntelliMart"
	}, { headers: { "Cache-Control": "no-store" } });
} } } });
var $$splitComponentImporter$6 = () => import("./login-BiLyEM3j.mjs");
var Route$6 = createFileRoute("/login")({
	validateSearch: (search) => search["redirect"] === "/admin" ? { redirect: "/admin" } : {},
	head: () => ({ meta: [
		{ title: "Sign in — IntelliMart" },
		{
			name: "description",
			content: "Sign in to IntelliMart to track orders, save a wishlist and check out faster."
		},
		{
			property: "og:title",
			content: "Sign in — IntelliMart"
		},
		{
			property: "og:description",
			content: "Access your IntelliMart account."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./order-confirmation-Cah57U-1.mjs");
var Route$5 = createFileRoute("/order-confirmation")({
	validateSearch: (search) => ({ id: typeof search["id"] === "string" ? search["id"] : "" }),
	head: () => ({ meta: [
		{ title: "Order confirmed — IntelliMart" },
		{
			name: "description",
			content: "Your IntelliMart order is confirmed. Track the order ID, items and estimated delivery."
		},
		{
			name: "robots",
			content: "noindex"
		},
		{
			property: "og:title",
			content: "Order confirmed — IntelliMart"
		},
		{
			property: "og:description",
			content: "Order details and estimated delivery."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./register-KTfeAHWY.mjs");
var Route$4 = createFileRoute("/register")({
	head: () => ({ meta: [
		{ title: "Create account — IntelliMart" },
		{
			name: "description",
			content: "Create an IntelliMart account to save products, track orders and check out faster."
		},
		{
			property: "og:title",
			content: "Create account — IntelliMart"
		},
		{
			property: "og:description",
			content: "Join IntelliMart in a few seconds."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./search-DEqdyrcR.mjs");
var Route$3 = createFileRoute("/search")({
	validateSearch: (search) => ({ q: typeof search["q"] === "string" ? search["q"] : "" }),
	head: ({ match }) => {
		const q = match.search.q;
		const title = q ? `Search results for "${q}" — IntelliMart` : "Search — IntelliMart";
		return { meta: [
			{ title },
			{
				name: "description",
				content: q ? `Products matching "${q}" at IntelliMart.` : "Search the IntelliMart catalogue."
			},
			{
				name: "robots",
				content: "noindex"
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: "Search the IntelliMart catalogue by name, category or description."
			}
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./shop-BcvSfbyS.mjs");
var Route$2 = createFileRoute("/shop")({
	validateSearch: (search) => ({
		...typeof search["category"] === "string" ? { category: search["category"] } : {},
		...search["sale"] === true || search["sale"] === "true" ? { sale: true } : {}
	}),
	head: () => ({ meta: [
		{ title: "Shop all products — IntelliMart" },
		{
			name: "description",
			content: "Filter and sort the full IntelliMart catalogue: electronics, computing, gaming, smart devices and more."
		},
		{
			property: "og:title",
			content: "Shop all products — IntelliMart"
		},
		{
			property: "og:description",
			content: "Filter by category, price and rating across the full catalogue."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./verify-email-DVxZIJzB.mjs");
var Route$1 = createFileRoute("/verify-email")({
	validateSearch: (raw) => ({ email: typeof raw["email"] === "string" ? raw["email"] : "" }),
	head: () => ({ meta: [{ title: "Verify email — IntelliMart" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./product._id-AW1Bkj_I.mjs");
var Route = createFileRoute("/product/$id")({
	head: ({ params }) => ({ meta: [
		{ title: `Product ${params.id} — IntelliMart` },
		{
			name: "description",
			content: "Full specifications, reviews, shipping and returns for this IntelliMart product."
		},
		{
			property: "og:title",
			content: "IntelliMart product"
		},
		{
			property: "og:description",
			content: "Specifications, reviews, shipping and returns."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$16.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$17
	}),
	AboutRoute: Route$15.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$17
	}),
	AccountRoute: Route$14.update({
		id: "/account",
		path: "/account",
		getParentRoute: () => Route$17
	}),
	AdminRoute: Route$13.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$17
	}),
	CartRoute: Route$12.update({
		id: "/cart",
		path: "/cart",
		getParentRoute: () => Route$17
	}),
	CategoriesRoute: Route$11.update({
		id: "/categories",
		path: "/categories",
		getParentRoute: () => Route$17
	}),
	CheckoutRoute: Route$10.update({
		id: "/checkout",
		path: "/checkout",
		getParentRoute: () => Route$17
	}),
	DealsRoute: Route$9.update({
		id: "/deals",
		path: "/deals",
		getParentRoute: () => Route$17
	}),
	ForgotPasswordRoute: Route$8.update({
		id: "/forgot-password",
		path: "/forgot-password",
		getParentRoute: () => Route$17
	}),
	HealthRoute: Route$7.update({
		id: "/health",
		path: "/health",
		getParentRoute: () => Route$17
	}),
	LoginRoute: Route$6.update({
		id: "/login",
		path: "/login",
		getParentRoute: () => Route$17
	}),
	OrderConfirmationRoute: Route$5.update({
		id: "/order-confirmation",
		path: "/order-confirmation",
		getParentRoute: () => Route$17
	}),
	RegisterRoute: Route$4.update({
		id: "/register",
		path: "/register",
		getParentRoute: () => Route$17
	}),
	SearchRoute: Route$3.update({
		id: "/search",
		path: "/search",
		getParentRoute: () => Route$17
	}),
	ShopRoute: Route$2.update({
		id: "/shop",
		path: "/shop",
		getParentRoute: () => Route$17
	}),
	VerifyEmailRoute: Route$1.update({
		id: "/verify-email",
		path: "/verify-email",
		getParentRoute: () => Route$17
	}),
	ProductIdRoute: Route.update({
		id: "/product/$id",
		path: "/product/$id",
		getParentRoute: () => Route$17
	})
};
var routeTree = Route$17._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
export { ServiceError as A, discountPercent as C, authService as D, useAuth as E, isCurrentAuthGeneration as M, unwrap as N, confirmSignUpFn as O, currency as S, stockLabel as T, SheetHeader as _, Route$3 as a, QuantitySelector as b, CartItemRow as c, LoadingSkeleton as d, LoadingState as f, SheetContent as g, Sheet as h, Route$2 as i, authGeneration as j, resendCodeFn as k, EmptyState as l, SearchBar as m, Route as n, Route$5 as o, useWishlist as p, Route$1 as r, Route$6 as s, router_exports as t, ErrorState as u, SheetTitle as v, formatDate as w, useCart as x, SheetTrigger as y };
