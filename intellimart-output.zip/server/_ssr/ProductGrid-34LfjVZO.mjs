import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as cn } from "./button-DUF1Y1qY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as Heart } from "../_libs/lucide-react.mjs";
import { C as discountPercent, S as currency, d as LoadingSkeleton, l as EmptyState, p as useWishlist, u as ErrorState, x as useCart } from "./router-Couj4mWN.mjs";
// node_modules/.nitro/vite/services/ssr/assets/ProductGrid-34LfjVZO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product, className }) {
	const { add } = useCart();
	const wishlist = useWishlist();
	const [adding, setAdding] = (0, import_react.useState)(false);
	const saved = wishlist.has(product.id);
	const discount = discountPercent(product.price, product.originalPrice);
	const outOfStock = product.stock === 0;
	const name = product.name.replace("Wireless Noise Cancelling", "Noise-cancelling");
	const addToBag = async () => {
		setAdding(true);
		try {
			await add(product.id);
		} finally {
			setAdding(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("product-card", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "product-picture",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/product/$id",
					params: { id: product.id },
					"aria-label": `View ${product.name}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.images[0],
						alt: product.name,
						loading: "lazy",
						width: 800,
						height: 800
					})
				}),
				discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "product-sale",
					children: [
						"Save ",
						discount,
						"%"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => wishlist.toggle(product.id),
					"aria-label": saved ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`,
					"aria-pressed": saved,
					className: "save-product",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						className: cn("h-[18px] w-[18px]", saved && "fill-current"),
						strokeWidth: 1.5,
						"aria-hidden": true
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "product-info",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "product-category",
					children: product.category
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/product/$id",
					params: { id: product.id },
					children: name
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "product-detail",
					children: product.highlights.slice(0, 2).join(" · ")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "product-buy",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "product-price",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currency(product.price) }), discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("del", { children: currency(product.originalPrice) })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "add-product",
						disabled: outOfStock || adding,
						onClick: () => void addToBag(),
						"aria-label": `Add ${product.name} to bag`,
						children: outOfStock ? "Sold out" : adding ? "Adding…" : "Add to bag"
					})]
				})
			]
		})]
	});
}
function ProductGrid({ products, loading, error, emptyTitle = "No products found", emptyDescription = "Try adjusting your filters or search for something else.", className }) {
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: error });
	if (!products.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: emptyTitle,
		description: emptyDescription
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("product-grid", className),
		children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
	});
}
export { ProductGrid as t };
