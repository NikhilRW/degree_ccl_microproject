import { c as number, d as string, l as object } from "../_libs/zod.mjs";
import { j as productQuerySchema, w as idSchema } from "./ssr.mjs";
import { r as createServerFn } from "./server-CiMkYVYO.mjs";
import { o as createSsrRpc } from "./customer.functions-BcXykFYC.mjs";
// node_modules/.nitro/vite/services/ssr/assets/catalogue.functions-DBDE1qea.js
var productsFn = createServerFn({ method: "GET" }).validator(productQuerySchema).handler(createSsrRpc("505034f6c1509072c9b72795c5951f9cfa306c998d82ddc744ae3a75529a69d8"));
var productFn = createServerFn({ method: "GET" }).validator(idSchema).handler(createSsrRpc("c087471c6121e41c9d35167fffbc5ff18678392d67430a9bcb89e0f75b31e205"));
var categoriesFn = createServerFn({ method: "GET" }).handler(createSsrRpc("31fcc8d20701a93edecf6b2813cee9db316064ce5356852c680b4e193943a22d"));
var reviewsFn = createServerFn({ method: "GET" }).validator(idSchema).handler(createSsrRpc("0a57ea703e25e959586c6f30d63196c9cdef45974498456bcf26b85802632ffa"));
var relatedFn = createServerFn({ method: "GET" }).validator(object({
	id: idSchema,
	limit: number().int().min(1).max(100)
})).handler(createSsrRpc("d39ba7cf46f2596a149586f31c055eadad477ce900f15635139c867dc5c5d891"));
var priceRangeFn = createServerFn({ method: "GET" }).handler(createSsrRpc("6bfe4e6b6cc0434a447a4c104dc38a4add00cc56323e2a06dd7ed361d0649133"));
var suggestionsFn = createServerFn({ method: "GET" }).validator(string().max(200)).handler(createSsrRpc("bcd37277638b8aa16f12025069395b727ffcd52a8d33963d4987ce20923bf1fa"));
export { relatedFn as a, productsFn as i, priceRangeFn as n, reviewsFn as o, productFn as r, suggestionsFn as s, categoriesFn as t };
