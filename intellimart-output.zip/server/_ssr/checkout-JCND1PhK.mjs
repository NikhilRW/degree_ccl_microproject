import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as cn, t as Button } from "./button-DUF1Y1qY.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as orderService } from "./awsOrderService-gOrj1Wb6.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { b as Check, g as Circle } from "../_libs/lucide-react.mjs";
import { E as useAuth, S as currency, f as LoadingState, l as EmptyState, x as useCart } from "./router-Couj4mWN.mjs";
import { n as RadioGroupIndicator, r as RadioGroupItem$1, t as RadioGroup$1 } from "../_libs/@radix-ui/react-radio-group+[...].mjs";
import { t as Input } from "./input-BbR4Ntsy.mjs";
import { t as Label } from "./label-Cvda4mU8.mjs";
// node_modules/.nitro/vite/services/ssr/assets/checkout-JCND1PhK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RadioGroup = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup$1, {
		className: cn("grid gap-2", className),
		...props,
		ref
	});
});
RadioGroup.displayName = RadioGroup$1.displayName;
var RadioGroupItem = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem$1, {
		ref,
		className: cn("aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupIndicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-3.5 w-3.5 fill-primary" })
		})
	});
});
RadioGroupItem.displayName = RadioGroupItem$1.displayName;
var steps = [
	"Shipping",
	"Delivery",
	"Review"
];
var emptyAddress = {
	fullName: "",
	phone: "",
	address: "",
	apartment: "",
	city: "",
	state: "",
	postalCode: "",
	country: "India"
};
function CheckoutPage() {
	const { cart, loading: cartLoading, totals, refresh } = useCart();
	const { user, loading: authLoading } = useAuth();
	const navigate = useNavigate();
	const [step, setStep] = (0, import_react.useState)(0);
	const [address, setAddress] = (0, import_react.useState)(emptyAddress);
	const [delivery, setDelivery] = (0, import_react.useState)("standard");
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("card");
	const [placing, setPlacing] = (0, import_react.useState)(false);
	const requestId = (0, import_react.useRef)(null);
	const active = cart.items.filter((item) => !item.savedForLater);
	const t = totals(delivery);
	if (authLoading || cartLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading checkout" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "site-container py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Sign in to check out",
			description: "Use your account to save your shipping details and keep track of your order.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					children: "Sign in"
				})
			})
		})
	});
	if (!active.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "site-container py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Your bag is empty",
			description: "Find something you love before checking out.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					children: "Shop the collection"
				})
			})
		})
	});
	const shippingValid = [
		address.fullName,
		address.phone,
		address.address,
		address.city,
		address.state,
		address.postalCode
	].every((value) => value.trim());
	const placeOrder = async () => {
		if (placing) return;
		if (paymentMethod !== "cod" && !window.confirm(`Simulate ${paymentMethod.toUpperCase()} payment of ${currency(t.total)}? No payment will be processed.`)) return;
		setPlacing(true);
		requestId.current ??= crypto.randomUUID();
		try {
			const order = await orderService.create({
				address,
				delivery,
				method: paymentMethod,
				idempotencyKey: requestId.current,
				expectedTotal: t.total
			});
			refresh();
			navigate({
				to: "/order-confirmation",
				search: { id: order.id }
			});
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not place your order.");
		} finally {
			setPlacing(false);
		}
	};
	const field = (key, label, required = true) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor: key,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			id: key,
			value: address[key] ?? "",
			required,
			maxLength: key === "address" ? 300 : 100,
			onChange: (event) => setAddress({
				...address,
				[key]: event.target.value
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-container pb-24 pt-10 sm:pt-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl font-medium sm:text-6xl",
				children: "Checkout"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 flex flex-wrap gap-6",
				"aria-label": "Checkout steps",
				children: steps.map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("flex items-center gap-2 text-sm", index === step ? "font-semibold" : "text-muted-foreground"),
					"aria-current": index === step ? "step" : void 0,
					children: [index < step && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "h-4 w-4",
						"aria-hidden": true
					}), label]
				}, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-10 lg:grid-cols-[minmax(0,1fr)_340px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card p-6 sm:p-8",
					children: [
						step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl font-medium",
								children: "Shipping address"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [
									field("fullName", "Full name"),
									field("phone", "Phone"),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "sm:col-span-2",
										children: field("address", "Address")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "sm:col-span-2",
										children: field("apartment", "Apartment, suite (optional)", false)
									}),
									field("city", "City"),
									field("state", "State"),
									field("postalCode", "Postal code"),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "country",
											children: "Country"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "country",
											value: "India",
											readOnly: true
										})]
									})
								]
							})]
						}),
						step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-2xl font-medium",
									children: "Delivery method"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
									value: delivery,
									onValueChange: (value) => setDelivery(value),
									className: "gap-4",
									children: [{
										id: "standard",
										title: "Standard delivery",
										detail: "4–6 business days",
										price: t.subtotal > 2e4 ? "Free" : currency(199)
									}, {
										id: "express",
										title: "Express delivery",
										detail: "1–2 business days",
										price: currency(499)
									}].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										htmlFor: option.id,
										className: "flex cursor-pointer items-center gap-4 bg-surface p-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
												id: option.id,
												value: option.id
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-base font-medium",
													children: option.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block text-sm text-muted-foreground",
													children: option.detail
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: option.price })
										]
									}, option.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-surface p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-base font-medium",
											children: "Payment method"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
											value: paymentMethod,
											onValueChange: (value) => setPaymentMethod(value),
											className: "mt-3 gap-3",
											children: [
												{
													id: "card",
													title: "Card (mock payment)"
												},
												{
													id: "upi",
													title: "UPI (mock payment)"
												},
												{
													id: "cod",
													title: "Cash on delivery"
												}
											].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
												htmlFor: `payment-${option.id}`,
												className: "flex cursor-pointer items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
													id: `payment-${option.id}`,
													value: option.id
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: option.title })]
											}, option.id))
										}),
										paymentMethod === "cod" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm",
											children: "Pay the order total when your items arrive. No advance payment is required."
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm text-muted-foreground",
											children: "Demo only: this simulates payment approval. No card/UPI details are collected and no money is charged."
										})
									]
								})
							]
						}),
						step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-2xl font-medium",
									children: "Review your order"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-4",
									children: active.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: item.product.images[0],
												alt: "",
												className: "h-16 w-16 object-cover"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex-1 text-sm",
												children: [
													item.product.name,
													" × ",
													item.quantity
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm tabular-nums",
												children: currency(item.product.price * item.quantity)
											})
										]
									}, item.productId))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-6 bg-surface p-5 text-sm sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-medium",
										children: "Ship to"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2",
										children: [
											address.fullName,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											address.address,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											address.city,
											", ",
											address.state,
											" ",
											address.postalCode
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-medium",
											children: "Delivery & payment"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-2 capitalize",
											children: [delivery, " delivery"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1",
											children: paymentMethod === "cod" ? "Cash on delivery" : `${paymentMethod.toUpperCase()} · simulated`
										})
									] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								disabled: step === 0 || placing,
								onClick: () => setStep((value) => value - 1),
								children: "Back"
							}), step < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: step === 0 && !shippingValid,
								onClick: () => setStep((value) => value + 1),
								children: "Continue"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: placing,
								onClick: () => void placeOrder(),
								children: placing ? "Placing order…" : paymentMethod === "cod" ? "Place order" : "Simulate payment & place order"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "self-start bg-surface p-6 sm:p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-medium",
						children: "Order summary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 space-y-4 text-sm",
						children: [[
							["Subtotal", currency(t.subtotal)],
							["Shipping", t.shipping ? currency(t.shipping) : "Free"],
							["Tax (18%)", currency(t.tax)]
						].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: value
							})]
						}, label)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between pt-4 text-lg font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: paymentMethod === "cod" ? "Due on delivery" : "Mock payment total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: currency(t.total)
							})]
						})]
					})]
				})]
			})
		]
	});
}
export { CheckoutPage as component };
