import { l as require_serde, u as require_endpoints } from "./@aws-sdk/checksums+[...].mjs";
import { D as getSigningKey, E as createScope, x as init_dist_es } from "./@aws-sdk/client-cognito-identity-provider+[...].mjs";
import { o as require_util, t as PutObjectCommand } from "./@aws-sdk/client-s3+[...].mjs";
// node_modules/@aws-sdk/s3-presigned-post/dist-es/constants.js
var import_endpoints = require_endpoints();
var import_serde = require_serde();
init_dist_es();
var import_util = require_util();
var ALGORITHM_QUERY_PARAM = "X-Amz-Algorithm";
var CREDENTIAL_QUERY_PARAM = "X-Amz-Credential";
var AMZ_DATE_QUERY_PARAM = "X-Amz-Date";
var TOKEN_QUERY_PARAM = "X-Amz-Security-Token";
var SIGNATURE_QUERY_PARAM = "X-Amz-Signature";
var ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256";
// node_modules/@aws-sdk/s3-presigned-post/dist-es/createPresignedPost.js
var createPresignedPost = async (client, { Bucket, Key, Conditions = [], Fields = {}, Expires = 3600 }) => {
	const { systemClockOffset, base64Encoder, utf8Decoder, sha256 } = client.config;
	const now = new Date(Date.now() + systemClockOffset);
	const signingDate = iso8601(now).replace(/[\-:]/g, "");
	const shortDate = signingDate.slice(0, 8);
	const clientRegion = await client.config.region();
	const credentialScope = createScope(shortDate, clientRegion, "s3");
	const clientCredentials = await client.config.credentials();
	const credential = `${clientCredentials.accessKeyId}/${credentialScope}`;
	const fields = {
		...Fields,
		bucket: Bucket,
		[ALGORITHM_QUERY_PARAM]: ALGORITHM_IDENTIFIER,
		[CREDENTIAL_QUERY_PARAM]: credential,
		[AMZ_DATE_QUERY_PARAM]: signingDate,
		...clientCredentials.sessionToken ? { [TOKEN_QUERY_PARAM]: clientCredentials.sessionToken } : {}
	};
	const expiration = new Date(now.valueOf() + Expires * 1e3);
	const conditionsSet = /* @__PURE__ */ new Set();
	for (const condition of Conditions) {
		const stringifiedCondition = JSON.stringify(condition);
		conditionsSet.add(stringifiedCondition);
	}
	for (const [k, v] of Object.entries(fields)) conditionsSet.add(JSON.stringify({ [k]: v }));
	if (Key.endsWith("${filename}")) conditionsSet.add(JSON.stringify([
		"starts-with",
		"$key",
		Key.substring(0, Key.lastIndexOf("${filename}"))
	]));
	else conditionsSet.add(JSON.stringify({ key: Key }));
	const conditions = Array.from(conditionsSet).map((item) => JSON.parse(item));
	const encodedPolicy = base64Encoder(utf8Decoder(JSON.stringify({
		expiration: iso8601(expiration),
		conditions
	})));
	const signature = await hmac(sha256, await getSigningKey(sha256, clientCredentials, shortDate, clientRegion, "s3"), encodedPolicy);
	const endpoint = (0, import_endpoints.toEndpointV1)(await (0, import_endpoints.getEndpointFromInstructions)({
		Bucket,
		Key
	}, PutObjectCommand, { ...client.config }, { logger: client.config.logger }));
	return {
		url: (0, import_util.formatUrl)(endpoint),
		fields: {
			...fields,
			key: Key,
			Policy: encodedPolicy,
			[SIGNATURE_QUERY_PARAM]: (0, import_serde.toHex)(signature)
		}
	};
};
var iso8601 = (date) => date.toISOString().replace(/\.\d{3}Z$/, "Z");
var hmac = (ctor, secret, data) => {
	const hash = new ctor(secret);
	hash.update((0, import_serde.toUint8Array)(data));
	return hash.digest();
};
export { createPresignedPost as t };
