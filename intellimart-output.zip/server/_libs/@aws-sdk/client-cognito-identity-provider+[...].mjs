import { a as __toCommonJS, n as __esmMin, r as __exportAll, t as __commonJSMin } from "../../_runtime.mjs";
import { a as require_retry, c as require_checksum, d as require_config, f as require_client, g as init_dist_es$3, h as dist_es_exports$4, i as require_dist_cjs, l as require_serde, m as require_transport, o as require_protocols$1, p as require_schema, r as require_client$1, u as require_endpoints } from "./checksums+[...].mjs";
import { Readable } from "node:stream";
import node_https from "node:https";
import nodeHTTP2, { default as node_http2 } from "node:http2";
// node_modules/@smithy/signature-v4/dist-es/HeaderFormatter.js
function negate(bytes) {
	for (let i = 0; i < 8; i++) bytes[i] ^= 255;
	for (let i = 7; i > -1; i--) {
		bytes[i]++;
		if (bytes[i] !== 0) break;
	}
}
var import_serde$12, HeaderFormatter, HEADER_VALUE_TYPE, UUID_PATTERN, Int64;
var init_HeaderFormatter = __esmMin((() => {
	import_serde$12 = require_serde();
	HeaderFormatter = class {
		format(headers) {
			const chunks = [];
			for (const headerName in headers) {
				if (!(0, import_serde$12.hasOwn)(headers, headerName)) continue;
				const bytes = (0, import_serde$12.fromUtf8)(headerName);
				chunks.push(Uint8Array.from([bytes.byteLength]), bytes, this.formatHeaderValue(headers[headerName]));
			}
			const out = new Uint8Array(chunks.reduce((carry, bytes) => carry + bytes.byteLength, 0));
			let position = 0;
			for (const chunk of chunks) {
				out.set(chunk, position);
				position += chunk.byteLength;
			}
			return out;
		}
		formatHeaderValue(header) {
			switch (header.type) {
				case "boolean": return Uint8Array.from([header.value ? 0 : 1]);
				case "byte": return Uint8Array.from([2, header.value]);
				case "short":
					const shortView = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(3));
					shortView.setUint8(0, 3);
					shortView.setInt16(1, header.value, false);
					return new Uint8Array(shortView.buffer);
				case "integer":
					const intView = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(5));
					intView.setUint8(0, 4);
					intView.setInt32(1, header.value, false);
					return new Uint8Array(intView.buffer);
				case "long":
					const longBytes = /* @__PURE__ */ new Uint8Array(9);
					longBytes[0] = 5;
					longBytes.set(header.value.bytes, 1);
					return longBytes;
				case "binary":
					const binView = new DataView(new ArrayBuffer(3 + header.value.byteLength));
					binView.setUint8(0, 6);
					binView.setUint16(1, header.value.byteLength, false);
					const binBytes = new Uint8Array(binView.buffer);
					binBytes.set(header.value, 3);
					return binBytes;
				case "string":
					const utf8Bytes = (0, import_serde$12.fromUtf8)(header.value);
					const strView = new DataView(new ArrayBuffer(3 + utf8Bytes.byteLength));
					strView.setUint8(0, 7);
					strView.setUint16(1, utf8Bytes.byteLength, false);
					const strBytes = new Uint8Array(strView.buffer);
					strBytes.set(utf8Bytes, 3);
					return strBytes;
				case "timestamp":
					const tsBytes = /* @__PURE__ */ new Uint8Array(9);
					tsBytes[0] = 8;
					tsBytes.set(Int64.fromNumber(header.value.valueOf()).bytes, 1);
					return tsBytes;
				case "uuid":
					if (!UUID_PATTERN.test(header.value)) throw new Error(`Invalid UUID received: ${header.value}`);
					const uuidBytes = /* @__PURE__ */ new Uint8Array(17);
					uuidBytes[0] = 9;
					uuidBytes.set((0, import_serde$12.fromHex)(header.value.replace(/-/g, "")), 1);
					return uuidBytes;
			}
		}
	};
	(function(HEADER_VALUE_TYPE) {
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["boolTrue"] = 0] = "boolTrue";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["boolFalse"] = 1] = "boolFalse";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["byte"] = 2] = "byte";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["short"] = 3] = "short";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["integer"] = 4] = "integer";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["long"] = 5] = "long";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["byteArray"] = 6] = "byteArray";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["string"] = 7] = "string";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["timestamp"] = 8] = "timestamp";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["uuid"] = 9] = "uuid";
	})(HEADER_VALUE_TYPE || (HEADER_VALUE_TYPE = {}));
	UUID_PATTERN = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
	Int64 = class Int64 {
		bytes;
		constructor(bytes) {
			this.bytes = bytes;
			if (bytes.byteLength !== 8) throw new Error("Int64 buffers must be exactly 8 bytes");
		}
		static fromNumber(number) {
			if (number > 0x8000000000000000 || number < -0x8000000000000000) throw new Error(`${number} is too large (or, if negative, too small) to represent as an Int64`);
			const bytes = /* @__PURE__ */ new Uint8Array(8);
			for (let i = 7, remaining = Math.abs(Math.round(number)); i > -1 && remaining > 0; i--, remaining /= 256) bytes[i] = remaining;
			if (number < 0) negate(bytes);
			return new Int64(bytes);
		}
		valueOf() {
			const bytes = this.bytes.slice(0);
			const negative = bytes[0] & 128;
			if (negative) negate(bytes);
			return parseInt((0, import_serde$12.toHex)(bytes), 16) * (negative ? -1 : 1);
		}
		toString() {
			return String(this.valueOf());
		}
	};
}));
// node_modules/@smithy/signature-v4/dist-es/constants.js
var ALGORITHM_QUERY_PARAM, CREDENTIAL_QUERY_PARAM, AMZ_DATE_QUERY_PARAM, SIGNED_HEADERS_QUERY_PARAM, EXPIRES_QUERY_PARAM, SIGNATURE_QUERY_PARAM, TOKEN_QUERY_PARAM, REGION_SET_PARAM, AUTH_HEADER, AMZ_DATE_HEADER, DATE_HEADER, GENERATED_HEADERS, SIGNATURE_HEADER, SHA256_HEADER, TOKEN_HEADER, HOST_HEADER, ALWAYS_UNSIGNABLE_HEADERS, PROXY_HEADER_PATTERN, SEC_HEADER_PATTERN, UNSIGNABLE_PATTERNS, ALGORITHM_IDENTIFIER, ALGORITHM_IDENTIFIER_V4A, EVENT_ALGORITHM_IDENTIFIER, UNSIGNED_PAYLOAD, KEY_TYPE_IDENTIFIER, MAX_PRESIGNED_TTL;
var init_constants$1 = __esmMin((() => {
	ALGORITHM_QUERY_PARAM = "X-Amz-Algorithm";
	CREDENTIAL_QUERY_PARAM = "X-Amz-Credential";
	AMZ_DATE_QUERY_PARAM = "X-Amz-Date";
	SIGNED_HEADERS_QUERY_PARAM = "X-Amz-SignedHeaders";
	EXPIRES_QUERY_PARAM = "X-Amz-Expires";
	SIGNATURE_QUERY_PARAM = "X-Amz-Signature";
	TOKEN_QUERY_PARAM = "X-Amz-Security-Token";
	REGION_SET_PARAM = "X-Amz-Region-Set";
	AUTH_HEADER = "authorization";
	AMZ_DATE_HEADER = AMZ_DATE_QUERY_PARAM.toLowerCase();
	DATE_HEADER = "date";
	GENERATED_HEADERS = [
		AUTH_HEADER,
		AMZ_DATE_HEADER,
		DATE_HEADER
	];
	SIGNATURE_HEADER = SIGNATURE_QUERY_PARAM.toLowerCase();
	SHA256_HEADER = "x-amz-content-sha256";
	TOKEN_HEADER = TOKEN_QUERY_PARAM.toLowerCase();
	HOST_HEADER = "host";
	ALWAYS_UNSIGNABLE_HEADERS = {
		authorization: true,
		"cache-control": true,
		connection: true,
		expect: true,
		from: true,
		"keep-alive": true,
		"max-forwards": true,
		pragma: true,
		referer: true,
		te: true,
		trailer: true,
		"transfer-encoding": true,
		upgrade: true,
		"user-agent": true,
		"x-amzn-trace-id": true
	};
	PROXY_HEADER_PATTERN = /^proxy-/;
	SEC_HEADER_PATTERN = /^sec-/;
	UNSIGNABLE_PATTERNS = [/^proxy-/i, /^sec-/i];
	ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256";
	ALGORITHM_IDENTIFIER_V4A = "AWS4-ECDSA-P256-SHA256";
	EVENT_ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256-PAYLOAD";
	UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
	KEY_TYPE_IDENTIFIER = "aws4_request";
	MAX_PRESIGNED_TTL = 604800;
}));
// node_modules/@smithy/signature-v4/dist-es/getCanonicalQuery.js
var import_serde$11, import_protocols$7, getCanonicalQuery;
var init_getCanonicalQuery = __esmMin((() => {
	import_serde$11 = require_serde();
	import_protocols$7 = require_protocols$1();
	init_constants$1();
	getCanonicalQuery = ({ query = {} }) => {
		const keys = [];
		const serialized = {};
		for (const key in query) {
			if (!(0, import_serde$11.hasOwn)(query, key)) continue;
			if (key.toLowerCase() === "x-amz-signature") continue;
			const encodedKey = (0, import_protocols$7.escapeUri)(key);
			keys.push(encodedKey);
			const value = query[key];
			if (typeof value === "string") serialized[encodedKey] = `${encodedKey}=${(0, import_protocols$7.escapeUri)(value)}`;
			else if (Array.isArray(value)) serialized[encodedKey] = value.slice(0).reduce((encoded, value) => encoded.concat([`${encodedKey}=${(0, import_protocols$7.escapeUri)(value)}`]), []).sort().join("&");
		}
		return keys.sort().map((key) => serialized[key]).filter((serialized) => serialized).join("&");
	};
}));
// node_modules/@smithy/signature-v4/dist-es/utilDate.js
var iso8601, toDate;
var init_utilDate = __esmMin((() => {
	iso8601 = (time) => toDate(time).toISOString().replace(/\.\d{3}Z$/, "Z");
	toDate = (time) => {
		if (typeof time === "number") return /* @__PURE__ */ new Date(time * 1e3);
		if (typeof time === "string") {
			if (Number(time)) return /* @__PURE__ */ new Date(Number(time) * 1e3);
			return new Date(time);
		}
		return time;
	};
}));
// node_modules/@smithy/signature-v4/dist-es/SignatureV4Base.js
var import_client$2, import_protocols$6, import_serde$10, SignatureV4Base;
var init_SignatureV4Base = __esmMin((() => {
	import_client$2 = require_client();
	import_protocols$6 = require_protocols$1();
	import_serde$10 = require_serde();
	init_getCanonicalQuery();
	init_utilDate();
	SignatureV4Base = class {
		service;
		regionProvider;
		credentialProvider;
		sha256;
		uriEscapePath;
		applyChecksum;
		constructor({ applyChecksum, credentials, region, service, sha256, uriEscapePath = true }) {
			this.service = service;
			this.sha256 = sha256;
			this.uriEscapePath = uriEscapePath;
			this.applyChecksum = typeof applyChecksum === "boolean" ? applyChecksum : true;
			this.regionProvider = (0, import_client$2.normalizeProvider)(region);
			this.credentialProvider = (0, import_client$2.normalizeProvider)(credentials);
		}
		createCanonicalRequest(request, canonicalHeaders, payloadHash) {
			const sortedHeaders = Object.keys(canonicalHeaders).sort();
			return `${request.method}
${this.getCanonicalPath(request)}
${getCanonicalQuery(request)}
${sortedHeaders.map((name) => `${name}:${canonicalHeaders[name]}`).join("\n")}

${sortedHeaders.join(";")}
${payloadHash}`;
		}
		async createStringToSign(longDate, credentialScope, canonicalRequest, algorithmIdentifier) {
			const hash = new this.sha256();
			hash.update((0, import_serde$10.toUint8Array)(canonicalRequest));
			const hashedRequest = await hash.digest();
			return `${algorithmIdentifier}
${longDate}
${credentialScope}
${(0, import_serde$10.toHex)(hashedRequest)}`;
		}
		getCanonicalPath({ path }) {
			if (this.uriEscapePath) {
				const normalizedPathSegments = [];
				for (const pathSegment of path.split("/")) {
					if (pathSegment?.length === 0) continue;
					if (pathSegment === ".") continue;
					if (pathSegment === "..") normalizedPathSegments.pop();
					else normalizedPathSegments.push(pathSegment);
				}
				const normalizedPath = `${path?.startsWith("/") ? "/" : ""}${normalizedPathSegments.join("/")}${normalizedPathSegments.length > 0 && path?.endsWith("/") ? "/" : ""}`;
				return (0, import_protocols$6.escapeUri)(normalizedPath).replace(/%2F/g, "/");
			}
			return path;
		}
		validateResolvedCredentials(credentials) {
			if (typeof credentials !== "object" || typeof credentials.accessKeyId !== "string" || typeof credentials.secretAccessKey !== "string") throw new Error("Resolved credential object is not valid");
		}
		formatDate(now) {
			const longDate = iso8601(now).replace(/[-:]/g, "");
			return {
				longDate,
				shortDate: longDate.slice(0, 8)
			};
		}
		getCanonicalHeaderList(headers) {
			return Object.keys(headers).sort().join(";");
		}
	};
}));
// node_modules/@smithy/signature-v4/dist-es/credentialDerivation.js
var import_serde$9, signingKeyCache, cacheQueue, createScope, getSigningKey, clearCredentialCache, hmac;
var init_credentialDerivation = __esmMin((() => {
	import_serde$9 = require_serde();
	init_constants$1();
	signingKeyCache = {};
	cacheQueue = [];
	createScope = (shortDate, region, service) => `${shortDate}/${region}/${service}/${KEY_TYPE_IDENTIFIER}`;
	getSigningKey = async (sha256Constructor, credentials, shortDate, region, service) => {
		const credsHash = await hmac(sha256Constructor, credentials.secretAccessKey, credentials.accessKeyId);
		const cacheKey = `${shortDate}:${region}:${service}:${(0, import_serde$9.toHex)(credsHash)}:${credentials.sessionToken}`;
		if (cacheKey in signingKeyCache) return signingKeyCache[cacheKey];
		cacheQueue.push(cacheKey);
		while (cacheQueue.length > 50) delete signingKeyCache[cacheQueue.shift()];
		let key = `AWS4${credentials.secretAccessKey}`;
		for (const signable of [
			shortDate,
			region,
			service,
			KEY_TYPE_IDENTIFIER
		]) key = await hmac(sha256Constructor, key, signable);
		return signingKeyCache[cacheKey] = key;
	};
	clearCredentialCache = () => {
		cacheQueue.length = 0;
		Object.keys(signingKeyCache).forEach((cacheKey) => {
			delete signingKeyCache[cacheKey];
		});
	};
	hmac = (ctor, secret, data) => {
		const hash = new ctor(secret);
		hash.update((0, import_serde$9.toUint8Array)(data));
		return hash.digest();
	};
}));
// node_modules/@smithy/signature-v4/dist-es/getCanonicalHeaders.js
var getCanonicalHeaders;
var init_getCanonicalHeaders = __esmMin((() => {
	init_constants$1();
	getCanonicalHeaders = ({ headers }, unsignableHeaders, signableHeaders) => {
		const canonical = {};
		for (const headerName of Object.keys(headers).sort()) {
			if (headers[headerName] == void 0) continue;
			const canonicalHeaderName = headerName.toLowerCase();
			if (canonicalHeaderName in ALWAYS_UNSIGNABLE_HEADERS || unsignableHeaders?.has(canonicalHeaderName) || PROXY_HEADER_PATTERN.test(canonicalHeaderName) || SEC_HEADER_PATTERN.test(canonicalHeaderName)) {
				if (!signableHeaders || signableHeaders && !signableHeaders.has(canonicalHeaderName)) continue;
			}
			canonical[canonicalHeaderName] = headers[headerName].replace(/[\r\n]/g, " ").replace(/[ \t]+/g, " ").replace(/^ | $/g, "");
		}
		return canonical;
	};
}));
// node_modules/@smithy/signature-v4/dist-es/getPayloadHash.js
var import_serde$8, getPayloadHash;
var init_getPayloadHash = __esmMin((() => {
	import_serde$8 = require_serde();
	init_constants$1();
	getPayloadHash = async ({ headers, body }, hashConstructor) => {
		for (const headerName in headers) {
			if (!(0, import_serde$8.hasOwn)(headers, headerName)) continue;
			if (headerName.toLowerCase() === "x-amz-content-sha256") return headers[headerName];
		}
		if (body == void 0) return "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
		else if (typeof body === "string" || ArrayBuffer.isView(body) || (0, import_serde$8.isArrayBuffer)(body)) {
			const hashCtor = new hashConstructor();
			hashCtor.update((0, import_serde$8.toUint8Array)(body));
			return (0, import_serde$8.toHex)(await hashCtor.digest());
		}
		return UNSIGNED_PAYLOAD;
	};
}));
// node_modules/@smithy/signature-v4/dist-es/headerUtil.js
var import_serde$7, hasHeader;
var init_headerUtil = __esmMin((() => {
	import_serde$7 = require_serde();
	hasHeader = (soughtHeader, headers) => {
		soughtHeader = soughtHeader.toLowerCase();
		for (const headerName in headers) {
			if (!(0, import_serde$7.hasOwn)(headers, headerName)) continue;
			if (soughtHeader === headerName.toLowerCase()) return true;
		}
		return false;
	};
}));
// node_modules/@smithy/signature-v4/dist-es/moveHeadersToQuery.js
var import_serde$6, import_protocols$5, moveHeadersToQuery;
var init_moveHeadersToQuery = __esmMin((() => {
	import_serde$6 = require_serde();
	import_protocols$5 = require_protocols$1();
	moveHeadersToQuery = (request, options = {}) => {
		const { headers, query = {} } = import_protocols$5.HttpRequest.clone(request);
		for (const name in headers) {
			if (!(0, import_serde$6.hasOwn)(headers, name)) continue;
			const lname = name.toLowerCase();
			if (lname.slice(0, 6) === "x-amz-" && !options.unhoistableHeaders?.has(lname) || options.hoistableHeaders?.has(lname)) {
				query[name] = headers[name];
				delete headers[name];
			}
		}
		return {
			...request,
			headers,
			query
		};
	};
}));
// node_modules/@smithy/signature-v4/dist-es/prepareRequest.js
var import_serde$5, import_protocols$4, prepareRequest;
var init_prepareRequest = __esmMin((() => {
	import_serde$5 = require_serde();
	import_protocols$4 = require_protocols$1();
	init_constants$1();
	prepareRequest = (request) => {
		request = import_protocols$4.HttpRequest.clone(request);
		for (const headerName in request.headers) {
			if (!(0, import_serde$5.hasOwn)(request.headers, headerName)) continue;
			if (GENERATED_HEADERS.indexOf(headerName.toLowerCase()) > -1) delete request.headers[headerName];
		}
		return request;
	};
}));
// node_modules/@smithy/signature-v4/dist-es/SignatureV4.js
var import_serde$4, SignatureV4;
var init_SignatureV4 = __esmMin((() => {
	import_serde$4 = require_serde();
	init_HeaderFormatter();
	init_SignatureV4Base();
	init_constants$1();
	init_credentialDerivation();
	init_getCanonicalHeaders();
	init_getPayloadHash();
	init_headerUtil();
	init_moveHeadersToQuery();
	init_prepareRequest();
	SignatureV4 = class extends SignatureV4Base {
		headerFormatter = new HeaderFormatter();
		constructor({ applyChecksum, credentials, region, service, sha256, uriEscapePath = true }) {
			super({
				applyChecksum,
				credentials,
				region,
				service,
				sha256,
				uriEscapePath
			});
		}
		async presign(originalRequest, options = {}) {
			const { signingDate = /* @__PURE__ */ new Date(), expiresIn = 3600, unsignableHeaders, unhoistableHeaders, signableHeaders, hoistableHeaders, signingRegion, signingService } = options;
			const credentials = await this.credentialProvider();
			this.validateResolvedCredentials(credentials);
			const region = signingRegion ?? await this.regionProvider();
			const { longDate, shortDate } = this.formatDate(signingDate);
			if (expiresIn > 604800) return Promise.reject("Signature version 4 presigned URLs must have an expiration date less than one week in the future");
			const scope = createScope(shortDate, region, signingService ?? this.service);
			const request = moveHeadersToQuery(prepareRequest(originalRequest), {
				unhoistableHeaders,
				hoistableHeaders
			});
			if (credentials.sessionToken) request.query[TOKEN_QUERY_PARAM] = credentials.sessionToken;
			request.query[ALGORITHM_QUERY_PARAM] = ALGORITHM_IDENTIFIER;
			request.query[CREDENTIAL_QUERY_PARAM] = `${credentials.accessKeyId}/${scope}`;
			request.query[AMZ_DATE_QUERY_PARAM] = longDate;
			request.query[EXPIRES_QUERY_PARAM] = expiresIn.toString(10);
			const canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
			request.query[SIGNED_HEADERS_QUERY_PARAM] = this.getCanonicalHeaderList(canonicalHeaders);
			request.query[SIGNATURE_QUERY_PARAM] = await this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, await getPayloadHash(originalRequest, this.sha256)));
			return request;
		}
		async sign(toSign, options) {
			if (typeof toSign === "string") return this.signString(toSign, options);
			else if (toSign.headers && toSign.payload) return this.signEvent(toSign, options);
			else if (toSign.message) return this.signMessage(toSign, options);
			else return this.signRequest(toSign, options);
		}
		async signEvent({ headers, payload }, { signingDate = /* @__PURE__ */ new Date(), priorSignature, signingRegion, signingService, eventStreamCredentials }) {
			const region = signingRegion ?? await this.regionProvider();
			const { shortDate, longDate } = this.formatDate(signingDate);
			const scope = createScope(shortDate, region, signingService ?? this.service);
			const hashedPayload = await getPayloadHash({
				headers: {},
				body: payload
			}, this.sha256);
			const hash = new this.sha256();
			hash.update(headers);
			const hashedHeaders = (0, import_serde$4.toHex)(await hash.digest());
			const stringToSign = [
				EVENT_ALGORITHM_IDENTIFIER,
				longDate,
				scope,
				priorSignature,
				hashedHeaders,
				hashedPayload
			].join("\n");
			return this.signString(stringToSign, {
				signingDate,
				signingRegion: region,
				signingService,
				eventStreamCredentials
			});
		}
		async signMessage(signableMessage, { signingDate = /* @__PURE__ */ new Date(), signingRegion, signingService, eventStreamCredentials }) {
			return this.signEvent({
				headers: this.headerFormatter.format(signableMessage.message.headers),
				payload: signableMessage.message.body
			}, {
				signingDate,
				signingRegion,
				signingService,
				priorSignature: signableMessage.priorSignature,
				eventStreamCredentials
			}).then((signature) => {
				return {
					message: signableMessage.message,
					signature
				};
			});
		}
		async signString(stringToSign, { signingDate = /* @__PURE__ */ new Date(), signingRegion, signingService, eventStreamCredentials } = {}) {
			const credentials = eventStreamCredentials ?? await this.credentialProvider();
			this.validateResolvedCredentials(credentials);
			const region = signingRegion ?? await this.regionProvider();
			const { shortDate } = this.formatDate(signingDate);
			const hash = new this.sha256(await this.getSigningKey(credentials, region, shortDate, signingService));
			hash.update((0, import_serde$4.toUint8Array)(stringToSign));
			return (0, import_serde$4.toHex)(await hash.digest());
		}
		async signRequest(requestToSign, { signingDate = /* @__PURE__ */ new Date(), signableHeaders, unsignableHeaders, signingRegion, signingService } = {}) {
			const credentials = await this.credentialProvider();
			this.validateResolvedCredentials(credentials);
			const region = signingRegion ?? await this.regionProvider();
			const request = prepareRequest(requestToSign);
			const { longDate, shortDate } = this.formatDate(signingDate);
			const scope = createScope(shortDate, region, signingService ?? this.service);
			request.headers[AMZ_DATE_HEADER] = longDate;
			if (credentials.sessionToken) request.headers[TOKEN_HEADER] = credentials.sessionToken;
			const payloadHash = await getPayloadHash(request, this.sha256);
			if (!hasHeader("x-amz-content-sha256", request.headers) && this.applyChecksum) request.headers[SHA256_HEADER] = payloadHash;
			const canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
			const signature = await this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, payloadHash));
			request.headers[AUTH_HEADER] = `${ALGORITHM_IDENTIFIER} Credential=${credentials.accessKeyId}/${scope}, SignedHeaders=${this.getCanonicalHeaderList(canonicalHeaders)}, Signature=${signature}`;
			return request;
		}
		async getSignature(longDate, credentialScope, keyPromise, canonicalRequest) {
			const stringToSign = await this.createStringToSign(longDate, credentialScope, canonicalRequest, ALGORITHM_IDENTIFIER);
			const hash = new this.sha256(await keyPromise);
			hash.update((0, import_serde$4.toUint8Array)(stringToSign));
			return (0, import_serde$4.toHex)(await hash.digest());
		}
		getSigningKey(credentials, region, shortDate, service) {
			return getSigningKey(this.sha256, credentials, shortDate, region, service || this.service);
		}
	};
}));
// node_modules/@smithy/signature-v4/dist-es/signature-v4a-container.js
var signatureV4aContainer;
var init_signature_v4a_container = __esmMin((() => {
	signatureV4aContainer = { SignatureV4a: null };
}));
// node_modules/@smithy/signature-v4/dist-es/index.js
var dist_es_exports$3 = /* @__PURE__ */ __exportAll({
	ALGORITHM_IDENTIFIER: () => ALGORITHM_IDENTIFIER,
	ALGORITHM_IDENTIFIER_V4A: () => ALGORITHM_IDENTIFIER_V4A,
	ALGORITHM_QUERY_PARAM: () => ALGORITHM_QUERY_PARAM,
	ALWAYS_UNSIGNABLE_HEADERS: () => ALWAYS_UNSIGNABLE_HEADERS,
	AMZ_DATE_HEADER: () => AMZ_DATE_HEADER,
	AMZ_DATE_QUERY_PARAM: () => AMZ_DATE_QUERY_PARAM,
	AUTH_HEADER: () => AUTH_HEADER,
	CREDENTIAL_QUERY_PARAM: () => CREDENTIAL_QUERY_PARAM,
	DATE_HEADER: () => DATE_HEADER,
	EVENT_ALGORITHM_IDENTIFIER: () => EVENT_ALGORITHM_IDENTIFIER,
	EXPIRES_QUERY_PARAM: () => EXPIRES_QUERY_PARAM,
	GENERATED_HEADERS: () => GENERATED_HEADERS,
	HOST_HEADER: () => HOST_HEADER,
	KEY_TYPE_IDENTIFIER: () => KEY_TYPE_IDENTIFIER,
	MAX_CACHE_SIZE: () => 50,
	MAX_PRESIGNED_TTL: () => MAX_PRESIGNED_TTL,
	PROXY_HEADER_PATTERN: () => PROXY_HEADER_PATTERN,
	REGION_SET_PARAM: () => REGION_SET_PARAM,
	SEC_HEADER_PATTERN: () => SEC_HEADER_PATTERN,
	SHA256_HEADER: () => SHA256_HEADER,
	SIGNATURE_HEADER: () => SIGNATURE_HEADER,
	SIGNATURE_QUERY_PARAM: () => SIGNATURE_QUERY_PARAM,
	SIGNED_HEADERS_QUERY_PARAM: () => SIGNED_HEADERS_QUERY_PARAM,
	SignatureV4: () => SignatureV4,
	SignatureV4Base: () => SignatureV4Base,
	TOKEN_HEADER: () => TOKEN_HEADER,
	TOKEN_QUERY_PARAM: () => TOKEN_QUERY_PARAM,
	UNSIGNABLE_PATTERNS: () => UNSIGNABLE_PATTERNS,
	UNSIGNED_PAYLOAD: () => UNSIGNED_PAYLOAD,
	clearCredentialCache: () => clearCredentialCache,
	createScope: () => createScope,
	getCanonicalHeaders: () => getCanonicalHeaders,
	getCanonicalQuery: () => getCanonicalQuery,
	getPayloadHash: () => getPayloadHash,
	getSigningKey: () => getSigningKey,
	hasHeader: () => hasHeader,
	moveHeadersToQuery: () => moveHeadersToQuery,
	prepareRequest: () => prepareRequest,
	signatureV4aContainer: () => signatureV4aContainer
});
var init_dist_es$2 = __esmMin((() => {
	init_SignatureV4();
	init_constants$1();
	init_getCanonicalHeaders();
	init_getCanonicalQuery();
	init_getPayloadHash();
	init_moveHeadersToQuery();
	init_prepareRequest();
	init_credentialDerivation();
	init_SignatureV4Base();
	init_headerUtil();
	init_signature_v4a_container();
}));
// node_modules/@smithy/core/dist-cjs/submodules/cbor/index.js
var require_cbor = /* @__PURE__ */ __commonJSMin(((exports) => {
	var { nv, NumericValue, calculateBodyLength, generateIdempotencyToken, fromBase64, _parseEpochTimestamp } = require_serde();
	var { hasOwn, getSmithyContext } = require_transport();
	var { HttpRequest, collectBody, SerdeContext, RpcProtocol } = require_protocols$1();
	var { NormalizedSchema, deref, TypeRegistry } = require_schema();
	var majorUint64 = 0;
	var majorNegativeInt64 = 1;
	var majorUnstructuredByteString = 2;
	var majorUtf8String = 3;
	var majorList = 4;
	var majorMap = 5;
	var majorTag = 6;
	var majorSpecial = 7;
	var specialFalse = 20;
	var specialTrue = 21;
	var specialNull = 22;
	var specialUndefined = 23;
	var extendedOneByte = 24;
	var extendedFloat16 = 25;
	var extendedFloat32 = 26;
	var extendedFloat64 = 27;
	var minorIndefinite = 31;
	function alloc(size) {
		return typeof Buffer !== "undefined" ? Buffer.alloc(size) : new Uint8Array(size);
	}
	var tagSymbol = Symbol("@smithy/core/cbor::tagSymbol");
	function tag(data) {
		data[tagSymbol] = true;
		return data;
	}
	var USE_BUFFER$3 = typeof Buffer !== "undefined";
	var textDecoder$1 = new TextDecoder();
	var payload$1 = alloc(0);
	var isBuffer$1 = false;
	var dataView$2 = new DataView(payload$1.buffer, payload$1.byteOffset, payload$1.byteLength);
	var _offset = 0;
	function setPayload(bytes) {
		payload$1 = bytes;
		isBuffer$1 = USE_BUFFER$3 && payload$1 instanceof Buffer;
		dataView$2 = new DataView(payload$1.buffer, payload$1.byteOffset, payload$1.byteLength);
	}
	function decode(at, to) {
		if (at >= to) throw new Error("unexpected end of (decode) payload.");
		const major = (payload$1[at] & 224) >> 5;
		const minor = payload$1[at] & 31;
		if (minor === minorIndefinite && 2 <= major && major <= 5) return decodeIndefinite(at, to);
		switch (major) {
			case majorUint64:
			case majorNegativeInt64:
			case majorTag: {
				let unsignedInt;
				let offset;
				if (minor < 24) {
					unsignedInt = minor;
					offset = 1;
				} else switch (minor) {
					case extendedOneByte:
						if (to - at < 2) overflow$1(1);
						unsignedInt = payload$1[at + 1];
						offset = 2;
						break;
					case extendedFloat16:
						if (to - at < 3) overflow$1(2);
						unsignedInt = dataView$2.getUint16(at + 1);
						offset = 3;
						break;
					case extendedFloat32:
						if (to - at < 5) overflow$1(4);
						unsignedInt = dataView$2.getUint32(at + 1);
						offset = 5;
						break;
					case extendedFloat64:
						if (to - at < 9) overflow$1(8);
						{
							const hi = dataView$2.getUint32(at + 1);
							if (hi < 2097152) unsignedInt = hi * 4294967296 + dataView$2.getUint32(at + 5);
							else unsignedInt = dataView$2.getBigUint64(at + 1);
						}
						offset = 9;
						break;
					default: unexpectedMinor(minor);
				}
				if (major === majorUint64) {
					_offset = offset;
					return castBigInt$1(unsignedInt);
				} else if (major === majorNegativeInt64) {
					let negativeInt;
					if (typeof unsignedInt === "bigint") negativeInt = BigInt(-1) - unsignedInt;
					else negativeInt = -1 - unsignedInt;
					_offset = offset;
					return castBigInt$1(negativeInt);
				} else return decodeTagValue(at, to, minor, unsignedInt, offset);
			}
			case majorUtf8String: return decodeUtf8String(at, to);
			case majorMap: return decodeMap(at, to);
			case majorList: return decodeList(at, to);
			case majorUnstructuredByteString: return decodeUnstructuredByteString(at, to);
			default: return decodeSpecial(at, to);
		}
	}
	function decodeIndefinite(at, to) {
		const major = (payload$1[at] & 224) >> 5;
		if ((payload$1[at] & 31) === minorIndefinite) switch (major) {
			case majorUtf8String: return decodeUtf8StringIndefinite(at, to);
			case majorMap: return decodeMapIndefinite(at, to);
			case majorList: return decodeListIndefinite(at, to);
			case majorUnstructuredByteString: return decodeUnstructuredByteStringIndefinite(at, to);
		}
	}
	function bytesToFloat16$1(a, b) {
		const sign = a >> 7;
		const exponent = (a & 124) >> 2;
		const fraction = (a & 3) << 8 | b;
		const scalar = sign === 0 ? 1 : -1;
		if (exponent === 0) {
			if (fraction === 0) return 0;
			return scalar * (Math.pow(2, -14) * (fraction / 1024));
		} else if (exponent === 31) {
			if (fraction === 0) return scalar * Infinity;
			return NaN;
		}
		return scalar * (Math.pow(2, exponent - 15) * (1 + fraction / 1024));
	}
	function decodeMap(at, to) {
		const mapDataLength = decodeCount$1(at, to);
		if (mapDataLength < 25) return decodeMapSmall(at, to, mapDataLength);
		return decodeMapLarge(at, to, mapDataLength);
	}
	function decodeMapLarge(at, to, mapDataLength) {
		const offset = _offset;
		at += offset;
		const base = at;
		const map = Object.create(null);
		for (let i = 0; i < mapDataLength; ++i) {
			const key = decodeUtf8String(at, to);
			at += _offset;
			if ((payload$1[at] & 224) >> 5 === majorUtf8String) map[key] = decodeUtf8String(at, to);
			else map[key] = decode(at, to);
			at += _offset;
		}
		_offset = offset + (at - base);
		Object.setPrototypeOf(map, Object.prototype);
		return map;
	}
	function decodeMapSmall(at, to, mapDataLength) {
		const offset = _offset;
		at += offset;
		const base = at;
		const map = {};
		for (let i = 0; i < mapDataLength; ++i) {
			const key = decodeUtf8String(at, to);
			at += _offset;
			map[key] = decode(at, to);
			at += _offset;
		}
		_offset = offset + (at - base);
		return map;
	}
	function decodeList(at, to) {
		const listDataLength = decodeCount$1(at, to);
		const offset = _offset;
		at += offset;
		const base = at;
		const list = Array(listDataLength);
		for (let i = 0; i < listDataLength; ++i) {
			list[i] = decode(at, to);
			at += _offset;
		}
		_offset = offset + (at - base);
		return list;
	}
	function decodeUtf8String(at, to) {
		const length = decodeCount$1(at, to);
		const offset = _offset;
		at += offset;
		if (to - at < length) overflow$1(length);
		_offset = offset + length;
		if (length < 24) return decodeUtf8StringCached(at, length);
		if (isBuffer$1) return payload$1.toString("utf-8", at, at + length);
		return textDecoder$1.decode(payload$1.subarray(at, at + length));
	}
	var stringCache$1 = new Array(2048);
	var stringCacheEpochs$1 = /* @__PURE__ */ new Uint16Array(2048);
	var cacheEpoch$1 = 0;
	function advanceDecodingEpoch() {
		cacheEpoch$1 = cacheEpoch$1 + 1 & 65535;
	}
	function decodeUtf8StringCached(at, length) {
		let h = length;
		for (let i = 0; i < length; ++i) h = h * 31 + payload$1[at + i] | 0;
		const slot = h >>> 0 & 2047;
		const cached = stringCache$1[slot];
		if (cached !== void 0) {
			if (cached.length === length) {
				let match = true;
				for (let i = 0; i < length; ++i) if (cached.charCodeAt(i) !== payload$1[at + i]) {
					match = false;
					break;
				}
				if (match) {
					stringCacheEpochs$1[slot] = cacheEpoch$1;
					return cached;
				}
			}
		}
		const result = isBuffer$1 ? payload$1.toString("utf-8", at, at + length) : textDecoder$1.decode(payload$1.subarray(at, at + length));
		if (stringCacheEpochs$1[slot] !== cacheEpoch$1) {
			stringCache$1[slot] = result;
			stringCacheEpochs$1[slot] = cacheEpoch$1;
		}
		return result;
	}
	function decodeUnstructuredByteString(at, to) {
		const length = decodeCount$1(at, to);
		const offset = _offset;
		at += offset;
		if (to - at < length) overflow$1(length);
		const value = payload$1.subarray(at, at + length);
		_offset = offset + length;
		return value;
	}
	function decodeTagValue(at, to, minor, unsignedInt, offset) {
		if (minor === 2 || minor === 3) {
			const length = decodeCount$1(at + offset, to);
			let b = BigInt(0);
			const start = at + offset + _offset;
			for (let i = start; i < start + length; ++i) b = b << BigInt(8) | BigInt(payload$1[i]);
			_offset = offset + _offset + length;
			return minor === 3 ? -b - BigInt(1) : b;
		} else if (minor === 4) {
			const [rawExponent, mantissa] = decode(at + offset, to);
			const absMantissa = BigInt(mantissa < 0 ? -1 : 1) * BigInt(mantissa);
			const mantissaDigits = String(absMantissa);
			const sign = mantissa < 0 ? "-" : "";
			let numericString;
			if (typeof rawExponent === "number" && Math.abs(rawExponent) <= 2 ** 28) {
				const exponent = rawExponent;
				const mantissaStr = "0".repeat(Math.abs(exponent) + 1) + mantissaDigits;
				numericString = exponent === 0 ? mantissaStr : mantissaStr.slice(0, mantissaStr.length + exponent) + "." + mantissaStr.slice(exponent);
				numericString = numericString.replace(/^0+/g, "");
				if (numericString === "") numericString = "0";
				if (numericString[0] === ".") numericString = "0" + numericString;
				numericString = sign + numericString;
			} else {
				const bigExponent = BigInt(rawExponent);
				if (mantissaDigits.length === 1) numericString = sign + mantissaDigits + "e" + String(bigExponent);
				else {
					const adjustedExp = bigExponent + BigInt(mantissaDigits.length - 1);
					numericString = sign + mantissaDigits[0] + "." + mantissaDigits.slice(1) + "e" + String(adjustedExp);
				}
			}
			_offset = offset + _offset;
			return nv(numericString);
		} else {
			const value = decode(at + offset, to);
			_offset = offset + _offset;
			return tag({
				tag: castBigInt$1(unsignedInt),
				value
			});
		}
	}
	function decodeSpecial(at, to) {
		const minor = payload$1[at] & 31;
		switch (minor) {
			case specialTrue:
			case specialFalse:
				_offset = 1;
				return minor === specialTrue;
			case specialNull:
				_offset = 1;
				return null;
			case specialUndefined:
				_offset = 1;
				return null;
			case extendedFloat16:
				if (to - at < 3) throw new Error("incomplete float16 at end of buf.");
				_offset = 3;
				return bytesToFloat16$1(payload$1[at + 1], payload$1[at + 2]);
			case extendedFloat32:
				if (to - at < 5) throw new Error("incomplete float32 at end of buf.");
				_offset = 5;
				return dataView$2.getFloat32(at + 1);
			case extendedFloat64:
				if (to - at < 9) throw new Error("incomplete float64 at end of buf.");
				_offset = 9;
				return dataView$2.getFloat64(at + 1);
			default: unexpectedMinor(minor);
		}
	}
	function decodeCount$1(at, to) {
		const minor = payload$1[at] & 31;
		if (minor < 24) {
			_offset = 1;
			return minor;
		}
		switch (minor) {
			case extendedOneByte:
				if (to - at < 2) overflow$1(1);
				_offset = 2;
				return payload$1[at + 1];
			case extendedFloat16:
				if (to - at < 3) overflow$1(2);
				_offset = 3;
				return dataView$2.getUint16(at + 1);
			case extendedFloat32:
				if (to - at < 5) overflow$1(4);
				_offset = 5;
				return dataView$2.getUint32(at + 1);
			case extendedFloat64:
				if (to - at < 9) overflow$1(8);
				_offset = 9;
				return demote(dataView$2.getBigUint64(at + 1));
			default: unexpectedMinor(minor);
		}
	}
	function decodeMapIndefinite(at, to) {
		at += 1;
		const base = at;
		const map = {};
		for (; at < to;) {
			if (payload$1[at] === 255) {
				_offset = at - base + 2;
				return map;
			}
			const key = decodeUtf8String(at, to);
			at += _offset;
			map[key] = decode(at, to);
			at += _offset;
		}
		throw new Error("expected break marker.");
	}
	function decodeListIndefinite(at, to) {
		at += 1;
		const list = [];
		for (const base = at; at < to;) {
			if (payload$1[at] === 255) {
				_offset = at - base + 2;
				return list;
			}
			list.push(decode(at, to));
			at += _offset;
		}
		throw new Error("expected break marker.");
	}
	function decodeUtf8StringIndefinite(at, to) {
		at += 1;
		const vector = [];
		for (const base = at; at < to;) {
			if (payload$1[at] === 255) {
				const data = alloc(vector.length);
				data.set(vector, 0);
				_offset = at - base + 2;
				if (USE_BUFFER$3) return data.toString("utf-8", 0, data.length);
				return textDecoder$1.decode(data);
			}
			const major = (payload$1[at] & 224) >> 5;
			const minor = payload$1[at] & 31;
			if (major !== majorUtf8String) unexpectedMajorInIndefiniteString(major);
			if (minor === minorIndefinite) throw new Error("nested indefinite string.");
			const bytes = decodeUnstructuredByteString(at, to);
			at += _offset;
			for (let i = 0; i < bytes.length; ++i) vector.push(bytes[i]);
		}
		throw new Error("expected break marker.");
	}
	function decodeUnstructuredByteStringIndefinite(at, to) {
		at += 1;
		const vector = [];
		for (const base = at; at < to;) {
			if (payload$1[at] === 255) {
				const data = alloc(vector.length);
				data.set(vector, 0);
				_offset = at - base + 2;
				return data;
			}
			const major = (payload$1[at] & 224) >> 5;
			const minor = payload$1[at] & 31;
			if (major !== majorUnstructuredByteString) unexpectedMajorInIndefiniteString(major);
			if (minor === minorIndefinite) throw new Error("nested indefinite string.");
			const bytes = decodeUnstructuredByteString(at, to);
			at += _offset;
			for (let i = 0; i < bytes.length; ++i) vector.push(bytes[i]);
		}
		throw new Error("expected break marker.");
	}
	function castBigInt$1(bigInt) {
		if (typeof bigInt === "number") return bigInt;
		const num = Number(bigInt);
		if (Number.MIN_SAFE_INTEGER <= num && num <= Number.MAX_SAFE_INTEGER) return num;
		return bigInt;
	}
	function demote(bigInteger) {
		const num = Number(bigInteger);
		if (num < Number.MIN_SAFE_INTEGER || Number.MAX_SAFE_INTEGER < num) console.warn(/* @__PURE__ */ new Error(`@smithy/core/cbor - truncating BigInt(${bigInteger}) to ${num} with loss of precision.`));
		return num;
	}
	function overflow$1(n) {
		throw new Error(`length ${n} greater than remaining buf len.`);
	}
	function unexpectedMinor(minor) {
		throw new Error(`unexpected minor value ${minor}.`);
	}
	function unexpectedMajorInIndefiniteString(major) {
		throw new Error(`unexpected major type ${major} in indefinite string.`);
	}
	var USE_BUFFER$2 = typeof Buffer !== "undefined";
	var encodeStringCache = /* @__PURE__ */ new Map();
	var encodeCacheEpoch$1 = 0;
	var encodeCacheSaturated$1 = false;
	var data = alloc(2048);
	var dataView$1 = new DataView(data.buffer, data.byteOffset, data.byteLength);
	var cursor$1 = 0;
	function encode(_input) {
		const encodeStack = [_input];
		while (encodeStack.length) {
			const input = encodeStack.pop();
			if (typeof input === "string") {
				const len = input.length;
				if (USE_BUFFER$2) {
					ensureSpace(len * 3 + 9);
					if (len > 23) {
						encodeHeader$1(majorUtf8String, Buffer.byteLength(input));
						cursor$1 += data.write(input, cursor$1);
					} else encodeStringCached(input);
				} else {
					ensureSpace(len * 3 + 9);
					const headerPos = cursor$1;
					const byteLen = new TextEncoder().encodeInto(input, data.subarray(cursor$1 + 9)).written;
					let headerSize;
					if (byteLen < 24) headerSize = 1;
					else if (byteLen < 256) headerSize = 2;
					else if (byteLen < 65536) headerSize = 3;
					else if (byteLen < 4294967296) headerSize = 5;
					else headerSize = 9;
					if (headerSize < 9) data.copyWithin(headerPos + headerSize, headerPos + 9, headerPos + 9 + byteLen);
					cursor$1 = headerPos;
					encodeInteger(majorUtf8String, byteLen);
					cursor$1 += byteLen;
				}
				continue;
			}
			if (data.byteLength - cursor$1 < 9) ensureSpace(64);
			if (typeof input === "number") {
				if (Number.isInteger(input) && input >= -9007199254740992 && input <= 9007199254740991) {
					const nonNegative = input >= 0;
					const major = nonNegative ? majorUint64 : majorNegativeInt64;
					const value = nonNegative ? input : -input - 1;
					if (value < 24) data[cursor$1++] = major << 5 | value;
					else if (value < 256) {
						data[cursor$1++] = major << 5 | 24;
						data[cursor$1++] = value;
					} else if (value < 65536) {
						data[cursor$1++] = major << 5 | extendedFloat16;
						data[cursor$1++] = value >> 8;
						data[cursor$1++] = value & 255;
					} else if (value < 4294967296) {
						data[cursor$1++] = major << 5 | extendedFloat32;
						dataView$1.setUint32(cursor$1, value);
						cursor$1 += 4;
					} else {
						data[cursor$1++] = major << 5 | extendedFloat64;
						const hi = value / 4294967296 | 0;
						const lo = value - hi * 4294967296 | 0;
						dataView$1.setUint32(cursor$1, hi);
						dataView$1.setUint32(cursor$1 + 4, lo);
						cursor$1 += 8;
					}
					continue;
				}
				data[cursor$1++] = 251;
				dataView$1.setFloat64(cursor$1, input);
				cursor$1 += 8;
				continue;
			} else if (typeof input === "bigint") {
				const nonNegative = input >= 0;
				const major = nonNegative ? majorUint64 : majorNegativeInt64;
				const value = nonNegative ? input : -input - BigInt(1);
				if (value < BigInt("18446744073709551616")) {
					const n = Number(value);
					if (n < 4294967296) encodeInteger(major, n);
					else {
						data[cursor$1++] = major << 5 | extendedFloat64;
						dataView$1.setBigUint64(cursor$1, value);
						cursor$1 += 8;
					}
				} else {
					const binaryBigInt = value.toString(2);
					const bigIntBytes = new Uint8Array(Math.ceil(binaryBigInt.length / 8));
					let b = value;
					let i = 0;
					while (bigIntBytes.byteLength - ++i >= 0) {
						bigIntBytes[bigIntBytes.byteLength - i] = Number(b & BigInt(255));
						b >>= BigInt(8);
					}
					ensureSpace(bigIntBytes.byteLength * 2 + 16);
					data[cursor$1++] = nonNegative ? 194 : 195;
					encodeHeader$1(majorUnstructuredByteString, bigIntBytes.byteLength);
					data.set(bigIntBytes, cursor$1);
					cursor$1 += bigIntBytes.byteLength;
				}
				continue;
			} else if (input === null) {
				data[cursor$1++] = 246;
				continue;
			} else if (typeof input === "boolean") {
				data[cursor$1++] = 224 | (input ? specialTrue : specialFalse);
				continue;
			} else if (typeof input === "undefined") throw new Error("@smithy/core/cbor: client may not serialize undefined value.");
			else if (Array.isArray(input)) {
				encodeInteger(majorList, input.length);
				ensureSpace(input.length * 9 + 64);
				for (let i = input.length - 1; i >= 0; --i) encodeStack.push(input[i]);
				continue;
			} else if (typeof input.byteLength === "number") {
				ensureSpace(input.length * 2 + 9);
				encodeInteger(majorUnstructuredByteString, input.length);
				data.set(input, cursor$1);
				cursor$1 += input.byteLength;
				continue;
			} else if (typeof input === "object") {
				if (input instanceof NumericValue) {
					let str = input.string;
					let expOffset = BigInt(0);
					const eIndex = str.search(/[eE]/);
					if (eIndex !== -1) {
						expOffset = BigInt(str.slice(eIndex + 1));
						str = str.slice(0, eIndex);
					}
					const decimalIndex = str.indexOf(".");
					const fractionDigits = decimalIndex === -1 ? 0 : str.length - decimalIndex - 1;
					const exponent = expOffset - BigInt(fractionDigits);
					const mantissa = BigInt(str.replace(".", ""));
					data[cursor$1++] = 196;
					encodeInteger(majorList, 2);
					encodeStack.push(mantissa);
					encodeStack.push(exponent >= -9007199254740992n && exponent <= 9007199254740991n ? Number(exponent) : exponent);
					continue;
				}
				if (input[tagSymbol]) {
					if ("tag" in input && "value" in input) {
						encodeStack.push(input.value);
						encodeHeader$1(majorTag, input.tag);
						continue;
					} else throw new Error("tag encountered with missing fields, need 'tag' and 'value', found: " + JSON.stringify(input));
				}
				const keys = Object.keys(input);
				const len = keys.length;
				encodeInteger(majorMap, len);
				for (let i = len - 1; i >= 0; --i) {
					encodeStack.push(input[keys[i]]);
					encodeStack.push(keys[i]);
				}
				continue;
			}
			throw new Error(`data type ${input?.constructor?.name ?? typeof input} not compatible for encoding.`);
		}
	}
	function advanceEncodingEpoch() {
		encodeCacheEpoch$1 = encodeCacheEpoch$1 + 1 & 65535;
		encodeCacheSaturated$1 = false;
	}
	function toUint8Array() {
		const out = alloc(cursor$1);
		out.set(data.subarray(0, cursor$1), 0);
		cursor$1 = 0;
		return out;
	}
	function resize(size) {
		const old = data;
		data = alloc(size);
		if (old) {
			if (old.copy) old.copy(data, 0, 0, old.byteLength);
			else data.set(old, 0);
		}
		dataView$1 = new DataView(data.buffer, data.byteOffset, data.byteLength);
	}
	function encodeStringCached(input) {
		const cached = encodeStringCache.get(input);
		if (cached !== void 0) {
			data.set(cached.bytes, cursor$1);
			cursor$1 += cached.bytes.length;
			cached.epoch = encodeCacheEpoch$1;
			return;
		}
		const start = cursor$1;
		encodeInteger(majorUtf8String, Buffer.byteLength(input));
		cursor$1 += data.write(input, cursor$1);
		const bytes = Uint8Array.prototype.slice.call(data, start, cursor$1);
		if (encodeStringCache.size >= 2048) {
			if (encodeCacheSaturated$1) return;
			let evicted = 0;
			for (const [key, entry] of encodeStringCache) {
				if (evicted >= 1024) break;
				if (entry.epoch !== encodeCacheEpoch$1) {
					encodeStringCache.delete(key);
					evicted++;
				}
			}
			if (evicted === 0) {
				encodeCacheSaturated$1 = true;
				return;
			}
		}
		if (encodeStringCache.size < 2048) encodeStringCache.set(input, {
			epoch: encodeCacheEpoch$1,
			bytes
		});
	}
	function ensureSpace(bytes) {
		if (data.byteLength - cursor$1 < bytes) {
			if (cursor$1 < 16e6) resize(Math.max(data.byteLength * 4, data.byteLength + bytes));
			else resize(data.byteLength + bytes + 16e6);
		}
	}
	function encodeHeader$1(major, value) {
		if (value < 24) data[cursor$1++] = major << 5 | value;
		else if (value < 256) {
			data[cursor$1++] = major << 5 | 24;
			data[cursor$1++] = value;
		} else if (value < 65536) {
			data[cursor$1++] = major << 5 | extendedFloat16;
			dataView$1.setUint16(cursor$1, value);
			cursor$1 += 2;
		} else if (value < 4294967296) {
			data[cursor$1++] = major << 5 | extendedFloat32;
			dataView$1.setUint32(cursor$1, value);
			cursor$1 += 4;
		} else {
			data[cursor$1++] = major << 5 | extendedFloat64;
			dataView$1.setBigUint64(cursor$1, typeof value === "bigint" ? value : BigInt(value));
			cursor$1 += 8;
		}
	}
	function encodeInteger(major, value) {
		if (value < 24) data[cursor$1++] = major << 5 | value;
		else if (value < 256) {
			data[cursor$1++] = major << 5 | 24;
			data[cursor$1++] = value;
		} else if (value < 65536) {
			data[cursor$1++] = major << 5 | extendedFloat16;
			data[cursor$1++] = value >> 8;
			data[cursor$1++] = value & 255;
		} else if (value < 4294967296) {
			data[cursor$1++] = major << 5 | extendedFloat32;
			dataView$1.setUint32(cursor$1, value);
			cursor$1 += 4;
		} else {
			data[cursor$1++] = major << 5 | extendedFloat64;
			const hi = value / 4294967296 | 0;
			const lo = value - hi * 4294967296 | 0;
			dataView$1.setUint32(cursor$1, hi);
			dataView$1.setUint32(cursor$1 + 4, lo);
			cursor$1 += 8;
		}
	}
	var cbor = {
		deserialize(payload) {
			advanceDecodingEpoch();
			setPayload(payload);
			return decode(0, payload.length);
		},
		serialize(input) {
			advanceEncodingEpoch();
			try {
				encode(input);
				return toUint8Array();
			} catch (e) {
				toUint8Array();
				throw e;
			}
		},
		resizeEncodingBuffer(size) {
			resize(size);
		}
	};
	var parseCborBody = (streamBody, context) => {
		return collectBody(streamBody, context).then(async (bytes) => {
			if (bytes.length) try {
				return cbor.deserialize(bytes);
			} catch (e) {
				Object.defineProperty(e, "$responseBodyText", { value: context.utf8Encoder(bytes) });
				throw e;
			}
			return {};
		});
	};
	var dateToTag = (date) => {
		return tag({
			tag: 1,
			value: date.getTime() / 1e3
		});
	};
	var parseCborErrorBody = async (errorBody, context) => {
		const value = await parseCborBody(errorBody, context);
		value.message = value.message ?? value.Message;
		return value;
	};
	var loadSmithyRpcV2CborErrorCode = (output, data) => {
		const sanitizeErrorCode = (rawValue) => {
			let cleanValue = rawValue;
			if (typeof cleanValue === "number") cleanValue = cleanValue.toString();
			if (cleanValue.indexOf(",") >= 0) cleanValue = cleanValue.split(",")[0];
			if (cleanValue.indexOf(":") >= 0) cleanValue = cleanValue.split(":")[0];
			return cleanValue;
		};
		if (data["__type"] !== void 0) return sanitizeErrorCode(data["__type"]);
	};
	var checkCborResponse = (response) => {
		if (String(response.headers["smithy-protocol"]).toLowerCase() !== "rpc-v2-cbor") throw new Error("Malformed RPCv2 CBOR response, status: " + response.statusCode);
	};
	var buildHttpRpcRequest = async (context, headers, path, resolvedHostname, body) => {
		const endpoint = await context.endpoint();
		const { hostname, protocol = "https", port, path: basePath } = endpoint;
		const contents = {
			protocol,
			hostname,
			port,
			method: "POST",
			path: basePath.endsWith("/") ? basePath.slice(0, -1) + path : basePath + path,
			headers: { ...headers }
		};
		if (resolvedHostname !== void 0) contents.hostname = resolvedHostname;
		if (endpoint.headers) for (const name in endpoint.headers) {
			if (!hasOwn(endpoint.headers, name)) continue;
			contents.headers[name] = endpoint.headers[name];
		}
		if (body !== void 0) {
			contents.body = body;
			try {
				contents.headers["content-length"] = String(calculateBodyLength(body));
			} catch (ignored) {}
		}
		return new HttpRequest(contents);
	};
	var CborShapeSerializer2 = class extends SerdeContext {
		write(schema, value) {
			cursor = 0;
			writeValue(NormalizedSchema.of(schema), value, void 0, this.serdeContext);
		}
		flush() {
			const result = buf.subarray(0, cursor);
			cursor = 0;
			buf = allocUnsafe(INITIAL_BUFFER_SIZE);
			view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
			return result;
		}
	};
	var CBOR_STRUCT_CACHE = Symbol.for("@smithy/cbor-struct-cache");
	function loadCborStructIterator(ns) {
		const schema = ns.getSchema();
		const existing = schema[CBOR_STRUCT_CACHE];
		if (existing) return existing;
		const memberNames = [];
		const memberSchemas = [];
		for (const [name, memberSchema] of ns.structIterator()) {
			memberNames.push(name);
			memberSchemas.push(memberSchema);
		}
		const encodedKeys = new Array(memberNames.length);
		for (let i = 0; i < memberNames.length; ++i) encodedKeys[i] = encodeCborStringKey(memberNames[i]);
		const cache = {
			memberNames,
			memberSchemas,
			encodedKeys
		};
		schema[CBOR_STRUCT_CACHE] = cache;
		return cache;
	}
	function encodeCborStringKey(s) {
		let utf8Bytes;
		if (USE_BUFFER$1) utf8Bytes = Buffer.from(s, "utf-8");
		else utf8Bytes = new TextEncoder().encode(s);
		const byteLen = utf8Bytes.length;
		let headerSize;
		if (byteLen < 24) headerSize = 1;
		else if (byteLen < 256) headerSize = 2;
		else headerSize = 3;
		const result = new Uint8Array(headerSize + byteLen);
		if (headerSize === 1) result[0] = 96 | byteLen;
		else if (headerSize === 2) {
			result[0] = 120;
			result[1] = byteLen;
		} else {
			result[0] = 121;
			result[1] = byteLen >> 8;
			result[2] = byteLen & 255;
		}
		result.set(utf8Bytes, headerSize);
		return result;
	}
	var USE_BUFFER$1 = typeof Buffer !== "undefined";
	var textEncoder = new TextEncoder();
	var INITIAL_BUFFER_SIZE = 2048;
	var buf = USE_BUFFER$1 ? Buffer.allocUnsafe(INITIAL_BUFFER_SIZE) : new Uint8Array(INITIAL_BUFFER_SIZE);
	var view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
	var cursor = 0;
	var STRING_CACHE_MAX = 2048;
	var stringEncodeCache = /* @__PURE__ */ new Map();
	var encodeCacheEpoch = 0;
	var encodeCacheSaturated = false;
	function allocUnsafe(size) {
		return USE_BUFFER$1 ? Buffer.allocUnsafe(size) : new Uint8Array(size);
	}
	function writeValue(ns, value, container, serdeContext) {
		if (value == null) {
			if (value === void 0 && ns.isIdempotencyToken()) {
				writeString(generateIdempotencyToken());
				return;
			}
			ensure(1);
			buf[cursor++] = 246;
			return;
		}
		if (ns.isUnitSchema()) {
			ensure(1);
			encodeHeader(majorMap, 0);
			return;
		}
		if (typeof value === "object") {
			if (ns.isBlobSchema()) {
				if (value instanceof Uint8Array) {
					writeBytes(value);
					return;
				}
			}
			if (ns.isTimestampSchema()) {
				if (value instanceof Date) {
					writeTimestamp(value);
					return;
				}
			}
			if (ns.isStructSchema()) {
				writeStruct(ns, value, serdeContext);
				return;
			}
			if (Array.isArray(value) && (ns.isListSchema() || ns.isDocumentSchema())) {
				writeList(ns, value, ns.isDocumentSchema(), serdeContext);
				return;
			}
			if (ns.isMapSchema()) {
				writeMap(ns, value, false, serdeContext);
				return;
			}
			if (value instanceof Date) {
				writeTimestamp(value);
				return;
			}
			if (value instanceof Uint8Array) {
				writeBytes(value);
				return;
			}
			if (value instanceof NumericValue) {
				writeNumericValue(value);
				return;
			}
			if (value[tagSymbol]) {
				const tagged = value;
				writeTag(tagged.tag, tagged.value);
				return;
			}
			if (ns.isDocumentSchema()) {
				if (Array.isArray(value)) writeList(ns, value, true, serdeContext);
				else writeMap(ns, value, true, serdeContext);
				return;
			}
			if (ns.isBigDecimalSchema()) {
				writeUntypedValue(value);
				return;
			}
			writeMap(ns, value, true, serdeContext);
			return;
		}
		if (typeof value === "string") {
			if (ns.isBlobSchema()) {
				writeBytes((serdeContext?.base64Decoder ?? fromBase64)(value));
				return;
			}
			writeString(value);
			return;
		}
		if (typeof value === "number") {
			ensure(9);
			if (Number.isInteger(value) && value >= -9007199254740992 && value <= 9007199254740991) writeInteger(value);
			else writeFloat64(value);
			return;
		}
		if (typeof value === "boolean") {
			ensure(1);
			buf[cursor++] = 224 | (value ? specialTrue : specialFalse);
			return;
		}
		if (typeof value === "bigint") {
			writeBigInt(value);
			return;
		}
		writeString(String(value));
	}
	function writeStruct(ns, value, serdeContext) {
		if (ns.isUnionSchema()) {
			let wrote = false;
			for (const [memberName, memberSchema] of ns.structIterator()) {
				const item = value[memberName];
				if (item != null) {
					ensure(9);
					encodeHeader(majorMap, 1);
					writeString(memberName);
					writeValue(memberSchema, item, ns, serdeContext);
					wrote = true;
					break;
				}
			}
			if (!wrote) {
				const { $unknown } = value;
				if (Array.isArray($unknown)) {
					ensure(9);
					encodeHeader(majorMap, 1);
					writeString($unknown[0]);
					writeUntypedValue($unknown[1]);
				} else {
					ensure(9);
					encodeHeader(majorMap, 0);
				}
			}
			return;
		}
		const { memberNames, memberSchemas, encodedKeys } = loadCborStructIterator(ns);
		const z = memberNames.length;
		let headerSize;
		if (z < 24) headerSize = 1;
		else if (z < 256) headerSize = 2;
		else headerSize = 3;
		ensure(headerSize);
		const headerPos = cursor;
		cursor += headerSize;
		let count = 0;
		for (let i = 0; i < z; ++i) {
			const item = value[memberNames[i]];
			if (item == null && !memberSchemas[i].isIdempotencyToken()) continue;
			const key = encodedKeys[i];
			ensure(key.length);
			buf.set(key, cursor);
			cursor += key.length;
			writeValue(memberSchemas[i], item, ns, serdeContext);
			++count;
		}
		if (typeof value.__type === "string") for (const k in value) {
			if (!hasOwn(value, k)) continue;
			if (!memberNames.includes(k)) {
				writeString(k);
				writeUntypedValue(value[k]);
				++count;
			}
		}
		if (headerSize === 1) buf[headerPos] = 160 | count;
		else if (headerSize === 2) {
			buf[headerPos] = 184;
			buf[headerPos + 1] = count;
		} else {
			buf[headerPos] = 185;
			buf[headerPos + 1] = count >> 8;
			buf[headerPos + 2] = count & 255;
		}
	}
	function writeList(ns, value, isDocument, serdeContext) {
		const sparse = !!ns.getMergedTraits().sparse;
		const valueSchema = ns.getValueSchema();
		if (isDocument || sparse) {
			const items = [];
			for (let i = 0; i < value.length; ++i) {
				const item = value[i];
				if (isDocument) {
					if (item !== void 0) items.push(item);
				} else if (item != null || sparse) items.push(item);
			}
			ensure(9);
			encodeHeader(majorList, items.length);
			for (let i = 0; i < items.length; ++i) writeValue(valueSchema, items[i], void 0, serdeContext);
		} else {
			let count = 0;
			for (let i = 0; i < value.length; ++i) if (value[i] != null) ++count;
			ensure(9);
			encodeHeader(majorList, count);
			for (let i = 0; i < value.length; ++i) if (value[i] != null) writeValue(valueSchema, value[i], void 0, serdeContext);
		}
	}
	function writeMap(ns, value, isDocument, serdeContext) {
		const sparse = !!ns.getMergedTraits().sparse;
		const valueSchema = ns.getValueSchema();
		const keys = [];
		for (const k in value) {
			if (!hasOwn(value, k)) continue;
			const v = value[k];
			if (isDocument ? v !== void 0 : v != null || sparse) keys.push(k);
		}
		ensure(9);
		encodeHeader(majorMap, keys.length);
		for (let i = 0; i < keys.length; ++i) {
			const k = keys[i];
			writeString(k);
			writeValue(valueSchema, value[k], void 0, serdeContext);
		}
	}
	function writeUntypedValue(value) {
		if (value == null) {
			ensure(1);
			buf[cursor++] = 246;
			return;
		}
		if (typeof value === "string") {
			writeString(value);
			return;
		}
		if (typeof value === "number") {
			ensure(9);
			if (Number.isInteger(value) && value >= -9007199254740992 && value <= 9007199254740991) writeInteger(value);
			else writeFloat64(value);
			return;
		}
		if (typeof value === "boolean") {
			ensure(1);
			buf[cursor++] = 224 | (value ? specialTrue : specialFalse);
			return;
		}
		if (typeof value === "bigint") {
			writeBigInt(value);
			return;
		}
		if (value instanceof Uint8Array) {
			writeBytes(value);
			return;
		}
		if (value instanceof Date) {
			writeTimestamp(value);
			return;
		}
		if (value instanceof NumericValue) {
			writeNumericValue(value);
			return;
		}
		if (value[tagSymbol]) {
			const tagged = value;
			writeTag(tagged.tag, tagged.value);
			return;
		}
		if (Array.isArray(value)) {
			ensure(9);
			encodeHeader(majorList, value.length);
			for (let i = 0; i < value.length; ++i) writeUntypedValue(value[i]);
			return;
		}
		if (typeof value === "object") {
			const keys = Object.keys(value);
			ensure(9);
			encodeHeader(majorMap, keys.length);
			for (let i = 0; i < keys.length; ++i) {
				writeString(keys[i]);
				writeUntypedValue(value[keys[i]]);
			}
			return;
		}
		writeString(String(value));
	}
	function ensure(n) {
		if (cursor + n > buf.length) {
			let newSize = buf.length * 2;
			while (newSize < cursor + n) newSize *= 2;
			const next = allocUnsafe(newSize);
			next.set(buf.subarray(0, cursor));
			buf = next;
			view = new DataView(next.buffer, next.byteOffset, next.byteLength);
		}
	}
	function encodeHeader(major, value) {
		if (value < 24) buf[cursor++] = major << 5 | value;
		else if (value < 256) {
			buf[cursor++] = major << 5 | 24;
			buf[cursor++] = value;
		} else if (value < 65536) {
			buf[cursor++] = major << 5 | extendedFloat16;
			buf[cursor++] = value >> 8;
			buf[cursor++] = value & 255;
		} else if (value < 4294967296) {
			buf[cursor++] = major << 5 | extendedFloat32;
			view.setUint32(cursor, value);
			cursor += 4;
		} else {
			buf[cursor++] = major << 5 | extendedFloat64;
			const hi = value / 4294967296 | 0;
			const lo = value - hi * 4294967296 | 0;
			view.setUint32(cursor, hi);
			view.setUint32(cursor + 4, lo);
			cursor += 8;
		}
	}
	function encodeBigHeader(major, value) {
		const n = Number(value);
		if (n < 4294967296) {
			encodeHeader(major, n);
			return;
		}
		buf[cursor++] = major << 5 | extendedFloat64;
		view.setBigUint64(cursor, value);
		cursor += 8;
	}
	function writeString(s) {
		const len = s.length;
		if (len <= 23) {
			const cached = stringEncodeCache.get(s);
			if (cached) {
				ensure(cached.bytes.length);
				buf.set(cached.bytes, cursor);
				cursor += cached.bytes.length;
				cached.epoch = encodeCacheEpoch;
				return;
			}
			const start = cursor;
			writeStringUncached(s, len);
			const end = cursor;
			const bytes = Uint8Array.prototype.slice.call(buf, start, end);
			if (stringEncodeCache.size >= STRING_CACHE_MAX) {
				if (encodeCacheSaturated) return;
				let evicted = 0;
				for (const [key, entry] of stringEncodeCache) {
					if (evicted >= 1024) break;
					if (entry.epoch !== encodeCacheEpoch) {
						stringEncodeCache.delete(key);
						++evicted;
					}
				}
				if (evicted === 0) {
					encodeCacheSaturated = true;
					return;
				}
			}
			if (stringEncodeCache.size < STRING_CACHE_MAX) stringEncodeCache.set(s, {
				epoch: encodeCacheEpoch,
				bytes
			});
			return;
		}
		writeStringUncached(s, len);
	}
	function writeStringUncached(s, len) {
		if (USE_BUFFER$1) {
			ensure(len * 3 + 9);
			encodeHeader(majorUtf8String, Buffer.byteLength(s));
			cursor += buf.write(s, cursor);
		} else {
			ensure(len * 3 + 9);
			const headerPos = cursor;
			const byteLen = textEncoder.encodeInto(s, buf.subarray(headerPos + 9)).written;
			let headerSize;
			if (byteLen < 24) headerSize = 1;
			else if (byteLen < 256) headerSize = 2;
			else if (byteLen < 65536) headerSize = 3;
			else if (byteLen < 4294967296) headerSize = 5;
			else headerSize = 9;
			if (headerSize < 9) buf.copyWithin(headerPos + headerSize, headerPos + 9, headerPos + 9 + byteLen);
			cursor = headerPos;
			encodeHeader(majorUtf8String, byteLen);
			cursor += byteLen;
		}
	}
	function writeFloat64(value) {
		ensure(9);
		buf[cursor++] = 251;
		view.setFloat64(cursor, value);
		cursor += 8;
	}
	function writeInteger(value) {
		ensure(9);
		const nonNegative = value >= 0;
		encodeHeader(nonNegative ? majorUint64 : majorNegativeInt64, nonNegative ? value : -value - 1);
	}
	function writeBigInt(value) {
		const nonNegative = value >= 0;
		const major = nonNegative ? majorUint64 : majorNegativeInt64;
		const abs = nonNegative ? value : -value - BigInt(1);
		if (abs < BigInt("18446744073709551616")) {
			ensure(9);
			encodeBigHeader(major, abs);
		} else {
			const binaryStr = abs.toString(2);
			const byteLen = Math.ceil(binaryStr.length / 8);
			const bigIntBytes = new Uint8Array(byteLen);
			let b = abs;
			for (let i = byteLen - 1; i >= 0; --i) {
				bigIntBytes[i] = Number(b & BigInt(255));
				b >>= BigInt(8);
			}
			ensure(byteLen + 16);
			buf[cursor++] = nonNegative ? 194 : 195;
			encodeHeader(majorUnstructuredByteString, byteLen);
			buf.set(bigIntBytes, cursor);
			cursor += byteLen;
		}
	}
	function writeBytes(data) {
		ensure(data.length + 9);
		encodeHeader(majorUnstructuredByteString, data.length);
		buf.set(data, cursor);
		cursor += data.length;
	}
	function writeTag(tagValue, innerValue) {
		ensure(9);
		if (typeof tagValue === "bigint") encodeBigHeader(majorTag, tagValue);
		else encodeHeader(majorTag, tagValue);
		writeUntypedValue(innerValue);
	}
	function writeNumericValue(nv) {
		let str = nv.string;
		let expOffset = BigInt(0);
		const eIndex = str.search(/[eE]/);
		if (eIndex !== -1) {
			expOffset = BigInt(str.slice(eIndex + 1));
			str = str.slice(0, eIndex);
		}
		const decimalIndex = str.indexOf(".");
		const fractionDigits = decimalIndex === -1 ? 0 : str.length - decimalIndex - 1;
		const exponent = expOffset - BigInt(fractionDigits);
		const mantissa = BigInt(str.replace(".", ""));
		ensure(9);
		buf[cursor++] = 196;
		encodeHeader(majorList, 2);
		ensure(9);
		if (exponent >= -9007199254740992n && exponent <= 9007199254740991n) writeInteger(Number(exponent));
		else writeBigInt(exponent);
		writeBigInt(mantissa);
	}
	function writeTimestamp(date) {
		ensure(18);
		encodeHeader(majorTag, 1);
		const epochSecs = date.getTime() / 1e3;
		if (Number.isInteger(epochSecs)) writeInteger(epochSecs);
		else writeFloat64(epochSecs);
	}
	var CborShapeDeserializer2 = class extends SerdeContext {
		read(schema, bytes) {
			payload = bytes;
			isBuffer = USE_BUFFER && bytes instanceof Buffer;
			dataView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
			pos = 0;
			end = bytes.length;
			cacheEpoch = cacheEpoch + 1 & 65535;
			return readValue(NormalizedSchema.of(schema));
		}
		readValue(_schema, value) {
			return transformObject(NormalizedSchema.of(_schema), value);
		}
	};
	var USE_BUFFER = typeof Buffer !== "undefined";
	var textDecoder = new TextDecoder();
	var payload = /* @__PURE__ */ new Uint8Array(0);
	var isBuffer = false;
	var dataView = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(0));
	var pos = 0;
	var end = 0;
	var STRING_CACHE_SIZE = 2048;
	var stringCache = new Array(STRING_CACHE_SIZE);
	var stringCacheEpochs = new Uint16Array(STRING_CACHE_SIZE);
	var cacheEpoch = 0;
	function readValue(ns) {
		if (pos >= end) throw new Error("unexpected end of CBOR payload.");
		const major = (payload[pos] & 224) >> 5;
		if ((payload[pos] & 31) === minorIndefinite && major >= 2 && major <= 5) return readIndefinite(ns, major);
		switch (major) {
			case majorUint64: return readUnsignedInt();
			case majorNegativeInt64: return readNegativeInt();
			case majorUnstructuredByteString: return readByteString();
			case majorUtf8String: return readUtf8String();
			case majorList: return readList(ns);
			case majorMap: return readMap(ns);
			case majorTag: return readTag();
			case majorSpecial: return readSpecial();
			default: throw new Error(`unexpected CBOR major type ${major}.`);
		}
	}
	function readList(ns) {
		const count = decodeCount();
		const memberSchema = ns.isListSchema() ? ns.getValueSchema() : ns;
		const list = Array(count);
		for (let i = 0; i < count; ++i) list[i] = readValue(memberSchema);
		return list;
	}
	function readMap(ns) {
		const count = decodeCount();
		if (ns.isStructSchema()) return readStruct(ns, count, pos);
		const valueSchema = ns.isMapSchema() ? ns.getValueSchema() : ns;
		const map = {};
		for (let i = 0; i < count; ++i) {
			const key = readUtf8String();
			map[key] = readValue(valueSchema);
		}
		return map;
	}
	function readStruct(ns, count, startPos) {
		const isUnion = ns.isUnionSchema();
		const { memberSchemas, encodedKeys, memberNames } = loadCborStructIterator(ns);
		const z = encodedKeys.length;
		const result = {};
		let unknownKey;
		let unknownValue;
		let unknownCount = 0;
		let hasType = false;
		let hint = 0;
		for (let i = 0; i < count; ++i) {
			const matchIdx = matchStructKey(encodedKeys, z, hint);
			if (matchIdx >= 0) {
				hint = matchIdx + 1;
				if (hint >= z) hint = 0;
				const val = readValue(memberSchemas[matchIdx]);
				if (val != null) result[memberNames[matchIdx]] = val;
			} else {
				const key = readUtf8String();
				const val = readValue(NormalizedSchema.of(15));
				if (key === "__type" && typeof val === "string") hasType = true;
				else {
					unknownKey = key;
					unknownValue = val;
					++unknownCount;
				}
			}
		}
		if (isUnion) {
			let resultEmpty = true;
			for (const _ in result) {
				if (!hasOwn(result, _)) continue;
				resultEmpty = false;
				break;
			}
			if (resultEmpty && unknownCount === 1) result.$unknown = [unknownKey, unknownValue];
		} else if (hasType) {
			pos = startPos;
			const docSchema = NormalizedSchema.of(15);
			for (let i = 0; i < count; ++i) {
				const key = readUtf8String();
				const val = readValue(docSchema);
				if (!(key in result)) result[key] = val;
			}
		}
		return result;
	}
	function readTag(ns) {
		const tagNum = decodeArgument();
		const tagNumber = typeof tagNum === "bigint" ? Number(tagNum) : tagNum;
		if (tagNumber === 1) return _parseEpochTimestamp(readValue(NormalizedSchema.of(15)));
		if (tagNumber === 2 || tagNumber === 3) {
			const byteStr = readByteString();
			let b = BigInt(0);
			for (let i = 0; i < byteStr.length; ++i) b = b << BigInt(8) | BigInt(byteStr[i]);
			return tagNumber === 3 ? -b - BigInt(1) : b;
		}
		if (tagNumber === 4) {
			const [rawExponent, mantissa] = readValue(NormalizedSchema.of(15));
			const absMantissa = BigInt(mantissa < 0 ? -1 : 1) * BigInt(mantissa);
			const mantissaDigits = String(absMantissa);
			const sign = mantissa < 0 ? "-" : "";
			let numericString;
			if (typeof rawExponent === "number" && Math.abs(rawExponent) <= 2 ** 28) {
				const exponent = rawExponent;
				const mantissaStr = "0".repeat(Math.abs(exponent) + 1) + mantissaDigits;
				numericString = exponent === 0 ? mantissaStr : mantissaStr.slice(0, mantissaStr.length + exponent) + "." + mantissaStr.slice(exponent);
				numericString = numericString.replace(/^0+/g, "");
				if (numericString === "") numericString = "0";
				if (numericString[0] === ".") numericString = "0" + numericString;
				numericString = sign + numericString;
			} else {
				const bigExponent = BigInt(rawExponent);
				if (mantissaDigits.length === 1) numericString = sign + mantissaDigits + "e" + String(bigExponent);
				else {
					const adjustedExp = bigExponent + BigInt(mantissaDigits.length - 1);
					numericString = sign + mantissaDigits[0] + "." + mantissaDigits.slice(1) + "e" + String(adjustedExp);
				}
			}
			return nv(numericString);
		}
		const innerValue = readValue(NormalizedSchema.of(15));
		return {
			tag: castBigInt(tagNum),
			value: innerValue
		};
	}
	function readIndefinite(ns, major) {
		switch (major) {
			case majorUtf8String: return readUtf8StringIndefinite();
			case majorUnstructuredByteString: return readByteStringIndefinite();
			case majorList: return readListIndefinite(ns);
			case majorMap: return readMapIndefinite(ns);
			default: throw new Error(`unexpected indefinite length for major ${major}.`);
		}
	}
	function readUtf8StringIndefinite() {
		pos += 1;
		const chunks = [];
		let totalLen = 0;
		while (pos < end) {
			if (payload[pos] === 255) {
				pos += 1;
				const combined = new Uint8Array(totalLen);
				let offset = 0;
				for (let i = 0; i < chunks.length; ++i) {
					combined.set(chunks[i], offset);
					offset += chunks[i].length;
				}
				if (USE_BUFFER) return Buffer.from(combined.buffer, combined.byteOffset, combined.byteLength).toString("utf-8");
				return textDecoder.decode(combined);
			}
			const bytes = readByteString();
			chunks.push(bytes);
			totalLen += bytes.length;
		}
		throw new Error("expected break marker.");
	}
	function readByteStringIndefinite() {
		pos += 1;
		const chunks = [];
		let totalLen = 0;
		while (pos < end) {
			if (payload[pos] === 255) {
				pos += 1;
				const combined = new Uint8Array(totalLen);
				let offset = 0;
				for (let i = 0; i < chunks.length; ++i) {
					combined.set(chunks[i], offset);
					offset += chunks[i].length;
				}
				return combined;
			}
			const bytes = readByteString();
			chunks.push(bytes);
			totalLen += bytes.length;
		}
		throw new Error("expected break marker.");
	}
	function readListIndefinite(ns) {
		pos += 1;
		const memberSchema = ns.isListSchema() ? ns.getValueSchema() : ns;
		const list = [];
		while (pos < end) {
			if (payload[pos] === 255) {
				pos += 1;
				return list;
			}
			list.push(readValue(memberSchema));
		}
		throw new Error("expected break marker.");
	}
	function readMapIndefinite(ns) {
		pos += 1;
		if (ns.isStructSchema()) {
			const { memberSchemas, encodedKeys, memberNames } = loadCborStructIterator(ns);
			const z = encodedKeys.length;
			const isUnion = ns.isUnionSchema();
			const result = {};
			let unknownKey;
			let unknownValue;
			let unknownCount = 0;
			let hint = 0;
			while (pos < end) {
				if (payload[pos] === 255) {
					pos += 1;
					if (isUnion) {
						let resultEmpty = true;
						for (const _ in result) {
							if (!hasOwn(result, _)) continue;
							resultEmpty = false;
							break;
						}
						if (resultEmpty && unknownCount === 1) result.$unknown = [unknownKey, unknownValue];
					}
					return result;
				}
				const matchIdx = matchStructKey(encodedKeys, z, hint);
				if (matchIdx >= 0) {
					hint = matchIdx + 1;
					if (hint >= z) hint = 0;
					const val = readValue(memberSchemas[matchIdx]);
					if (val != null) result[memberNames[matchIdx]] = val;
				} else {
					const key = readUtf8String();
					const val = readValue(NormalizedSchema.of(15));
					if (key !== "__type") {
						unknownKey = key;
						unknownValue = val;
						++unknownCount;
					}
				}
			}
			throw new Error("expected break marker.");
		}
		const valueSchema = ns.isMapSchema() ? ns.getValueSchema() : ns;
		const map = {};
		while (pos < end) {
			if (payload[pos] === 255) {
				pos += 1;
				return map;
			}
			const key = readUtf8String();
			map[key] = readValue(valueSchema);
		}
		throw new Error("expected break marker.");
	}
	function matchStructKey(encodedKeys, z, hint) {
		const hintKey = encodedKeys[hint];
		if (pos + hintKey.length <= end && bytesMatch(pos, hintKey)) {
			pos += hintKey.length;
			return hint;
		}
		for (let i = 0; i < z; ++i) {
			if (i === hint) continue;
			const ek = encodedKeys[i];
			if (pos + ek.length <= end && bytesMatch(pos, ek)) {
				pos += ek.length;
				return i;
			}
		}
		return -1;
	}
	function bytesMatch(at, expected) {
		const len = expected.length;
		if (payload[at] !== expected[0]) return false;
		for (let i = 1; i < len; ++i) if (payload[at + i] !== expected[i]) return false;
		return true;
	}
	function decodeArgument() {
		const minor = payload[pos] & 31;
		if (minor < 24) {
			pos += 1;
			return minor;
		}
		switch (minor) {
			case extendedOneByte:
				if (end - pos < 2) overflow(1);
				pos += 2;
				return payload[pos - 1];
			case extendedFloat16:
				if (end - pos < 3) overflow(2);
				pos += 3;
				return dataView.getUint16(pos - 2);
			case extendedFloat32:
				if (end - pos < 5) overflow(4);
				pos += 5;
				return dataView.getUint32(pos - 4);
			case extendedFloat64: {
				if (end - pos < 9) overflow(8);
				pos += 9;
				const hi = dataView.getUint32(pos - 8);
				if (hi < 2097152) return hi * 4294967296 + dataView.getUint32(pos - 4);
				return dataView.getBigUint64(pos - 8);
			}
			default: throw new Error(`unexpected minor value ${minor}.`);
		}
	}
	function decodeCount() {
		const val = decodeArgument();
		return typeof val === "bigint" ? Number(val) : val;
	}
	function readUnsignedInt() {
		return castBigInt(decodeArgument());
	}
	function readNegativeInt() {
		const val = decodeArgument();
		if (typeof val === "bigint") return BigInt(-1) - val;
		return -1 - val;
	}
	function readByteString() {
		const length = decodeCount();
		if (end - pos < length) overflow(length);
		const start = pos;
		pos += length;
		return payload.subarray(start, start + length);
	}
	function readUtf8String() {
		const length = decodeCount();
		if (end - pos < length) overflow(length);
		const start = pos;
		pos += length;
		if (length < 24) return decodeUtf8Cached(start, length);
		if (isBuffer) return payload.toString("utf-8", start, start + length);
		return textDecoder.decode(payload.subarray(start, start + length));
	}
	function decodeUtf8Cached(at, length) {
		let h = length;
		for (let i = 0; i < length; ++i) h = h * 31 + payload[at + i] | 0;
		const slot = h >>> 0 & 2047;
		const cached = stringCache[slot];
		if (cached !== void 0 && cached.length === length) {
			let match = true;
			for (let i = 0; i < length; ++i) if (cached.charCodeAt(i) !== payload[at + i]) {
				match = false;
				break;
			}
			if (match) {
				stringCacheEpochs[slot] = cacheEpoch;
				return cached;
			}
		}
		const result = isBuffer ? payload.toString("utf-8", at, at + length) : textDecoder.decode(payload.subarray(at, at + length));
		if (stringCacheEpochs[slot] !== cacheEpoch) {
			stringCache[slot] = result;
			stringCacheEpochs[slot] = cacheEpoch;
		}
		return result;
	}
	function readSpecial() {
		const p = pos;
		const minor = payload[p] & 31;
		switch (minor) {
			case specialTrue:
				pos = p + 1;
				return true;
			case specialFalse:
				pos = p + 1;
				return false;
			case specialNull:
				pos = p + 1;
				return null;
			case specialUndefined:
				pos = p + 1;
				return null;
			case extendedFloat16:
				if (end - p < 3) overflow(2);
				pos = p + 3;
				return bytesToFloat16(payload[p + 1], payload[p + 2]);
			case extendedFloat32:
				if (end - p < 5) overflow(4);
				pos = p + 5;
				return dataView.getFloat32(p + 1);
			case extendedFloat64:
				if (end - p < 9) overflow(8);
				pos = p + 9;
				return dataView.getFloat64(p + 1);
			default: throw new Error(`unexpected minor value ${minor} for major 7.`);
		}
	}
	function bytesToFloat16(a, b) {
		const sign = a >> 7;
		const exponent = (a & 124) >> 2;
		const fraction = (a & 3) << 8 | b;
		const scalar = sign === 0 ? 1 : -1;
		if (exponent === 0) {
			if (fraction === 0) return 0;
			return scalar * (Math.pow(2, -14) * (fraction / 1024));
		} else if (exponent === 31) {
			if (fraction === 0) return scalar * Infinity;
			return NaN;
		}
		return scalar * (Math.pow(2, exponent - 15) * (1 + fraction / 1024));
	}
	function castBigInt(value) {
		if (typeof value === "number") return value;
		const num = Number(value);
		if (Number.MIN_SAFE_INTEGER <= num && num <= Number.MAX_SAFE_INTEGER) return num;
		return value;
	}
	function overflow(n) {
		throw new Error(`CBOR: length ${n} greater than remaining buffer length.`);
	}
	function transformObject(ns, value) {
		if (ns.isTimestampSchema()) {
			if (typeof value === "number") return _parseEpochTimestamp(value);
			if (typeof value === "object" && value !== null) {
				if (value.tag === 1 && "value" in value) return _parseEpochTimestamp(value.value);
			}
		}
		if (ns.isBlobSchema()) return value;
		if (typeof value === "undefined" || typeof value === "boolean" || typeof value === "number" || typeof value === "string" || typeof value === "bigint" || typeof value === "symbol") return value;
		if (typeof value !== "object" || value === null) return value;
		if ("byteLength" in value) return value;
		if (value instanceof Date) return value;
		if (value instanceof NumericValue) return value;
		if (ns.isDocumentSchema()) return value;
		if (ns.isListSchema()) {
			const memberSchema = ns.getValueSchema();
			const out = [];
			for (const item of value) out.push(transformObject(memberSchema, item));
			return out;
		}
		const newObject = {};
		if (ns.isMapSchema()) {
			const targetSchema = ns.getValueSchema();
			for (const key in value) {
				if (!hasOwn(value, key)) continue;
				newObject[key] = transformObject(targetSchema, value[key]);
			}
		} else if (ns.isStructSchema()) {
			const isUnion = ns.isUnionSchema();
			let keys;
			if (isUnion) {
				keys = /* @__PURE__ */ new Set();
				for (const k in value) {
					if (!hasOwn(value, k)) continue;
					if (k !== "__type") keys.add(k);
				}
			}
			for (const [key, memberSchema] of ns.structIterator()) {
				if (isUnion) keys.delete(key);
				if (value[key] != null) newObject[key] = transformObject(memberSchema, value[key]);
			}
			if (isUnion && keys?.size === 1) {
				let newObjectEmpty = true;
				for (const _ in newObject) {
					if (!hasOwn(newObject, _)) continue;
					newObjectEmpty = false;
					break;
				}
				if (newObjectEmpty) {
					const k = keys.values().next().value;
					newObject.$unknown = [k, value[k]];
				}
			} else if (typeof value.__type === "string") for (const k in value) {
				if (!hasOwn(value, k)) continue;
				if (!(k in newObject)) newObject[k] = value[k];
			}
		}
		return newObject;
	}
	var CborCodec = class extends SerdeContext {
		createSerializer() {
			const serializer = new CborShapeSerializer2();
			serializer.setSerdeContext(this.serdeContext);
			return serializer;
		}
		createDeserializer() {
			const deserializer = new CborShapeDeserializer2();
			deserializer.setSerdeContext(this.serdeContext);
			return deserializer;
		}
	};
	var SmithyRpcV2CborProtocol = class extends RpcProtocol {
		codec = new CborCodec();
		serializer = this.codec.createSerializer();
		deserializer = this.codec.createDeserializer();
		constructor({ defaultNamespace, errorTypeRegistries }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
		}
		getShapeId() {
			return "smithy.protocols#rpcv2Cbor";
		}
		getPayloadCodec() {
			return this.codec;
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			Object.assign(request.headers, {
				"content-type": this.getDefaultContentType(),
				"smithy-protocol": "rpc-v2-cbor",
				accept: this.getDefaultContentType()
			});
			if (deref(operationSchema.input) === "unit") {
				delete request.body;
				delete request.headers["content-type"];
			} else {
				if (!request.body) {
					this.serializer.write(15, {});
					request.body = this.serializer.flush();
				}
				if (request.body instanceof Uint8Array) request.headers["content-length"] = String(request.body.byteLength);
			}
			const { service, operation } = getSmithyContext(context);
			const path = `/service/${service}/operation/${operation}`;
			if (request.path.endsWith("/")) request.path += path.slice(1);
			else request.path += path;
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			return super.deserializeResponse(operationSchema, context, response);
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorIdentifier = loadSmithyRpcV2CborErrorCode(response, dataObject) ?? "Unknown";
			const preferredNamespaces = ["*"];
			const { defaultNamespace } = this.options;
			preferredNamespaces.unshift(defaultNamespace);
			const [namespace, errorShapeName] = (() => {
				if (errorIdentifier.includes("#")) return errorIdentifier.split("#");
				return [void 0, errorIdentifier];
			})();
			if (namespace) preferredNamespaces.unshift(namespace);
			const errorMetadata = {
				$metadata: metadata,
				$fault: response.statusCode < 500 ? "client" : "server"
			};
			const preferredRegistries = [this.compositeErrorRegistry];
			if (namespace) preferredRegistries.push(TypeRegistry.for(namespace));
			preferredRegistries.push(TypeRegistry.for(defaultNamespace));
			const [errorSchema, ErrorCtor, errorMode] = this.resolveError(errorShapeName, preferredNamespaces, preferredRegistries);
			if (errorMode === "native" || errorMode === "synthetic") {
				if (dataObject.Message) dataObject.message = dataObject.Message;
				const error = errorMode === "synthetic" ? new ErrorCtor({ name: errorShapeName }) : new Error(errorShapeName);
				throw Object.assign(error, errorMetadata, dataObject);
			}
			const ns = NormalizedSchema.of(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "Unknown";
			const exception = new ErrorCtor({});
			const output = {};
			for (const [name, member] of ns.structIterator()) output[name] = this.deserializer.readValue(member, dataObject[name]);
			throw Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output);
		}
		getDefaultContentType() {
			return "application/cbor";
		}
	};
	var CborShapeSerializer = class extends SerdeContext {
		value;
		write(schema, value) {
			this.value = this.serialize(schema, value);
		}
		serialize(schema, source) {
			const ns = NormalizedSchema.of(schema);
			if (source == null) {
				if (ns.isIdempotencyToken()) return generateIdempotencyToken();
				return source;
			}
			if (ns.isBlobSchema()) {
				if (typeof source === "string") return (this.serdeContext?.base64Decoder ?? fromBase64)(source);
				return source;
			}
			if (ns.isTimestampSchema()) {
				if (typeof source === "number" || typeof source === "bigint") return dateToTag(/* @__PURE__ */ new Date(Number(source) / 1e3 | 0));
				return dateToTag(source);
			}
			if (typeof source === "function" || typeof source === "object") {
				const sourceObject = source;
				if (ns.isListSchema() && Array.isArray(sourceObject)) {
					const sparse = !!ns.getMergedTraits().sparse;
					const newArray = [];
					let i = 0;
					for (const item of sourceObject) {
						const value = this.serialize(ns.getValueSchema(), item);
						if (value != null || sparse) newArray[i++] = value;
					}
					return newArray;
				}
				if (sourceObject instanceof Date) return dateToTag(sourceObject);
				const newObject = {};
				if (ns.isMapSchema()) {
					const sparse = !!ns.getMergedTraits().sparse;
					for (const key in sourceObject) {
						if (!hasOwn(sourceObject, key)) continue;
						const value = this.serialize(ns.getValueSchema(), sourceObject[key]);
						if (value != null || sparse) newObject[key] = value;
					}
				} else if (ns.isStructSchema()) {
					for (const [key, memberSchema] of ns.structIterator()) {
						const value = this.serialize(memberSchema, sourceObject[key]);
						if (value != null) newObject[key] = value;
					}
					if (ns.isUnionSchema() && Array.isArray(sourceObject.$unknown)) {
						const [k, v] = sourceObject.$unknown;
						newObject[k] = v;
					} else if (typeof sourceObject.__type === "string") for (const k in sourceObject) {
						if (!hasOwn(sourceObject, k)) continue;
						if (!(k in newObject)) newObject[k] = this.serialize(15, sourceObject[k]);
					}
				} else if (ns.isDocumentSchema()) {
					if (Array.isArray(sourceObject)) {
						const newArray = [];
						let i = 0;
						for (const item of sourceObject) newArray[i++] = this.serialize(ns.getValueSchema(), item);
						return newArray;
					}
					for (const key in sourceObject) {
						if (!hasOwn(sourceObject, key)) continue;
						newObject[key] = this.serialize(ns.getValueSchema(), sourceObject[key]);
					}
				} else if (ns.isBigDecimalSchema()) return sourceObject;
				return newObject;
			}
			return source;
		}
		flush() {
			const buffer = cbor.serialize(this.value);
			this.value = void 0;
			return buffer;
		}
	};
	var CborShapeDeserializer = class extends SerdeContext {
		read(schema, bytes) {
			const data = cbor.deserialize(bytes);
			return this.readValue(schema, data);
		}
		readValue(_schema, value) {
			const ns = NormalizedSchema.of(_schema);
			if (ns.isTimestampSchema()) {
				if (typeof value === "number") return _parseEpochTimestamp(value);
				if (typeof value === "object") {
					if (value.tag === 1 && "value" in value) return _parseEpochTimestamp(value.value);
				}
			}
			if (ns.isBlobSchema()) {
				if (typeof value === "string") return (this.serdeContext?.base64Decoder ?? fromBase64)(value);
				return value;
			}
			if (typeof value === "undefined" || typeof value === "boolean" || typeof value === "number" || typeof value === "string" || typeof value === "bigint" || typeof value === "symbol") return value;
			else if (typeof value === "object") {
				if (value === null) return null;
				if ("byteLength" in value) return value;
				if (value instanceof Date) return value;
				if (ns.isDocumentSchema()) return value;
				if (ns.isListSchema()) {
					const newArray = [];
					const memberSchema = ns.getValueSchema();
					for (const item of value) {
						const itemValue = this.readValue(memberSchema, item);
						newArray.push(itemValue);
					}
					return newArray;
				}
				const newObject = {};
				if (ns.isMapSchema()) {
					const targetSchema = ns.getValueSchema();
					for (const key in value) {
						if (!hasOwn(value, key)) continue;
						newObject[key] = this.readValue(targetSchema, value[key]);
					}
				} else if (ns.isStructSchema()) {
					const isUnion = ns.isUnionSchema();
					let keys;
					if (isUnion) {
						keys = /* @__PURE__ */ new Set();
						for (const k in value) {
							if (!hasOwn(value, k)) continue;
							if (k !== "__type") keys.add(k);
						}
					}
					for (const [key, memberSchema] of ns.structIterator()) {
						if (isUnion) keys.delete(key);
						if (value[key] != null) newObject[key] = this.readValue(memberSchema, value[key]);
					}
					if (isUnion && keys?.size === 1) {
						let newObjectEmpty = true;
						for (const _ in newObject) {
							if (!hasOwn(newObject, _)) continue;
							newObjectEmpty = false;
							break;
						}
						if (newObjectEmpty) {
							const k = keys.values().next().value;
							newObject.$unknown = [k, value[k]];
						}
					} else if (typeof value.__type === "string") for (const k in value) {
						if (!hasOwn(value, k)) continue;
						if (!(k in newObject)) newObject[k] = value[k];
					}
				} else if (value instanceof NumericValue) return value;
				return newObject;
			} else return value;
		}
	};
	exports.CborCodec = CborCodec;
	exports.CborShapeDeserializer = CborShapeDeserializer;
	exports.CborShapeDeserializer2 = CborShapeDeserializer2;
	exports.CborShapeSerializer = CborShapeSerializer;
	exports.CborShapeSerializer2 = CborShapeSerializer2;
	exports.SmithyRpcV2CborProtocol = SmithyRpcV2CborProtocol;
	exports.buildHttpRpcRequest = buildHttpRpcRequest;
	exports.cbor = cbor;
	exports.checkCborResponse = checkCborResponse;
	exports.dateToTag = dateToTag;
	exports.loadSmithyRpcV2CborErrorCode = loadSmithyRpcV2CborErrorCode;
	exports.parseCborBody = parseCborBody;
	exports.parseCborErrorBody = parseCborErrorBody;
	exports.tag = tag;
	exports.tagSymbol = tagSymbol;
}));
// node_modules/@aws-sdk/xml-builder/dist-es/escape-attribute.js
function escapeAttribute(value) {
	return value.replace(ATTR_ESCAPE_RE, (ch) => ATTR_ESCAPE_MAP[ch]);
}
var ATTR_ESCAPE_RE, ATTR_ESCAPE_MAP;
var init_escape_attribute = __esmMin((() => {
	ATTR_ESCAPE_RE = /[&<>"]/g;
	ATTR_ESCAPE_MAP = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;"
	};
}));
// node_modules/@aws-sdk/xml-builder/dist-es/escape-element.js
function escapeElement(value) {
	return value.replace(ELEMENT_ESCAPE_RE, (ch) => ELEMENT_ESCAPE_MAP[ch]);
}
var ELEMENT_ESCAPE_RE, ELEMENT_ESCAPE_MAP;
var init_escape_element = __esmMin((() => {
	ELEMENT_ESCAPE_RE = /[&"'<>\r\n\u0085\u2028]/g;
	ELEMENT_ESCAPE_MAP = {
		"&": "&amp;",
		"\"": "&quot;",
		"'": "&apos;",
		"<": "&lt;",
		">": "&gt;",
		"\r": "&#x0D;",
		"\n": "&#x0A;",
		"": "&#x85;",
		"\u2028": "&#x2028;"
	};
}));
// node_modules/@aws-sdk/xml-builder/dist-es/XmlText.js
var XmlText;
var init_XmlText = __esmMin((() => {
	init_escape_element();
	XmlText = class {
		value;
		constructor(value) {
			this.value = value;
		}
		toString() {
			return escapeElement("" + this.value);
		}
	};
}));
// node_modules/@aws-sdk/xml-builder/dist-es/XmlNode.js
var XmlNode;
var init_XmlNode = __esmMin((() => {
	init_escape_attribute();
	init_XmlText();
	XmlNode = class XmlNode {
		name;
		children;
		attributes = {};
		static of(name, childText, withName) {
			const node = new XmlNode(name);
			if (childText !== void 0) node.addChildNode(new XmlText(childText));
			if (withName !== void 0) node.withName(withName);
			return node;
		}
		constructor(name, children = []) {
			this.name = name;
			this.children = children;
		}
		withName(name) {
			this.name = name;
			return this;
		}
		addAttribute(name, value) {
			this.attributes[name] = value;
			return this;
		}
		addChildNode(child) {
			this.children.push(child);
			return this;
		}
		removeAttribute(name) {
			delete this.attributes[name];
			return this;
		}
		n(name) {
			this.name = name;
			return this;
		}
		c(child) {
			this.children.push(child);
			return this;
		}
		a(name, value) {
			if (value != null) this.attributes[name] = value;
			return this;
		}
		cc(input, field, withName = field) {
			if (input[field] != null) {
				const node = XmlNode.of(field, input[field]).withName(withName);
				this.c(node);
			}
		}
		l(input, listName, memberName, valueProvider) {
			if (input[listName] != null) valueProvider().map((node) => {
				node.withName(memberName);
				this.c(node);
			});
		}
		lc(input, listName, memberName, valueProvider) {
			if (input[listName] != null) {
				const nodes = valueProvider();
				const containerNode = new XmlNode(memberName);
				nodes.map((node) => {
					containerNode.c(node);
				});
				this.c(containerNode);
			}
		}
		toString() {
			const hasChildren = Boolean(this.children.length);
			let xmlText = `<${this.name}`;
			const attributes = this.attributes;
			for (const attributeName of Object.keys(attributes)) {
				const attribute = attributes[attributeName];
				if (attribute != null) xmlText += ` ${attributeName}="${escapeAttribute("" + attribute)}"`;
			}
			return xmlText += !hasChildren ? "/>" : `>${this.children.map((c) => c.toString()).join("")}</${this.name}>`;
		}
	};
}));
// node_modules/@aws-sdk/xml-builder/dist-es/xml-parser.js
function writeKey(obj) {
	Object.defineProperty(obj, "__proto__", {
		value: void 0,
		writable: true,
		enumerable: true,
		configurable: true
	});
}
function parseXML(xml) {
	return new AwsXmlParser(xml).parse();
}
var AwsXmlParser;
var init_xml_parser = __esmMin((() => {
	AwsXmlParser = class AwsXmlParser {
		x;
		i = 0;
		z;
		constructor(x) {
			this.x = x;
			this.x = x.replace(/\r\n?/g, "\n");
			this.z = this.x.length;
		}
		parse() {
			const p = this;
			const { z } = p;
			while (p.i < z) {
				p.trim();
				if (p.i >= z) break;
				if (p.isNext("<?")) {
					p.readTo("?>");
					p.trim();
				} else if (p.isNext("<!--")) {
					p.readTo("-->");
					p.trim();
				} else if (p.isNext("<!DOCTYPE", false)) {
					p.skipDoctype();
					p.trim();
				} else if (p.x[p.i] === "<") {
					const root = p.parseTag();
					return { [root.tag]: root.value };
				} else throw new Error("@aws-sdk XML parse error: unexpected content.");
			}
			throw new Error("@aws-sdk XML parse error: no root element.");
		}
		isNext(s, caseSensitive = true) {
			const p = this;
			if (caseSensitive) return p.x.startsWith(s, p.i);
			return p.x.toLowerCase().startsWith(s.toLowerCase(), p.i);
		}
		readTo(stop) {
			const p = this;
			const _i = p.x.indexOf(stop, p.i);
			if (_i === -1) throw new Error(`@aws-sdk XML parse error: expected "${stop}" not found.`);
			const result = p.x.slice(p.i, _i);
			p.i = _i + stop.length;
			return result;
		}
		trim() {
			const p = this;
			while (p.i < p.z && " 	\r\n".includes(p.x[p.i])) ++p.i;
		}
		readAttrValue() {
			const p = this;
			const quote = p.x[p.i];
			++p.i;
			let value = "";
			while (p.i < p.z && p.x[p.i] !== quote) value += p.x[p.i++];
			++p.i;
			return p.decodeEntities(value);
		}
		parseTag() {
			const p = this;
			++p.i;
			let tag = "";
			while (p.i < p.z && !" 	\r\n>/".includes(p.x[p.i])) tag += p.x[p.i++];
			let hasAttrs = false;
			const attrs = {};
			while (p.i < p.z) {
				p.trim();
				if (">/".includes(p.x[p.i])) break;
				let name = "";
				while (p.i < p.z && !"= 	\r\n>/?".includes(p.x[p.i])) name += p.x[p.i++];
				p.trim();
				if (p.x[p.i] !== "=") break;
				++p.i;
				p.trim();
				if (name === "__proto__") writeKey(attrs);
				attrs[name] = p.readAttrValue();
				hasAttrs = true;
			}
			if (p.i >= p.z) throw new Error("@aws-sdk XML parse error: unexpected end of input.");
			if (p.x[p.i] === "/") {
				++p.i;
				if (p.i >= p.z || p.x[p.i] !== ">") throw new Error("@aws-sdk XML parse error: expected > at the end of self-closing tag.");
				++p.i;
				return {
					tag,
					value: hasAttrs ? attrs : ""
				};
			}
			if (p.x[p.i] !== ">") throw new Error("@aws-sdk XML parse error: expected > at the end of opening tag.");
			++p.i;
			const textParts = [];
			const childTags = [];
			let hasElementChild = false;
			while (p.i < p.z) {
				if (p.isNext("</")) break;
				if (p.x[p.i] === "<") {
					if (p.isNext("<!--")) p.readTo("-->");
					else if (p.isNext("<![CDATA[")) {
						p.i += 9;
						textParts.push(p.readTo("]]>"));
					} else if (p.isNext("<?")) p.readTo("?>");
					else {
						hasElementChild = true;
						childTags.push(p.parseTag());
					}
				} else {
					let text = "";
					while (p.i < p.z && p.x[p.i] !== "<") text += p.x[p.i++];
					textParts.push(p.decodeEntities(text));
				}
			}
			if (!p.isNext("</")) throw new Error(`@aws-sdk XML parse error: missing closing tag </${tag}>.`);
			p.i += 2;
			const closeTag = p.readTo(">").trim();
			if (closeTag !== tag) throw new Error(`@aws-sdk XML parse error: mismatched tags <${tag}> and </${closeTag}>.`);
			if (!hasAttrs && textParts.length === 0 && !hasElementChild) return {
				tag,
				value: ""
			};
			if (!hasAttrs && !hasElementChild) {
				const text = textParts.length === 1 ? textParts[0] : textParts.join("");
				if (text.trim() === "" && text.includes("\n")) return {
					tag,
					value: ""
				};
				return {
					tag,
					value: text
				};
			}
			const obj = {};
			for (const text of textParts) {
				if (text.trim() === "" && text.includes("\n")) continue;
				obj["#text"] = "#text" in obj ? obj["#text"] + text : text;
			}
			for (const child of childTags) {
				if (child.tag === "__proto__") writeKey(obj);
				if (child.tag in obj) {
					if (Array.isArray(obj[child.tag])) obj[child.tag].push(child.value);
					else obj[child.tag] = [obj[child.tag], child.value];
				} else obj[child.tag] = child.value;
			}
			for (const [k, v] of Object.entries(attrs)) {
				if (k === "__proto__") writeKey(obj);
				obj[k] = v;
			}
			return {
				tag,
				value: obj
			};
		}
		static ENTITIES = {
			amp: "&",
			lt: "<",
			gt: ">",
			quot: "\"",
			apos: "'"
		};
		skipDoctype() {
			const p = this;
			p.i += 9;
			let depth = 0;
			while (p.i < p.z) {
				const c = p.x[p.i];
				if (c === "[") ++depth;
				else if (c === "]") --depth;
				else if (c === ">" && depth === 0) {
					++p.i;
					return;
				}
				++p.i;
			}
			throw new Error("@aws-sdk XML parse error: unclosed DOCTYPE.");
		}
		decodeEntities(s) {
			return s.replace(/&(?:#x([0-9a-fA-F]{1,6})|#(\d{1,7})|([a-zA-Z][a-zA-Z0-9]{0,30}));/g, (_, hex, dec, named) => {
				if (hex) return String.fromCharCode(parseInt(hex, 16));
				if (dec) return String.fromCharCode(parseInt(dec, 10));
				return AwsXmlParser.ENTITIES[named] ?? "";
			});
		}
	};
}));
// node_modules/@aws-sdk/xml-builder/dist-es/index.js
var dist_es_exports$2 = /* @__PURE__ */ __exportAll({
	XmlNode: () => XmlNode,
	XmlText: () => XmlText,
	parseXML: () => parseXML
});
var init_dist_es$1 = __esmMin((() => {
	init_XmlNode();
	init_XmlText();
	init_xml_parser();
}));
// node_modules/@aws-sdk/core/dist-cjs/submodules/protocols/index.js
var require_protocols = /* @__PURE__ */ __commonJSMin(((exports) => {
	var { SmithyRpcV2CborProtocol, loadSmithyRpcV2CborErrorCode } = require_cbor();
	var { TypeRegistry, NormalizedSchema, deref } = require_schema();
	var { decorateServiceException, getValueFromTextNode } = require_client();
	var { RpcProtocol, JsonCodec2, loadJsonRpcErrorCode, HttpBindingProtocol, HttpInterceptingShapeSerializer, HttpInterceptingShapeDeserializer, loadRestJsonErrorCode, FromStringShapeDeserializer, determineTimestampFormat, extendedEncodeURIComponent, collectBody } = require_protocols$1();
	var { JsonCodec, JsonShapeDeserializer, JsonShapeDeserializer2, JsonShapeSerializer, JsonShapeSerializer2, parseJsonBody, parseJsonErrorBody } = require_protocols$1();
	exports.JsonCodec = JsonCodec;
	exports.JsonCodec2 = JsonCodec2;
	exports.JsonShapeDeserializer = JsonShapeDeserializer;
	exports.JsonShapeDeserializer2 = JsonShapeDeserializer2;
	exports.JsonShapeSerializer = JsonShapeSerializer;
	exports.JsonShapeSerializer2 = JsonShapeSerializer2;
	exports.loadJsonRpcErrorCode = loadJsonRpcErrorCode;
	exports.loadRestJsonErrorCode = loadRestJsonErrorCode;
	exports.parseJsonBody = parseJsonBody;
	exports.parseJsonErrorBody = parseJsonErrorBody;
	var { parseXML, XmlNode, XmlText } = (init_dist_es$1(), __toCommonJS(dist_es_exports$2));
	var { toUtf8, toBase64, generateIdempotencyToken, NumericValue, dateToUtcString, fromBase64, expectUnion } = require_serde();
	var ProtocolLib = class {
		queryCompat;
		errorRegistry;
		constructor(queryCompat = false) {
			this.queryCompat = queryCompat;
		}
		resolveRestContentType(defaultContentType, inputSchema) {
			const members = inputSchema.getMemberSchemas();
			const httpPayloadMember = Object.values(members).find((m) => {
				return !!m.getMergedTraits().httpPayload;
			});
			if (httpPayloadMember) {
				const mediaType = httpPayloadMember.getMergedTraits().mediaType;
				if (mediaType) return mediaType;
				else if (httpPayloadMember.isStringSchema()) return "text/plain";
				else if (httpPayloadMember.isBlobSchema()) return "application/octet-stream";
				else return defaultContentType;
			} else if (!inputSchema.isUnitSchema()) {
				if (Object.values(members).find((m) => {
					const { httpQuery, httpQueryParams, httpHeader, httpLabel, httpPrefixHeaders } = m.getMergedTraits();
					return !httpQuery && !httpQueryParams && !httpHeader && !httpLabel && httpPrefixHeaders === void 0;
				})) return defaultContentType;
			}
		}
		async getErrorSchemaOrThrowBaseException(errorIdentifier, defaultNamespace, response, dataObject, metadata, getErrorSchema) {
			let errorName = errorIdentifier;
			if (errorIdentifier.includes("#")) [, errorName] = errorIdentifier.split("#");
			const errorMetadata = {
				$metadata: metadata,
				$fault: response.statusCode < 500 ? "client" : "server"
			};
			if (!this.errorRegistry) throw new Error("@aws-sdk/core/protocols - error handler not initialized.");
			try {
				return {
					errorSchema: getErrorSchema?.(this.errorRegistry, errorName) ?? this.errorRegistry.getSchema(errorIdentifier),
					errorMetadata
				};
			} catch (e) {
				dataObject.message = dataObject.message ?? dataObject.Message ?? "UnknownError";
				const synthetic = this.errorRegistry;
				const baseExceptionSchema = synthetic.getBaseException();
				if (baseExceptionSchema) {
					const ErrorCtor = synthetic.getErrorCtor(baseExceptionSchema) ?? Error;
					throw this.decorateServiceException(Object.assign(new ErrorCtor({ name: errorName }), errorMetadata), dataObject);
				}
				const d = dataObject;
				const message = d?.message ?? d?.Message ?? d?.Error?.Message ?? d?.Error?.message;
				throw this.decorateServiceException(Object.assign(new Error(message), { name: errorName }, errorMetadata), dataObject);
			}
		}
		compose(composite, errorIdentifier, defaultNamespace) {
			let namespace = defaultNamespace;
			if (errorIdentifier.includes("#")) [namespace] = errorIdentifier.split("#");
			const staticRegistry = TypeRegistry.for(namespace);
			const defaultSyntheticRegistry = TypeRegistry.for("smithy.ts.sdk.synthetic." + defaultNamespace);
			composite.copyFrom(staticRegistry);
			composite.copyFrom(defaultSyntheticRegistry);
			this.errorRegistry = composite;
		}
		decorateServiceException(exception, additions = {}) {
			if (this.queryCompat) {
				const msg = exception.Message ?? additions.Message;
				const error = decorateServiceException(exception, additions);
				if (msg) error.message = msg;
				const errorObj = error.Error ?? {};
				errorObj.Type = error.Error?.Type;
				errorObj.Code = error.Error?.Code;
				errorObj.Message = error.Error?.message ?? error.Error?.Message ?? msg;
				error.Error = errorObj;
				const reqId = error.$metadata.requestId;
				if (reqId) error.RequestId = reqId;
				return error;
			}
			return decorateServiceException(exception, additions);
		}
		setQueryCompatError(output, response) {
			const queryErrorHeader = response.headers?.["x-amzn-query-error"];
			if (output !== void 0 && queryErrorHeader != null) {
				const [Code, Type] = queryErrorHeader.split(";");
				const keys = Object.keys(output);
				const Error = {
					Code,
					Type
				};
				output.Code = Code;
				output.Type = Type;
				for (let i = 0; i < keys.length; i++) {
					const k = keys[i];
					Error[k === "message" ? "Message" : k] = output[k];
				}
				delete Error.__type;
				output.Error = Error;
			}
		}
		queryCompatOutput(queryCompatErrorData, errorData) {
			if (queryCompatErrorData.Error) errorData.Error = queryCompatErrorData.Error;
			if (queryCompatErrorData.Type) errorData.Type = queryCompatErrorData.Type;
			if (queryCompatErrorData.Code) errorData.Code = queryCompatErrorData.Code;
		}
		findQueryCompatibleError(registry, errorName) {
			try {
				return registry.getSchema(errorName);
			} catch (e) {
				return registry.find((schema) => NormalizedSchema.of(schema).getMergedTraits().awsQueryError?.[0] === errorName);
			}
		}
	};
	var AwsSmithyRpcV2CborProtocol = class extends SmithyRpcV2CborProtocol {
		awsQueryCompatible;
		mixin;
		constructor({ defaultNamespace, errorTypeRegistries, awsQueryCompatible }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
			this.awsQueryCompatible = !!awsQueryCompatible;
			this.mixin = new ProtocolLib(this.awsQueryCompatible);
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			if (this.awsQueryCompatible) request.headers["x-amzn-query-mode"] = "true";
			return request;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			if (this.awsQueryCompatible) this.mixin.setQueryCompatError(dataObject, response);
			const errorName = (() => {
				const compatHeader = response.headers["x-amzn-query-error"];
				if (compatHeader && this.awsQueryCompatible) return compatHeader.split(";")[0];
				return loadSmithyRpcV2CborErrorCode(response, dataObject) ?? "Unknown";
			})();
			this.mixin.compose(this.compositeErrorRegistry, errorName, this.options.defaultNamespace);
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorName, this.options.defaultNamespace, response, dataObject, metadata, this.awsQueryCompatible ? this.mixin.findQueryCompatibleError : void 0);
			const ns = NormalizedSchema.of(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)({});
			const output = {};
			for (const [name, member] of ns.structIterator()) if (dataObject[name] != null) output[name] = this.deserializer.readValue(member, dataObject[name]);
			if (this.awsQueryCompatible) this.mixin.queryCompatOutput(dataObject, output);
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
	};
	var AwsJsonRpcProtocol = class extends RpcProtocol {
		serializer;
		deserializer;
		serviceTarget;
		codec;
		mixin;
		awsQueryCompatible;
		constructor({ defaultNamespace, errorTypeRegistries, serviceTarget, awsQueryCompatible, jsonCodec }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
			this.serviceTarget = serviceTarget;
			this.codec = jsonCodec ?? new JsonCodec2({
				timestampFormat: {
					useTrait: true,
					default: 7
				},
				jsonName: false
			});
			this.serializer = this.codec.createSerializer();
			this.deserializer = this.codec.createDeserializer();
			this.awsQueryCompatible = !!awsQueryCompatible;
			this.mixin = new ProtocolLib(this.awsQueryCompatible);
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			if (!request.path.endsWith("/")) request.path += "/";
			request.headers["content-type"] = `application/x-amz-json-${this.getJsonRpcVersion()}`;
			request.headers["x-amz-target"] = `${this.serviceTarget}.${operationSchema.name}`;
			if (this.awsQueryCompatible) request.headers["x-amzn-query-mode"] = "true";
			if (deref(operationSchema.input) === "unit" || !request.body) request.body = "{}";
			return request;
		}
		getPayloadCodec() {
			return this.codec;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const { awsQueryCompatible } = this;
			if (awsQueryCompatible) this.mixin.setQueryCompatError(dataObject, response);
			const errorIdentifier = loadJsonRpcErrorCode(response, dataObject, awsQueryCompatible) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, dataObject, metadata, awsQueryCompatible ? this.mixin.findQueryCompatibleError : void 0);
			const ns = NormalizedSchema.of(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)({});
			const output = {};
			const errorDeserializer = this.codec.createDeserializer();
			for (const [name, member] of ns.structIterator()) if (dataObject[name] != null) output[name] = errorDeserializer.readObject(member, dataObject[name]);
			if (awsQueryCompatible) this.mixin.queryCompatOutput(dataObject, output);
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
	};
	var AwsJson1_0Protocol = class extends AwsJsonRpcProtocol {
		constructor({ defaultNamespace, errorTypeRegistries, serviceTarget, awsQueryCompatible, jsonCodec }) {
			super({
				defaultNamespace,
				errorTypeRegistries,
				serviceTarget,
				awsQueryCompatible,
				jsonCodec
			});
		}
		getShapeId() {
			return "aws.protocols#awsJson1_0";
		}
		getJsonRpcVersion() {
			return "1.0";
		}
		getDefaultContentType() {
			return "application/x-amz-json-1.0";
		}
	};
	var AwsJson1_1Protocol = class extends AwsJsonRpcProtocol {
		constructor({ defaultNamespace, errorTypeRegistries, serviceTarget, awsQueryCompatible, jsonCodec }) {
			super({
				defaultNamespace,
				errorTypeRegistries,
				serviceTarget,
				awsQueryCompatible,
				jsonCodec
			});
		}
		getShapeId() {
			return "aws.protocols#awsJson1_1";
		}
		getJsonRpcVersion() {
			return "1.1";
		}
		getDefaultContentType() {
			return "application/x-amz-json-1.1";
		}
	};
	var AwsRestJsonProtocol = class extends HttpBindingProtocol {
		serializer;
		deserializer;
		codec;
		mixin = new ProtocolLib();
		constructor({ defaultNamespace, errorTypeRegistries, jsonCodec }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
			const settings = {
				timestampFormat: {
					useTrait: true,
					default: 7
				},
				httpBindings: true,
				jsonName: true
			};
			this.codec = jsonCodec ?? new JsonCodec2(settings);
			this.serializer = new HttpInterceptingShapeSerializer(this.codec.createSerializer(), settings);
			this.deserializer = new HttpInterceptingShapeDeserializer(this.codec.createDeserializer(), settings);
		}
		getShapeId() {
			return "aws.protocols#restJson1";
		}
		getPayloadCodec() {
			return this.codec;
		}
		setSerdeContext(serdeContext) {
			this.codec.setSerdeContext(serdeContext);
			super.setSerdeContext(serdeContext);
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			const inputSchema = NormalizedSchema.of(operationSchema.input);
			if (!request.headers["content-type"]) {
				const contentType = this.mixin.resolveRestContentType(this.getDefaultContentType(), inputSchema);
				if (contentType) request.headers["content-type"] = contentType;
			}
			if (request.body == null && request.headers["content-type"] === this.getDefaultContentType()) request.body = "{}";
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			const output = await super.deserializeResponse(operationSchema, context, response);
			const outputSchema = NormalizedSchema.of(operationSchema.output);
			for (const [name, member] of outputSchema.structIterator()) if (member.getMemberTraits().httpPayload && !(name in output)) output[name] = null;
			return output;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorIdentifier = loadRestJsonErrorCode(response, dataObject) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, dataObject, metadata);
			const ns = NormalizedSchema.of(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)({});
			await this.deserializeHttpMessage(errorSchema, context, response, dataObject);
			const output = {};
			const errorDeserializer = this.codec.createDeserializer();
			for (const [name, member] of ns.structIterator()) {
				const target = member.getMergedTraits().jsonName ?? name;
				output[name] = errorDeserializer.readObject(member, dataObject[target]);
			}
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
		getDefaultContentType() {
			return "application/json";
		}
	};
	var SerdeContextConfig = class {
		serdeContext;
		setSerdeContext(serdeContext) {
			this.serdeContext = serdeContext;
		}
	};
	var UnionSerde = class {
		from;
		to;
		keys;
		constructor(from, to) {
			this.from = from;
			this.to = to;
			const keys = Object.keys(this.from);
			const set = new Set(keys);
			set.delete("__type");
			this.keys = set;
		}
		mark(key) {
			this.keys.delete(key);
		}
		hasUnknown() {
			return this.keys.size === 1 && Object.keys(this.to).length === 0;
		}
		writeUnknown() {
			if (this.hasUnknown()) {
				const k = this.keys.values().next().value;
				const v = this.from[k];
				this.to.$unknown = [k, v];
			}
		}
	};
	function writeKey(obj) {
		Object.defineProperty(obj, "__proto__", {
			value: void 0,
			writable: true,
			enumerable: true,
			configurable: true
		});
	}
	var XmlShapeDeserializer = class extends SerdeContextConfig {
		settings;
		stringDeserializer;
		constructor(settings) {
			super();
			this.settings = settings;
			this.stringDeserializer = new FromStringShapeDeserializer(settings);
		}
		setSerdeContext(serdeContext) {
			this.serdeContext = serdeContext;
			this.stringDeserializer.setSerdeContext(serdeContext);
		}
		read(schema, bytes, key) {
			const ns = NormalizedSchema.of(schema);
			const memberSchemas = ns.getMemberSchemas();
			if (ns.isStructSchema() && ns.isMemberSchema() && !!Object.values(memberSchemas).find((memberNs) => {
				return !!memberNs.getMemberTraits().eventPayload;
			})) {
				const output = {};
				const memberName = Object.keys(memberSchemas)[0];
				if (memberSchemas[memberName].isBlobSchema()) output[memberName] = bytes;
				else output[memberName] = this.read(memberSchemas[memberName], bytes);
				return output;
			}
			const xmlString = (this.serdeContext?.utf8Encoder ?? toUtf8)(bytes);
			const parsedObject = this.parseXml(xmlString);
			return this.readSchema(schema, key ? parsedObject[key] : parsedObject);
		}
		readSchema(_schema, value) {
			const ns = NormalizedSchema.of(_schema);
			if (ns.isUnitSchema()) return;
			const traits = ns.getMergedTraits();
			if (ns.isListSchema() && !Array.isArray(value)) return this.readSchema(ns, [value]);
			if (value == null) return value;
			if (typeof value === "object") {
				const flat = !!traits.xmlFlattened;
				if (ns.isListSchema()) {
					const listValue = ns.getValueSchema();
					const buffer = [];
					const sourceKey = listValue.getMergedTraits().xmlName ?? "member";
					const source = flat ? value : (value[0] ?? value)[sourceKey];
					if (source == null) return buffer;
					const sourceArray = Array.isArray(source) ? source : [source];
					for (const v of sourceArray) buffer.push(this.readSchema(listValue, v));
					return buffer;
				}
				const buffer = {};
				if (ns.isMapSchema()) {
					const keyNs = ns.getKeySchema();
					const memberNs = ns.getValueSchema();
					let entries;
					if (flat) entries = Array.isArray(value) ? value : [value];
					else entries = Array.isArray(value.entry) ? value.entry : [value.entry];
					const keyProperty = keyNs.getMergedTraits().xmlName ?? "key";
					const valueProperty = memberNs.getMergedTraits().xmlName ?? "value";
					for (const entry of entries) {
						const key = entry[keyProperty];
						const value = entry[valueProperty];
						if (key === "__proto__") writeKey(buffer);
						buffer[key] = this.readSchema(memberNs, value);
					}
					return buffer;
				}
				if (ns.isStructSchema()) {
					const union = ns.isUnionSchema();
					let unionSerde;
					if (union) unionSerde = new UnionSerde(value, buffer);
					for (const [memberName, memberSchema] of ns.structIterator()) {
						const memberTraits = memberSchema.getMergedTraits();
						const xmlObjectKey = !memberTraits.httpPayload ? memberSchema.getMemberTraits().xmlName ?? memberName : memberTraits.xmlName ?? memberSchema.getName();
						if (union) unionSerde.mark(xmlObjectKey);
						if (value[xmlObjectKey] != null) buffer[memberName] = this.readSchema(memberSchema, value[xmlObjectKey]);
					}
					if (union) unionSerde.writeUnknown();
					return buffer;
				}
				if (ns.isDocumentSchema()) return value;
				throw new Error(`@aws-sdk/core/protocols - xml deserializer unhandled schema type for ${ns.getName(true)}`);
			}
			if (ns.isListSchema()) return [];
			if (ns.isMapSchema() || ns.isStructSchema()) return {};
			return this.stringDeserializer.read(ns, value);
		}
		parseXml(xml) {
			if (xml.length) {
				let parsedObj;
				try {
					parsedObj = parseXML(xml);
				} catch (e) {
					if (e && typeof e === "object") Object.defineProperty(e, "$responseBodyText", { value: xml });
					throw e;
				}
				const textNodeName = "#text";
				const key = Object.keys(parsedObj)[0];
				const parsedObjToReturn = parsedObj[key];
				if (parsedObjToReturn[textNodeName]) {
					parsedObjToReturn[key] = parsedObjToReturn[textNodeName];
					delete parsedObjToReturn[textNodeName];
				}
				return getValueFromTextNode(parsedObjToReturn);
			}
			return {};
		}
	};
	var QueryShapeSerializer = class extends SerdeContextConfig {
		settings;
		buffer;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		write(schema, value, prefix = "") {
			if (this.buffer === void 0) this.buffer = "";
			const ns = NormalizedSchema.of(schema);
			if (prefix && !prefix.endsWith(".")) prefix += ".";
			if (ns.isBlobSchema()) {
				if (typeof value === "string" || value instanceof Uint8Array) {
					this.writeKey(prefix);
					this.writeValue((this.serdeContext?.base64Encoder ?? toBase64)(value));
				}
			} else if (ns.isBooleanSchema() || ns.isNumericSchema() || ns.isStringSchema()) {
				if (value != null) {
					this.writeKey(prefix);
					this.writeValue(String(value));
				} else if (ns.isIdempotencyToken()) {
					this.writeKey(prefix);
					this.writeValue(generateIdempotencyToken());
				}
			} else if (ns.isBigIntegerSchema()) {
				if (value != null) {
					this.writeKey(prefix);
					this.writeValue(String(value));
				}
			} else if (ns.isBigDecimalSchema()) {
				if (value != null) {
					this.writeKey(prefix);
					this.writeValue(value instanceof NumericValue ? value.string : String(value));
				}
			} else if (ns.isTimestampSchema()) {
				if (value instanceof Date) {
					this.writeKey(prefix);
					switch (determineTimestampFormat(ns, this.settings)) {
						case 5:
							this.writeValue(value.toISOString().replace(".000Z", "Z"));
							break;
						case 6:
							this.writeValue(dateToUtcString(value));
							break;
						case 7: this.writeValue(String(value.getTime() / 1e3));
					}
				}
			} else if (ns.isDocumentSchema()) {
				if (Array.isArray(value)) this.write(79, value, prefix);
				else if (value instanceof Date) this.write(4, value, prefix);
				else if (value instanceof Uint8Array) this.write(21, value, prefix);
				else if (value && typeof value === "object") this.write(143, value, prefix);
				else {
					this.writeKey(prefix);
					this.writeValue(String(value));
				}
			} else if (ns.isListSchema()) {
				if (Array.isArray(value)) {
					if (value.length === 0) {
						if (this.settings.serializeEmptyLists) {
							this.writeKey(prefix);
							this.writeValue("");
						}
					} else {
						const member = ns.getValueSchema();
						const flat = this.settings.flattenLists || ns.getMergedTraits().xmlFlattened;
						let i = 1;
						for (const item of value) {
							if (item == null) continue;
							const traits = member.getMergedTraits();
							const suffix = this.getKey("member", traits.xmlName, traits.ec2QueryName);
							const key = flat ? `${prefix}${i}` : `${prefix}${suffix}.${i}`;
							this.write(member, item, key);
							++i;
						}
					}
				}
			} else if (ns.isMapSchema()) {
				if (value && typeof value === "object") {
					const keySchema = ns.getKeySchema();
					const memberSchema = ns.getValueSchema();
					const flat = ns.getMergedTraits().xmlFlattened;
					let i = 1;
					for (const k in value) {
						const v = value[k];
						if (v == null) continue;
						const keyTraits = keySchema.getMergedTraits();
						const keySuffix = this.getKey("key", keyTraits.xmlName, keyTraits.ec2QueryName);
						const key = flat ? `${prefix}${i}.${keySuffix}` : `${prefix}entry.${i}.${keySuffix}`;
						const valTraits = memberSchema.getMergedTraits();
						const valueSuffix = this.getKey("value", valTraits.xmlName, valTraits.ec2QueryName);
						const valueKey = flat ? `${prefix}${i}.${valueSuffix}` : `${prefix}entry.${i}.${valueSuffix}`;
						this.write(keySchema, k, key);
						this.write(memberSchema, v, valueKey);
						++i;
					}
				}
			} else if (ns.isStructSchema()) {
				if (value && typeof value === "object") {
					let didWriteMember = false;
					for (const [memberName, member] of ns.structIterator()) {
						if (value[memberName] == null && !member.isIdempotencyToken()) continue;
						const traits = member.getMergedTraits();
						const suffix = this.getKey(memberName, traits.xmlName, traits.ec2QueryName, "struct");
						const key = `${prefix}${suffix}`;
						this.write(member, value[memberName], key);
						didWriteMember = true;
					}
					if (!didWriteMember && ns.isUnionSchema()) {
						const { $unknown } = value;
						if (Array.isArray($unknown)) {
							const [k, v] = $unknown;
							const key = `${prefix}${k}`;
							this.write(15, v, key);
						}
					}
				}
			} else if (ns.isUnitSchema());
			else throw new Error(`@aws-sdk/core/protocols - QuerySerializer unrecognized schema type ${ns.getName(true)}`);
		}
		flush() {
			if (this.buffer === void 0) throw new Error("@aws-sdk/core/protocols - QuerySerializer cannot flush with nothing written to buffer.");
			const str = this.buffer;
			delete this.buffer;
			return str;
		}
		getKey(memberName, xmlName, ec2QueryName, keySource) {
			const { ec2, capitalizeKeys } = this.settings;
			if (ec2 && ec2QueryName) return ec2QueryName;
			const key = xmlName ?? memberName;
			if (capitalizeKeys && keySource === "struct") return key[0].toUpperCase() + key.slice(1);
			return key;
		}
		writeKey(key) {
			if (key.endsWith(".")) key = key.slice(0, key.length - 1);
			this.buffer += `&${extendedEncodeURIComponent(key)}=`;
		}
		writeValue(value) {
			this.buffer += extendedEncodeURIComponent(value);
		}
	};
	var AwsQueryProtocol = class extends RpcProtocol {
		options;
		serializer;
		deserializer;
		mixin = new ProtocolLib();
		constructor(options) {
			super({
				defaultNamespace: options.defaultNamespace,
				errorTypeRegistries: options.errorTypeRegistries
			});
			this.options = options;
			const settings = {
				timestampFormat: {
					useTrait: true,
					default: 5
				},
				httpBindings: false,
				xmlNamespace: options.xmlNamespace,
				serviceNamespace: options.defaultNamespace,
				serializeEmptyLists: true
			};
			this.serializer = new QueryShapeSerializer(settings);
			this.deserializer = new XmlShapeDeserializer(settings);
		}
		getShapeId() {
			return "aws.protocols#awsQuery";
		}
		setSerdeContext(serdeContext) {
			this.serializer.setSerdeContext(serdeContext);
			this.deserializer.setSerdeContext(serdeContext);
		}
		getPayloadCodec() {
			throw new Error("AWSQuery protocol has no payload codec.");
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			if (!request.path.endsWith("/")) request.path += "/";
			request.headers["content-type"] = "application/x-www-form-urlencoded";
			if (deref(operationSchema.input) === "unit" || !request.body) request.body = "";
			request.body = `Action=${operationSchema.name.split("#")[1] ?? operationSchema.name}&Version=${this.options.version}` + request.body;
			if (request.body.endsWith("&")) request.body = request.body.slice(-1);
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			const deserializer = this.deserializer;
			const ns = NormalizedSchema.of(operationSchema.output);
			const dataObject = {};
			if (response.statusCode >= 300) {
				const bytes = await collectBody(response.body, context);
				if (bytes.byteLength > 0) Object.assign(dataObject, await deserializer.read(15, bytes));
				await this.handleError(operationSchema, context, response, dataObject, this.deserializeMetadata(response));
			}
			for (const header in response.headers) {
				const value = response.headers[header];
				delete response.headers[header];
				response.headers[header.toLowerCase()] = value;
			}
			const shortName = operationSchema.name.split("#")[1] ?? operationSchema.name;
			const awsQueryResultKey = ns.isStructSchema() && this.useNestedResult() ? shortName + "Result" : void 0;
			const bytes = await collectBody(response.body, context);
			if (bytes.byteLength > 0) Object.assign(dataObject, await deserializer.read(ns, bytes, awsQueryResultKey));
			dataObject.$metadata = this.deserializeMetadata(response);
			return dataObject;
		}
		useNestedResult() {
			return true;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorIdentifier = this.loadQueryErrorCode(response, dataObject) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			const errorData = this.loadQueryError(dataObject) ?? {};
			const message = this.loadQueryErrorMessage(dataObject);
			errorData.message = message;
			errorData.Error = {
				Type: errorData.Type,
				Code: errorData.Code,
				Message: message
			};
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, errorData, metadata, this.mixin.findQueryCompatibleError);
			const ns = NormalizedSchema.of(errorSchema);
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)({});
			const output = {
				Type: errorData.Error.Type,
				Code: errorData.Error.Code,
				Error: errorData.Error
			};
			for (const [name, member] of ns.structIterator()) {
				const target = member.getMergedTraits().xmlName ?? name;
				const value = errorData[target] ?? dataObject[target];
				output[name] = this.deserializer.readSchema(member, value);
			}
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
		loadQueryErrorCode(output, data) {
			const code = (data.Errors?.[0]?.Error ?? data.Errors?.Error ?? data.Error)?.Code;
			if (code !== void 0) return code;
			if (output.statusCode == 404) return "NotFound";
		}
		loadQueryError(data) {
			return data.Errors?.[0]?.Error ?? data.Errors?.Error ?? data.Error;
		}
		loadQueryErrorMessage(data) {
			const errorData = this.loadQueryError(data);
			return errorData?.message ?? errorData?.Message ?? data.message ?? data.Message ?? "Unknown";
		}
		getDefaultContentType() {
			return "application/x-www-form-urlencoded";
		}
	};
	var AwsEc2QueryProtocol = class extends AwsQueryProtocol {
		options;
		constructor(options) {
			super(options);
			this.options = options;
			Object.assign(this.serializer.settings, {
				capitalizeKeys: true,
				flattenLists: true,
				serializeEmptyLists: false,
				ec2: true
			});
		}
		getShapeId() {
			return "aws.protocols#ec2Query";
		}
		useNestedResult() {
			return false;
		}
	};
	var collectBodyString = (streamBody, context) => collectBody(streamBody, context).then((body) => (context?.utf8Encoder ?? toUtf8)(body));
	var parseXmlBody = (streamBody, context) => collectBodyString(streamBody, context).then((encoded) => {
		if (encoded.length) {
			let parsedObj;
			try {
				parsedObj = parseXML(encoded);
			} catch (e) {
				if (e && typeof e === "object") Object.defineProperty(e, "$responseBodyText", { value: encoded });
				throw e;
			}
			const textNodeName = "#text";
			const key = Object.keys(parsedObj)[0];
			const parsedObjToReturn = parsedObj[key];
			if (parsedObjToReturn[textNodeName]) {
				parsedObjToReturn[key] = parsedObjToReturn[textNodeName];
				delete parsedObjToReturn[textNodeName];
			}
			return getValueFromTextNode(parsedObjToReturn);
		}
		return {};
	});
	var parseXmlErrorBody = async (errorBody, context) => {
		const value = await parseXmlBody(errorBody, context);
		if (value.Error) value.Error.message = value.Error.message ?? value.Error.Message;
		return value;
	};
	var loadRestXmlErrorCode = (output, data) => {
		if (data?.Error?.Code !== void 0) return data.Error.Code;
		if (data?.Code !== void 0) return data.Code;
		if (output.statusCode == 404) return "NotFound";
	};
	var XmlShapeSerializer = class extends SerdeContextConfig {
		settings;
		stringBuffer;
		byteBuffer;
		buffer;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		write(schema, value) {
			const ns = NormalizedSchema.of(schema);
			if (ns.isStringSchema() && typeof value === "string") this.stringBuffer = value;
			else if (ns.isBlobSchema()) this.byteBuffer = "byteLength" in value ? value : (this.serdeContext?.base64Decoder ?? fromBase64)(value);
			else {
				this.buffer = this.writeStruct(ns, value, void 0);
				const traits = ns.getMergedTraits();
				if (traits.httpPayload && !traits.xmlName) this.buffer.withName(ns.getName());
			}
		}
		flush() {
			if (this.byteBuffer !== void 0) {
				const bytes = this.byteBuffer;
				delete this.byteBuffer;
				return bytes;
			}
			if (this.stringBuffer !== void 0) {
				const str = this.stringBuffer;
				delete this.stringBuffer;
				return str;
			}
			const buffer = this.buffer;
			if (this.settings.xmlNamespace) {
				if (!buffer?.attributes?.["xmlns"]) buffer.addAttribute("xmlns", this.settings.xmlNamespace);
			}
			delete this.buffer;
			return buffer.toString();
		}
		writeStruct(ns, value, parentXmlns) {
			const traits = ns.getMergedTraits();
			const name = ns.isMemberSchema() && !traits.httpPayload ? ns.getMemberTraits().xmlName ?? ns.getMemberName() : traits.xmlName ?? ns.getName();
			if (!name || !ns.isStructSchema()) throw new Error(`@aws-sdk/core/protocols - xml serializer, cannot write struct with empty name or non-struct, schema=${ns.getName(true)}.`);
			const structXmlNode = XmlNode.of(name);
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(ns, parentXmlns);
			for (const [memberName, memberSchema] of ns.structIterator()) {
				const val = value[memberName];
				if (val != null || memberSchema.isIdempotencyToken()) {
					if (memberSchema.getMergedTraits().xmlAttribute) {
						structXmlNode.addAttribute(memberSchema.getMergedTraits().xmlName ?? memberName, this.writeSimple(memberSchema, val));
						continue;
					}
					if (memberSchema.isListSchema()) this.writeList(memberSchema, val, structXmlNode, xmlns);
					else if (memberSchema.isMapSchema()) this.writeMap(memberSchema, val, structXmlNode, xmlns);
					else if (memberSchema.isStructSchema()) structXmlNode.addChildNode(this.writeStruct(memberSchema, val, xmlns));
					else {
						const memberNode = XmlNode.of(memberSchema.getMergedTraits().xmlName ?? memberSchema.getMemberName());
						this.writeSimpleInto(memberSchema, val, memberNode, xmlns);
						structXmlNode.addChildNode(memberNode);
					}
				}
			}
			const { $unknown } = value;
			if ($unknown && ns.isUnionSchema() && Array.isArray($unknown) && Object.keys(value).length === 1) {
				const [k, v] = $unknown;
				const node = XmlNode.of(k);
				if (typeof v !== "string") {
					if (value instanceof XmlNode || value instanceof XmlText) structXmlNode.addChildNode(value);
					else throw new Error("@aws-sdk - $unknown union member in XML requires value of type string, @aws-sdk/xml-builder::XmlNode or XmlText.");
				}
				this.writeSimpleInto(0, v, node, xmlns);
				structXmlNode.addChildNode(node);
			}
			if (xmlns) structXmlNode.addAttribute(xmlnsAttr, xmlns);
			return structXmlNode;
		}
		writeList(listMember, array, container, parentXmlns) {
			if (!listMember.isMemberSchema()) throw new Error(`@aws-sdk/core/protocols - xml serializer, cannot write non-member list: ${listMember.getName(true)}`);
			const listTraits = listMember.getMergedTraits();
			const listValueSchema = listMember.getValueSchema();
			const listValueTraits = listValueSchema.getMergedTraits();
			const sparse = !!listValueTraits.sparse;
			const flat = !!listTraits.xmlFlattened;
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(listMember, parentXmlns);
			const writeItem = (container, value) => {
				if (listValueSchema.isListSchema()) this.writeList(listValueSchema, Array.isArray(value) ? value : [value], container, xmlns);
				else if (listValueSchema.isMapSchema()) this.writeMap(listValueSchema, value, container, xmlns);
				else if (listValueSchema.isStructSchema()) {
					const struct = this.writeStruct(listValueSchema, value, xmlns);
					container.addChildNode(struct.withName(flat ? listTraits.xmlName ?? listMember.getMemberName() : listValueTraits.xmlName ?? "member"));
				} else {
					const listItemNode = XmlNode.of(flat ? listTraits.xmlName ?? listMember.getMemberName() : listValueTraits.xmlName ?? "member");
					this.writeSimpleInto(listValueSchema, value, listItemNode, xmlns);
					container.addChildNode(listItemNode);
				}
			};
			if (flat) {
				for (const value of array) if (sparse || value != null) writeItem(container, value);
			} else {
				const listNode = XmlNode.of(listTraits.xmlName ?? listMember.getMemberName());
				if (xmlns) listNode.addAttribute(xmlnsAttr, xmlns);
				for (const value of array) if (sparse || value != null) writeItem(listNode, value);
				container.addChildNode(listNode);
			}
		}
		writeMap(mapMember, map, container, parentXmlns, containerIsMap = false) {
			if (!mapMember.isMemberSchema()) throw new Error(`@aws-sdk/core/protocols - xml serializer, cannot write non-member map: ${mapMember.getName(true)}`);
			const mapTraits = mapMember.getMergedTraits();
			const mapKeySchema = mapMember.getKeySchema();
			const keyTag = mapKeySchema.getMergedTraits().xmlName ?? "key";
			const mapValueSchema = mapMember.getValueSchema();
			const mapValueTraits = mapValueSchema.getMergedTraits();
			const valueTag = mapValueTraits.xmlName ?? "value";
			const sparse = !!mapValueTraits.sparse;
			const flat = !!mapTraits.xmlFlattened;
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(mapMember, parentXmlns);
			const addKeyValue = (entry, key, val) => {
				const keyNode = XmlNode.of(keyTag, key);
				const [keyXmlnsAttr, keyXmlns] = this.getXmlnsAttribute(mapKeySchema, xmlns);
				if (keyXmlns) keyNode.addAttribute(keyXmlnsAttr, keyXmlns);
				entry.addChildNode(keyNode);
				let valueNode = XmlNode.of(valueTag);
				if (mapValueSchema.isListSchema()) this.writeList(mapValueSchema, val, valueNode, xmlns);
				else if (mapValueSchema.isMapSchema()) this.writeMap(mapValueSchema, val, valueNode, xmlns, true);
				else if (mapValueSchema.isStructSchema()) valueNode = this.writeStruct(mapValueSchema, val, xmlns);
				else this.writeSimpleInto(mapValueSchema, val, valueNode, xmlns);
				entry.addChildNode(valueNode);
			};
			if (flat) for (const key in map) {
				const val = map[key];
				if (sparse || val != null) {
					const entry = XmlNode.of(mapTraits.xmlName ?? mapMember.getMemberName());
					addKeyValue(entry, key, val);
					container.addChildNode(entry);
				}
			}
			else {
				let mapNode;
				if (!containerIsMap) {
					mapNode = XmlNode.of(mapTraits.xmlName ?? mapMember.getMemberName());
					if (xmlns) mapNode.addAttribute(xmlnsAttr, xmlns);
					container.addChildNode(mapNode);
				}
				for (const key in map) {
					const val = map[key];
					if (sparse || val != null) {
						const entry = XmlNode.of("entry");
						addKeyValue(entry, key, val);
						(containerIsMap ? container : mapNode).addChildNode(entry);
					}
				}
			}
		}
		writeSimple(_schema, value) {
			if (null === value) throw new Error("@aws-sdk/core/protocols - (XML serializer) cannot write null value.");
			const ns = NormalizedSchema.of(_schema);
			let nodeContents = null;
			if (value && typeof value === "object") {
				if (ns.isBlobSchema()) nodeContents = (this.serdeContext?.base64Encoder ?? toBase64)(value);
				else if (ns.isTimestampSchema() && value instanceof Date) switch (determineTimestampFormat(ns, this.settings)) {
					case 5:
						nodeContents = value.toISOString().replace(".000Z", "Z");
						break;
					case 6:
						nodeContents = dateToUtcString(value);
						break;
					case 7:
						nodeContents = String(value.getTime() / 1e3);
						break;
					default:
						console.warn("Missing timestamp format, using http date", value);
						nodeContents = dateToUtcString(value);
				}
				else if (ns.isBigDecimalSchema() && value) {
					if (value instanceof NumericValue) return value.string;
					return String(value);
				} else if (ns.isMapSchema() || ns.isListSchema()) throw new Error("@aws-sdk/core/protocols - xml serializer, cannot call _write() on List/Map schema, call writeList or writeMap() instead.");
				else throw new Error(`@aws-sdk/core/protocols - xml serializer, unhandled schema type for object value and schema: ${ns.getName(true)}`);
			}
			if (ns.isBooleanSchema() || ns.isNumericSchema() || ns.isBigIntegerSchema() || ns.isBigDecimalSchema()) nodeContents = String(value);
			if (ns.isStringSchema()) {
				if (value === void 0 && ns.isIdempotencyToken()) nodeContents = generateIdempotencyToken();
				else nodeContents = String(value);
			}
			if (nodeContents === null) throw new Error(`Unhandled schema-value pair ${ns.getName(true)}=${value}`);
			return nodeContents;
		}
		writeSimpleInto(_schema, value, into, parentXmlns) {
			const nodeContents = this.writeSimple(_schema, value);
			const ns = NormalizedSchema.of(_schema);
			const content = new XmlText(nodeContents);
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(ns, parentXmlns);
			if (xmlns) into.addAttribute(xmlnsAttr, xmlns);
			into.addChildNode(content);
		}
		getXmlnsAttribute(ns, parentXmlns) {
			const [prefix, xmlns] = ns.getMergedTraits().xmlNamespace ?? [];
			if (xmlns && xmlns !== parentXmlns) return [prefix ? `xmlns:${prefix}` : "xmlns", xmlns];
			return [void 0, void 0];
		}
	};
	var XmlCodec = class extends SerdeContextConfig {
		settings;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		createSerializer() {
			const serializer = new XmlShapeSerializer(this.settings);
			serializer.setSerdeContext(this.serdeContext);
			return serializer;
		}
		createDeserializer() {
			const deserializer = new XmlShapeDeserializer(this.settings);
			deserializer.setSerdeContext(this.serdeContext);
			return deserializer;
		}
	};
	var AwsRestXmlProtocol = class extends HttpBindingProtocol {
		codec;
		serializer;
		deserializer;
		mixin = new ProtocolLib();
		constructor(options) {
			super(options);
			const settings = {
				timestampFormat: {
					useTrait: true,
					default: 5
				},
				httpBindings: true,
				xmlNamespace: options.xmlNamespace,
				serviceNamespace: options.defaultNamespace
			};
			this.codec = new XmlCodec(settings);
			this.serializer = new HttpInterceptingShapeSerializer(this.codec.createSerializer(), settings);
			this.deserializer = new HttpInterceptingShapeDeserializer(this.codec.createDeserializer(), settings);
		}
		getPayloadCodec() {
			return this.codec;
		}
		getShapeId() {
			return "aws.protocols#restXml";
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			const inputSchema = NormalizedSchema.of(operationSchema.input);
			if (!request.headers["content-type"]) {
				const contentType = this.mixin.resolveRestContentType(this.getDefaultContentType(), inputSchema);
				if (contentType) request.headers["content-type"] = contentType;
			}
			if (typeof request.body === "string" && request.headers["content-type"] === this.getDefaultContentType() && !request.body.startsWith("<?xml ") && !this.hasUnstructuredPayloadBinding(inputSchema)) request.body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + request.body;
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			return super.deserializeResponse(operationSchema, context, response);
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorIdentifier = loadRestXmlErrorCode(response, dataObject) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			if (dataObject.Error && typeof dataObject.Error === "object") for (const key of Object.keys(dataObject.Error)) {
				dataObject[key] = dataObject.Error[key];
				if (key.toLowerCase() === "message") dataObject.message = dataObject.Error[key];
			}
			if (dataObject.RequestId && !metadata.requestId) metadata.requestId = dataObject.RequestId;
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, dataObject, metadata);
			const ns = NormalizedSchema.of(errorSchema);
			const message = dataObject.Error?.message ?? dataObject.Error?.Message ?? dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)({});
			await this.deserializeHttpMessage(errorSchema, context, response, dataObject);
			const output = {};
			const errorDeserializer = this.codec.createDeserializer();
			for (const [name, member] of ns.structIterator()) {
				const target = member.getMergedTraits().xmlName ?? name;
				const value = dataObject.Error?.[target] ?? dataObject[target];
				output[name] = errorDeserializer.readSchema(member, value);
			}
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
		getDefaultContentType() {
			return "application/xml";
		}
		hasUnstructuredPayloadBinding(ns) {
			for (const [, member] of ns.structIterator()) if (member.getMergedTraits().httpPayload) return !(member.isStructSchema() || member.isMapSchema() || member.isListSchema());
			return false;
		}
	};
	var awsExpectUnion = (value) => {
		if (value == null) return;
		if (typeof value === "object" && "__type" in value) delete value.__type;
		return expectUnion(value);
	};
	var _toStr = (val) => {
		if (val == null) return val;
		if (typeof val === "number" || typeof val === "bigint") {
			const warning = /* @__PURE__ */ new Error(`Received number ${val} where a string was expected.`);
			warning.name = "Warning";
			console.warn(warning);
			return String(val);
		}
		if (typeof val === "boolean") {
			const warning = /* @__PURE__ */ new Error(`Received boolean ${val} where a string was expected.`);
			warning.name = "Warning";
			console.warn(warning);
			return String(val);
		}
		return val;
	};
	var _toBool = (val) => {
		if (val == null) return val;
		if (typeof val === "string") {
			const lowercase = val.toLowerCase();
			if (val !== "" && lowercase !== "false" && lowercase !== "true") {
				const warning = /* @__PURE__ */ new Error(`Received string "${val}" where a boolean was expected.`);
				warning.name = "Warning";
				console.warn(warning);
			}
			return val !== "" && lowercase !== "false";
		}
		return val;
	};
	var _toNum = (val) => {
		if (val == null) return val;
		if (typeof val === "string") {
			const num = Number(val);
			if (num.toString() !== val) {
				const warning = /* @__PURE__ */ new Error(`Received string "${val}" where a number was expected.`);
				warning.name = "Warning";
				console.warn(warning);
				return val;
			}
			return num;
		}
		return val;
	};
	exports.AwsEc2QueryProtocol = AwsEc2QueryProtocol;
	exports.AwsJson1_0Protocol = AwsJson1_0Protocol;
	exports.AwsJson1_1Protocol = AwsJson1_1Protocol;
	exports.AwsJsonRpcProtocol = AwsJsonRpcProtocol;
	exports.AwsQueryProtocol = AwsQueryProtocol;
	exports.AwsRestJsonProtocol = AwsRestJsonProtocol;
	exports.AwsRestXmlProtocol = AwsRestXmlProtocol;
	exports.AwsSmithyRpcV2CborProtocol = AwsSmithyRpcV2CborProtocol;
	exports.QueryShapeSerializer = QueryShapeSerializer;
	exports.XmlCodec = XmlCodec;
	exports.XmlShapeDeserializer = XmlShapeDeserializer;
	exports.XmlShapeSerializer = XmlShapeSerializer;
	exports._toBool = _toBool;
	exports._toNum = _toNum;
	exports._toStr = _toStr;
	exports.awsExpectUnion = awsExpectUnion;
	exports.loadRestXmlErrorCode = loadRestXmlErrorCode;
	exports.parseXmlBody = parseXmlBody;
	exports.parseXmlErrorBody = parseXmlErrorBody;
}));
// node_modules/@aws-sdk/core/dist-cjs/submodules/httpAuthSchemes/index.js
var require_httpAuthSchemes = /* @__PURE__ */ __commonJSMin(((exports) => {
	var { ProviderError, booleanSelector, SelectorType, loadConfig } = require_config();
	var { setCredentialFeature } = require_client$1();
	var { normalizeProvider, memoizeIdentityProvider, isIdentityExpired, doesIdentityRequireRefresh } = require_dist_cjs();
	var { SignatureV4 } = (init_dist_es$2(), __toCommonJS(dist_es_exports$3));
	var { HttpResponse, HttpRequest } = require_protocols$1();
	var { SMITHY_CONTEXT_KEY } = (init_dist_es$3(), __toCommonJS(dist_es_exports$4));
	var getDateHeader = (response) => HttpResponse.isInstance(response) ? response.headers?.date ?? response.headers?.Date : void 0;
	var getAgeHeader = (response) => HttpResponse.isInstance(response) ? response.headers?.age ?? response.headers?.Age : void 0;
	var getSkewCorrectedDate = (systemClockOffset) => new Date(Date.now() + systemClockOffset);
	var getUpdatedSystemClockOffset = (clockTime, currentSystemClockOffset, timeRequestSent, ageHeader) => {
		if (ageHeader !== void 0) return currentSystemClockOffset;
		const serverTime = Date.parse(clockTime);
		const timeResponseReceived = Date.now();
		if (timeRequestSent !== void 0 && timeResponseReceived - timeRequestSent > 9e5) return currentSystemClockOffset;
		return timeRequestSent !== void 0 ? serverTime - (timeRequestSent + timeResponseReceived) / 2 : serverTime - timeResponseReceived;
	};
	var throwSigningPropertyError = (name, property) => {
		if (!property) throw new Error(`Property \`${name}\` is not resolved for AWS SDK SigV4Auth`);
		return property;
	};
	var hasEventStreamOutput = (signingProperties) => {
		return (signingProperties.context?.[SMITHY_CONTEXT_KEY]?.eventStream)?.output === true;
	};
	var validateSigningProperties = async (signingProperties) => {
		const context = throwSigningPropertyError("context", signingProperties.context);
		const config = throwSigningPropertyError("config", signingProperties.config);
		const authScheme = context.endpointV2?.properties?.authSchemes?.[0];
		return {
			config,
			signer: await throwSigningPropertyError("signer", config.signer)(authScheme),
			signingRegion: signingProperties?.signingRegion,
			signingRegionSet: signingProperties?.signingRegionSet,
			signingName: signingProperties?.signingName
		};
	};
	var AwsSdkSigV4Signer = class {
		async sign(httpRequest, identity, signingProperties) {
			if (!HttpRequest.isInstance(httpRequest)) throw new Error("The request is not an instance of `HttpRequest` and cannot be signed");
			const validatedProps = await validateSigningProperties(signingProperties);
			const { config, signer } = validatedProps;
			let { signingRegion, signingName } = validatedProps;
			const handlerExecutionContext = signingProperties.context;
			if (handlerExecutionContext?.authSchemes?.length ?? false) {
				const [first, second] = handlerExecutionContext.authSchemes;
				if (first?.name === "sigv4a" && second?.name === "sigv4") {
					signingRegion = second?.signingRegion ?? signingRegion;
					signingName = second?.signingName ?? signingName;
				}
			}
			const noSkewCorrection = await config.disableClockSkewCorrection?.() === true;
			signingProperties._disableClockSkewCorrection = noSkewCorrection;
			const skipSkewSampling = noSkewCorrection || hasEventStreamOutput(signingProperties);
			signingProperties._skipClockSkewSampling = skipSkewSampling;
			if (!skipSkewSampling) {
				signingProperties._preRequestSystemClockOffset = config.systemClockOffset;
				signingProperties._requestSentAt = Date.now();
			}
			return await signer.sign(httpRequest, {
				signingDate: noSkewCorrection ? /* @__PURE__ */ new Date() : getSkewCorrectedDate(config.systemClockOffset),
				signingRegion,
				signingService: signingName
			});
		}
		errorHandler(signingProperties) {
			return (error) => {
				const errorException = error;
				if (!signingProperties._skipClockSkewSampling && !signingProperties._disableClockSkewCorrection) {
					const serverTime = errorException.ServerTime ?? getDateHeader(errorException.$response);
					if (serverTime) {
						const config = throwSigningPropertyError("config", signingProperties.config);
						const preRequestOffset = signingProperties._preRequestSystemClockOffset;
						const timeRequestSent = signingProperties._requestSentAt;
						const ageHeader = getAgeHeader(errorException.$response);
						const newOffset = getUpdatedSystemClockOffset(serverTime, config.systemClockOffset, timeRequestSent, ageHeader);
						config.systemClockOffset = newOffset;
						if (Math.abs(newOffset) >= 24e4 && (newOffset !== preRequestOffset || preRequestOffset !== void 0 && preRequestOffset !== newOffset) && errorException.$metadata) errorException.$metadata.clockSkewCorrected = true;
					}
				}
				throw error;
			};
		}
		successHandler(httpResponse, signingProperties) {
			if (signingProperties._skipClockSkewSampling || signingProperties._disableClockSkewCorrection) return;
			const dateHeader = getDateHeader(httpResponse);
			if (dateHeader) {
				const config = throwSigningPropertyError("config", signingProperties.config);
				const timeRequestSent = signingProperties._requestSentAt;
				const ageHeader = getAgeHeader(httpResponse);
				config.systemClockOffset = getUpdatedSystemClockOffset(dateHeader, config.systemClockOffset, timeRequestSent, ageHeader);
			}
		}
	};
	var AWSSDKSigV4Signer = AwsSdkSigV4Signer;
	var AwsSdkSigV4ASigner = class extends AwsSdkSigV4Signer {
		async sign(httpRequest, identity, signingProperties) {
			if (!HttpRequest.isInstance(httpRequest)) throw new Error("The request is not an instance of `HttpRequest` and cannot be signed");
			const { config, signer, signingRegion, signingRegionSet, signingName } = await validateSigningProperties(signingProperties);
			const multiRegionOverride = (await config.sigv4aSigningRegionSet?.() ?? signingRegionSet ?? [signingRegion]).join(",");
			const noSkewCorrection = await config.disableClockSkewCorrection?.() === true;
			signingProperties._disableClockSkewCorrection = noSkewCorrection;
			if (!noSkewCorrection) {
				signingProperties._preRequestSystemClockOffset = config.systemClockOffset;
				signingProperties._requestSentAt = Date.now();
			}
			return await signer.sign(httpRequest, {
				signingDate: noSkewCorrection ? /* @__PURE__ */ new Date() : getSkewCorrectedDate(config.systemClockOffset),
				signingRegion: multiRegionOverride,
				signingService: signingName
			});
		}
	};
	var getArrayForCommaSeparatedString = (str) => typeof str === "string" && str.length > 0 ? str.split(",").map((item) => item.trim()) : [];
	var getBearerTokenEnvKey = (signingName) => `AWS_BEARER_TOKEN_${signingName.replace(/[\s-]/g, "_").toUpperCase()}`;
	var NODE_AUTH_SCHEME_PREFERENCE_ENV_KEY = "AWS_AUTH_SCHEME_PREFERENCE";
	var NODE_AUTH_SCHEME_PREFERENCE_CONFIG_KEY = "auth_scheme_preference";
	var NODE_AUTH_SCHEME_PREFERENCE_OPTIONS = {
		environmentVariableSelector: (env, options) => {
			if (options?.signingName) {
				if (getBearerTokenEnvKey(options.signingName) in env) return ["httpBearerAuth"];
			}
			if (!(NODE_AUTH_SCHEME_PREFERENCE_ENV_KEY in env)) return void 0;
			return getArrayForCommaSeparatedString(env[NODE_AUTH_SCHEME_PREFERENCE_ENV_KEY]);
		},
		configFileSelector: (profile) => {
			if (!(NODE_AUTH_SCHEME_PREFERENCE_CONFIG_KEY in profile)) return void 0;
			return getArrayForCommaSeparatedString(profile[NODE_AUTH_SCHEME_PREFERENCE_CONFIG_KEY]);
		},
		default: []
	};
	var resolveAwsSdkSigV4AConfig = (config) => {
		config.sigv4aSigningRegionSet = normalizeProvider(config.sigv4aSigningRegionSet);
		return config;
	};
	var NODE_SIGV4A_CONFIG_OPTIONS = {
		environmentVariableSelector(env) {
			if (env.AWS_SIGV4A_SIGNING_REGION_SET) return env.AWS_SIGV4A_SIGNING_REGION_SET.split(",").map((_) => _.trim());
			throw new ProviderError("AWS_SIGV4A_SIGNING_REGION_SET not set in env.", { tryNextLink: true });
		},
		configFileSelector(profile) {
			if (profile.sigv4a_signing_region_set) return (profile.sigv4a_signing_region_set ?? "").split(",").map((_) => _.trim());
			throw new ProviderError("sigv4a_signing_region_set not set in profile.", { tryNextLink: true });
		},
		default: void 0
	};
	var bindResolveAwsSdkSigV4Config = (defaultDisableClockSkewCorrection) => (config) => {
		let inputCredentials = config.credentials;
		let isUserSupplied = !!config.credentials;
		let resolvedCredentials = void 0;
		Object.defineProperty(config, "credentials", {
			set(credentials) {
				if (credentials && credentials !== inputCredentials && credentials !== resolvedCredentials) isUserSupplied = true;
				inputCredentials = credentials;
				const boundProvider = bindCallerConfig(config, normalizeCredentialProvider(config, {
					credentials: inputCredentials,
					credentialDefaultProvider: config.credentialDefaultProvider
				}));
				if (isUserSupplied && !boundProvider.attributed) {
					const isCredentialObject = typeof inputCredentials === "object" && inputCredentials !== null;
					resolvedCredentials = async (options) => {
						const attributedCreds = await boundProvider(options);
						if (isCredentialObject && (!attributedCreds.$source || Object.keys(attributedCreds.$source).length === 0)) return setCredentialFeature(attributedCreds, "CREDENTIALS_CODE", "e");
						return attributedCreds;
					};
					resolvedCredentials.memoized = boundProvider.memoized;
					resolvedCredentials.configBound = boundProvider.configBound;
					resolvedCredentials.attributed = true;
				} else resolvedCredentials = boundProvider;
			},
			get() {
				return resolvedCredentials;
			},
			enumerable: true,
			configurable: true
		});
		config.credentials = inputCredentials;
		const { signingEscapePath = true, systemClockOffset = config.systemClockOffset || 0, sha256 } = config;
		let signer;
		if (config.signer) signer = normalizeProvider(config.signer);
		else if (config.regionInfoProvider) signer = () => normalizeProvider(config.region)().then(async (region) => [await config.regionInfoProvider(region, {
			useFipsEndpoint: await config.useFipsEndpoint(),
			useDualstackEndpoint: await config.useDualstackEndpoint()
		}) || {}, region]).then(([regionInfo, region]) => {
			const { signingRegion, signingService } = regionInfo;
			config.signingRegion = config.signingRegion || signingRegion || region;
			config.signingName = config.signingName || signingService || config.serviceId;
			const params = {
				...config,
				credentials: config.credentials,
				region: config.signingRegion,
				service: config.signingName,
				sha256,
				uriEscapePath: signingEscapePath
			};
			return new (config.signerConstructor || SignatureV4)(params);
		});
		else signer = async (authScheme) => {
			authScheme = Object.assign({}, {
				name: "sigv4",
				signingName: config.signingName || config.defaultSigningName,
				signingRegion: await normalizeProvider(config.region)(),
				properties: {}
			}, authScheme);
			const signingRegion = authScheme.signingRegion;
			const signingService = authScheme.signingName;
			config.signingRegion = config.signingRegion || signingRegion;
			config.signingName = config.signingName || signingService || config.serviceId;
			const params = {
				...config,
				credentials: config.credentials,
				region: config.signingRegion,
				service: config.signingName,
				sha256,
				uriEscapePath: signingEscapePath
			};
			return new (config.signerConstructor || SignatureV4)(params);
		};
		return Object.assign(config, {
			systemClockOffset,
			signingEscapePath,
			signer,
			disableClockSkewCorrection: normalizeProvider(config.disableClockSkewCorrection ?? defaultDisableClockSkewCorrection)
		});
	};
	function normalizeCredentialProvider(config, { credentials, credentialDefaultProvider }) {
		let credentialsProvider;
		if (credentials) {
			if (!credentials?.memoized) credentialsProvider = memoizeIdentityProvider(credentials, isIdentityExpired, doesIdentityRequireRefresh);
			else credentialsProvider = credentials;
		} else if (credentialDefaultProvider) credentialsProvider = normalizeProvider(credentialDefaultProvider(Object.assign({}, config, { parentClientConfig: config })));
		else credentialsProvider = async () => {
			throw new Error("@aws-sdk/core::resolveAwsSdkSigV4Config - `credentials` not provided and no credentialDefaultProvider was configured.");
		};
		credentialsProvider.memoized = true;
		return credentialsProvider;
	}
	function bindCallerConfig(config, credentialsProvider) {
		if (credentialsProvider.configBound) return credentialsProvider;
		const fn = async (options) => credentialsProvider({
			...options,
			callerClientConfig: config
		});
		fn.memoized = credentialsProvider.memoized;
		fn.configBound = true;
		return fn;
	}
	var ENV_DISABLE_CLOCK_SKEW_CORRECTION = "AWS_DISABLE_CLOCK_SKEW_CORRECTION";
	var CONFIG_DISABLE_CLOCK_SKEW_CORRECTION = "disable_clock_skew_correction";
	var resolveAwsSdkSigV4Config = bindResolveAwsSdkSigV4Config(loadConfig({
		environmentVariableSelector: (env) => booleanSelector(env, ENV_DISABLE_CLOCK_SKEW_CORRECTION, SelectorType.ENV),
		configFileSelector: (profile) => booleanSelector(profile, CONFIG_DISABLE_CLOCK_SKEW_CORRECTION, SelectorType.CONFIG),
		default: false
	}));
	var resolveAWSSDKSigV4Config = resolveAwsSdkSigV4Config;
	exports.AWSSDKSigV4Signer = AWSSDKSigV4Signer;
	exports.AwsSdkSigV4ASigner = AwsSdkSigV4ASigner;
	exports.AwsSdkSigV4Signer = AwsSdkSigV4Signer;
	exports.NODE_AUTH_SCHEME_PREFERENCE_OPTIONS = NODE_AUTH_SCHEME_PREFERENCE_OPTIONS;
	exports.NODE_SIGV4A_CONFIG_OPTIONS = NODE_SIGV4A_CONFIG_OPTIONS;
	exports.getBearerTokenEnvKey = getBearerTokenEnvKey;
	exports.resolveAWSSDKSigV4Config = resolveAWSSDKSigV4Config;
	exports.resolveAwsSdkSigV4AConfig = resolveAwsSdkSigV4AConfig;
	exports.resolveAwsSdkSigV4Config = resolveAwsSdkSigV4Config;
	exports.validateSigningProperties = validateSigningProperties;
}));
// node_modules/@aws-sdk/credential-provider-env/dist-es/fromEnv.js
var import_client$1 = require_client$1();
var import_config = require_config();
var ENV_KEY = "AWS_ACCESS_KEY_ID";
var ENV_SECRET = "AWS_SECRET_ACCESS_KEY";
var ENV_SESSION = "AWS_SESSION_TOKEN";
var ENV_EXPIRATION = "AWS_CREDENTIAL_EXPIRATION";
var ENV_CREDENTIAL_SCOPE = "AWS_CREDENTIAL_SCOPE";
var ENV_ACCOUNT_ID = "AWS_ACCOUNT_ID";
var fromEnv = (init) => async () => {
	init?.logger?.debug("@aws-sdk/credential-provider-env - fromEnv");
	const accessKeyId = process.env[ENV_KEY];
	const secretAccessKey = process.env[ENV_SECRET];
	const sessionToken = process.env[ENV_SESSION];
	const expiry = process.env[ENV_EXPIRATION];
	const credentialScope = process.env[ENV_CREDENTIAL_SCOPE];
	const accountId = process.env[ENV_ACCOUNT_ID];
	if (accessKeyId && secretAccessKey) {
		const credentials = {
			accessKeyId,
			secretAccessKey,
			...sessionToken && { sessionToken },
			...expiry && { expiration: new Date(expiry) },
			...credentialScope && { credentialScope },
			...accountId && { accountId }
		};
		(0, import_client$1.setCredentialFeature)(credentials, "CREDENTIALS_ENV_VARS", "g");
		return credentials;
	}
	throw new import_config.CredentialsProviderError("Unable to find environment variable credentials.", { logger: init?.logger });
};
// node_modules/@aws-sdk/credential-provider-env/dist-es/index.js
var dist_es_exports$1 = /* @__PURE__ */ __exportAll({
	ENV_ACCOUNT_ID: () => ENV_ACCOUNT_ID,
	ENV_CREDENTIAL_SCOPE: () => ENV_CREDENTIAL_SCOPE,
	ENV_EXPIRATION: () => ENV_EXPIRATION,
	ENV_KEY: () => ENV_KEY,
	ENV_SECRET: () => ENV_SECRET,
	ENV_SESSION: () => ENV_SESSION,
	fromEnv: () => fromEnv
});
var remoteProvider = async (init) => {
	const { ENV_CMDS_FULL_URI, ENV_CMDS_RELATIVE_URI, fromContainerMetadata, fromInstanceMetadata } = await import("../@smithy/credential-provider-imds+[...].mjs").then((n) => n.t);
	if (process.env[ENV_CMDS_RELATIVE_URI] || process.env[ENV_CMDS_FULL_URI]) {
		init.logger?.debug("@aws-sdk/credential-provider-node - remoteProvider::fromHttp/fromContainerMetadata");
		const { fromHttp } = await import("./credential-provider-http+[...].mjs").then((n) => n.t);
		return (0, import_config.chain)(fromHttp(init), fromContainerMetadata(init));
	}
	if (process.env["AWS_EC2_METADATA_DISABLED"] && process.env["AWS_EC2_METADATA_DISABLED"] !== "false") return async () => {
		throw new import_config.CredentialsProviderError("EC2 Instance Metadata Service access disabled", { logger: init.logger });
	};
	init.logger?.debug("@aws-sdk/credential-provider-node - remoteProvider::fromInstanceMetadata");
	return fromInstanceMetadata(init);
};
// node_modules/@aws-sdk/credential-provider-node/dist-es/runtime/memoize-chain.js
function memoizeChain(providers, treatAsExpired) {
	const chain = internalCreateChain(providers);
	let activeLock;
	let passiveLock;
	let credentials;
	let forceRefreshLock;
	const provider = async (options) => {
		if (options?.forceRefresh) {
			if (!forceRefreshLock) forceRefreshLock = chain(options).then((c) => {
				credentials = c;
			}).finally(() => {
				forceRefreshLock = void 0;
			});
			await forceRefreshLock;
			return credentials;
		}
		if (credentials?.expiration) {
			if (credentials?.expiration?.getTime() < Date.now()) credentials = void 0;
		}
		if (activeLock) await activeLock;
		else if (!credentials || treatAsExpired?.(credentials)) {
			if (credentials) {
				if (!passiveLock) passiveLock = chain(options).then((c) => {
					credentials = c;
				}).catch(() => {}).finally(() => {
					passiveLock = void 0;
				});
			} else {
				activeLock = chain(options).then((c) => {
					credentials = c;
				}).finally(() => {
					activeLock = void 0;
				});
				return provider(options);
			}
		}
		return credentials;
	};
	return provider;
}
var internalCreateChain = (providers) => async (awsIdentityProperties) => {
	let lastProviderError;
	for (const provider of providers) try {
		return await provider(awsIdentityProperties);
	} catch (err) {
		lastProviderError = err;
		if (err?.tryNextLink) continue;
		throw err;
	}
	throw lastProviderError;
};
// node_modules/@aws-sdk/credential-provider-node/dist-es/defaultProvider.js
var multipleCredentialSourceWarningEmitted = false;
var defaultProvider = (init = {}) => memoizeChain([
	async () => {
		if (init.profile ?? process.env[import_config.ENV_PROFILE]) {
			if (process.env["AWS_ACCESS_KEY_ID"] && process.env["AWS_SECRET_ACCESS_KEY"]) {
				if (!multipleCredentialSourceWarningEmitted) {
					(init.logger?.warn && init.logger?.constructor?.name !== "NoOpLogger" ? init.logger.warn.bind(init.logger) : console.warn)(`@aws-sdk/credential-provider-node - defaultProvider::fromEnv WARNING:
    Multiple credential sources detected: 
    Both AWS_PROFILE and the pair AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY static credentials are set.
    This SDK will proceed with the AWS_PROFILE value.
    
    However, a future version may change this behavior to prefer the ENV static credentials.
    Please ensure that your environment only sets either the AWS_PROFILE or the
    AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY pair.
`);
					multipleCredentialSourceWarningEmitted = true;
				}
			}
			throw new import_config.CredentialsProviderError("AWS_PROFILE is set, skipping fromEnv provider.", {
				logger: init.logger,
				tryNextLink: true
			});
		}
		init.logger?.debug("@aws-sdk/credential-provider-node - defaultProvider::fromEnv");
		return fromEnv(init)();
	},
	async (awsIdentityProperties) => {
		init.logger?.debug("@aws-sdk/credential-provider-node - defaultProvider::fromSSO");
		const { ssoStartUrl, ssoAccountId, ssoRegion, ssoRoleName, ssoSession } = init;
		if (!ssoStartUrl && !ssoAccountId && !ssoRegion && !ssoRoleName && !ssoSession) throw new import_config.CredentialsProviderError("Skipping SSO provider in default chain (inputs do not include SSO fields).", { logger: init.logger });
		const { fromSSO } = await import("./credential-provider-sso+[...].mjs").then((n) => n.t);
		return fromSSO(init)(awsIdentityProperties);
	},
	async (awsIdentityProperties) => {
		init.logger?.debug("@aws-sdk/credential-provider-node - defaultProvider::fromIni");
		const { fromIni } = await import("./credential-provider-ini+[...].mjs").then((n) => n.t);
		return fromIni(init)(awsIdentityProperties);
	},
	async (awsIdentityProperties) => {
		init.logger?.debug("@aws-sdk/credential-provider-node - defaultProvider::fromProcess");
		const { fromProcess } = await import("./credential-provider-process+[...].mjs").then((n) => n.t);
		return fromProcess(init)(awsIdentityProperties);
	},
	async (awsIdentityProperties) => {
		init.logger?.debug("@aws-sdk/credential-provider-node - defaultProvider::fromTokenFile");
		const { fromTokenFile } = await import("./credential-provider-web-identity+[...].mjs").then((n) => n.t);
		return fromTokenFile(init)(awsIdentityProperties);
	},
	async () => {
		init.logger?.debug("@aws-sdk/credential-provider-node - defaultProvider::remoteProvider");
		return (await remoteProvider(init))();
	},
	async () => {
		throw new import_config.CredentialsProviderError("Could not load credentials from any providers", {
			tryNextLink: false,
			logger: init.logger
		});
	}
], credentialsTreatedAsExpired);
var credentialsTreatedAsExpired = (credentials) => credentials?.expiration !== void 0 && credentials.expiration.getTime() - Date.now() < 3e5;
// node_modules/@smithy/node-http-handler/dist-es/build-abort-error.js
function buildAbortError(abortSignal) {
	const reason = abortSignal && typeof abortSignal === "object" && "reason" in abortSignal ? abortSignal.reason : void 0;
	if (reason) {
		if (reason instanceof Error) {
			const abortError = /* @__PURE__ */ new Error("Request aborted");
			abortError.name = "AbortError";
			abortError.cause = reason;
			return abortError;
		}
		const abortError = new Error(String(reason));
		abortError.name = "AbortError";
		return abortError;
	}
	const abortError = /* @__PURE__ */ new Error("Request aborted");
	abortError.name = "AbortError";
	return abortError;
}
var init_build_abort_error = __esmMin((() => {}));
// node_modules/@smithy/node-http-handler/dist-es/constants.js
var NODEJS_TIMEOUT_ERROR_CODES;
var init_constants = __esmMin((() => {
	NODEJS_TIMEOUT_ERROR_CODES = [
		"ECONNRESET",
		"EPIPE",
		"ETIMEDOUT"
	];
}));
// node_modules/@smithy/node-http-handler/dist-es/get-transformed-headers.js
var import_serde$3, getTransformedHeaders;
var init_get_transformed_headers = __esmMin((() => {
	import_serde$3 = require_serde();
	getTransformedHeaders = (headers) => {
		const transformedHeaders = {};
		for (const name in headers) {
			if (!(0, import_serde$3.hasOwn)(headers, name)) continue;
			const headerValues = headers[name];
			transformedHeaders[name] = Array.isArray(headerValues) ? headerValues.join(",") : headerValues;
		}
		return transformedHeaders;
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/node-https.js
var init_node_https = __esmMin((() => {}));
// node_modules/@smithy/node-http-handler/dist-es/timing.js
var timing;
var init_timing = __esmMin((() => {
	timing = {
		setTimeout: (cb, ms) => setTimeout(cb, ms),
		clearTimeout: (timeoutId) => clearTimeout(timeoutId)
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/set-connection-timeout.js
var DEFER_EVENT_LISTENER_TIME$2, setConnectionTimeout;
var init_set_connection_timeout = __esmMin((() => {
	init_timing();
	DEFER_EVENT_LISTENER_TIME$2 = 1e3;
	setConnectionTimeout = (request, reject, timeoutInMs = 0) => {
		if (!timeoutInMs) return -1;
		const registerTimeout = (offset) => {
			const timeoutId = timing.setTimeout(() => {
				request.destroy();
				reject(Object.assign(/* @__PURE__ */ new Error(`@smithy/node-http-handler - the request socket did not establish a connection with the server within the configured timeout of ${timeoutInMs} ms.`), { name: "TimeoutError" }));
			}, timeoutInMs - offset);
			const doWithSocket = (socket) => {
				if (socket?.connecting) socket.on("connect", () => {
					timing.clearTimeout(timeoutId);
				});
				else timing.clearTimeout(timeoutId);
			};
			if (request.socket) doWithSocket(request.socket);
			else request.on("socket", doWithSocket);
		};
		if (timeoutInMs < 2e3) {
			registerTimeout(0);
			return 0;
		}
		return timing.setTimeout(registerTimeout.bind(null, DEFER_EVENT_LISTENER_TIME$2), DEFER_EVENT_LISTENER_TIME$2);
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/set-request-timeout.js
var setRequestTimeout;
var init_set_request_timeout = __esmMin((() => {
	init_timing();
	setRequestTimeout = (req, reject, timeoutInMs = 0, throwOnRequestTimeout, logger) => {
		if (timeoutInMs) return timing.setTimeout(() => {
			let msg = `@smithy/node-http-handler - [${throwOnRequestTimeout ? "ERROR" : "WARN"}] a request has exceeded the configured ${timeoutInMs} ms requestTimeout.`;
			if (throwOnRequestTimeout) {
				const error = Object.assign(new Error(msg), {
					name: "TimeoutError",
					code: "ETIMEDOUT"
				});
				req.destroy(error);
				reject(error);
			} else {
				msg += ` Init client requestHandler with throwOnRequestTimeout=true to turn this into an error.`;
				logger?.warn?.(msg);
			}
		}, timeoutInMs);
		return -1;
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/set-socket-keep-alive.js
var DEFER_EVENT_LISTENER_TIME$1, setSocketKeepAlive;
var init_set_socket_keep_alive = __esmMin((() => {
	init_timing();
	DEFER_EVENT_LISTENER_TIME$1 = 3e3;
	setSocketKeepAlive = (request, { keepAlive, keepAliveMsecs }, deferTimeMs = DEFER_EVENT_LISTENER_TIME$1) => {
		if (keepAlive !== true) return -1;
		const registerListener = () => {
			if (request.socket) request.socket.setKeepAlive(keepAlive, keepAliveMsecs || 0);
			else request.on("socket", (socket) => {
				socket.setKeepAlive(keepAlive, keepAliveMsecs || 0);
			});
		};
		if (deferTimeMs === 0) {
			registerListener();
			return 0;
		}
		return timing.setTimeout(registerListener, deferTimeMs);
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/set-socket-timeout.js
var DEFER_EVENT_LISTENER_TIME, setSocketTimeout;
var init_set_socket_timeout = __esmMin((() => {
	init_timing();
	DEFER_EVENT_LISTENER_TIME = 3e3;
	setSocketTimeout = (request, reject, timeoutInMs = 0) => {
		const registerTimeout = (offset) => {
			const timeout = timeoutInMs - offset;
			const onTimeout = () => {
				request.destroy();
				reject(Object.assign(/* @__PURE__ */ new Error(`@smithy/node-http-handler - the request socket timed out after ${timeoutInMs} ms of inactivity (configured by client requestHandler).`), { name: "TimeoutError" }));
			};
			if (request.socket) {
				request.socket.setTimeout(timeout, onTimeout);
				request.on("close", () => request.socket?.removeListener("timeout", onTimeout));
			} else request.setTimeout(timeout, onTimeout);
		};
		if (0 < timeoutInMs && timeoutInMs < 6e3) {
			registerTimeout(0);
			return 0;
		}
		return timing.setTimeout(registerTimeout.bind(null, timeoutInMs === 0 ? 0 : DEFER_EVENT_LISTENER_TIME), DEFER_EVENT_LISTENER_TIME);
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/write-request-body.js
async function writeRequestBody(httpRequest, request, maxContinueTimeoutMs = MIN_WAIT_TIME, externalAgent = false) {
	const headers = request.headers;
	const expect = headers ? headers.Expect || headers.expect : void 0;
	let timeoutId = -1;
	let sendBody = true;
	if (!externalAgent && expect === "100-continue") sendBody = await Promise.race([new Promise((resolve) => {
		timeoutId = Number(timing.setTimeout(() => resolve(true), Math.max(MIN_WAIT_TIME, maxContinueTimeoutMs)));
	}), new Promise((resolve) => {
		httpRequest.on("continue", () => {
			timing.clearTimeout(timeoutId);
			resolve(true);
		});
		httpRequest.on("response", () => {
			timing.clearTimeout(timeoutId);
			resolve(false);
		});
		httpRequest.on("error", () => {
			timing.clearTimeout(timeoutId);
			resolve(false);
		});
	})]);
	if (sendBody) writeBody(httpRequest, request.body);
}
function writeBody(httpRequest, body) {
	if (body instanceof Readable) {
		body.pipe(httpRequest);
		return;
	}
	if (body) {
		const isBuffer = Buffer.isBuffer(body);
		if (isBuffer || typeof body === "string") {
			if (isBuffer && body.byteLength === 0) httpRequest.end();
			else httpRequest.end(body);
			return;
		}
		const uint8 = body;
		if (typeof uint8 === "object" && uint8.buffer && typeof uint8.byteOffset === "number" && typeof uint8.byteLength === "number") {
			httpRequest.end(Buffer.from(uint8.buffer, uint8.byteOffset, uint8.byteLength));
			return;
		}
		httpRequest.end(Buffer.from(body));
		return;
	}
	httpRequest.end();
}
var MIN_WAIT_TIME;
var init_write_request_body = __esmMin((() => {
	init_timing();
	MIN_WAIT_TIME = 6e3;
}));
// node_modules/@smithy/node-http-handler/dist-es/node-http-handler.js
var import_serde$2, import_protocols$3, hAgent, hRequest, NodeHttpHandler;
var init_node_http_handler = __esmMin((() => {
	import_serde$2 = require_serde();
	import_protocols$3 = require_protocols$1();
	init_build_abort_error();
	init_constants();
	init_get_transformed_headers();
	init_node_https();
	init_set_connection_timeout();
	init_set_request_timeout();
	init_set_socket_keep_alive();
	init_set_socket_timeout();
	init_timing();
	init_write_request_body();
	hAgent = void 0;
	hRequest = void 0;
	NodeHttpHandler = class NodeHttpHandler {
		config;
		configProvider;
		socketWarningTimestamp = 0;
		externalAgent = false;
		metadata = { handlerProtocol: "http/1.1" };
		static create(instanceOrOptions) {
			if (typeof instanceOrOptions?.handle === "function") return instanceOrOptions;
			return new NodeHttpHandler(instanceOrOptions);
		}
		static checkSocketUsage(agent, socketWarningTimestamp, logger = console) {
			const { sockets, requests, maxSockets } = agent;
			if (typeof maxSockets !== "number" || maxSockets === Infinity) return socketWarningTimestamp;
			if (Date.now() - 15e3 < socketWarningTimestamp) return socketWarningTimestamp;
			if (sockets && requests) for (const origin in sockets) {
				if (!(0, import_serde$2.hasOwn)(sockets, origin)) continue;
				const socketsInUse = sockets[origin]?.length ?? 0;
				const requestsEnqueued = requests[origin]?.length ?? 0;
				if (socketsInUse >= maxSockets && requestsEnqueued >= 2 * maxSockets) {
					logger?.warn?.(`@smithy/node-http-handler:WARN - socket usage at capacity=${socketsInUse} and ${requestsEnqueued} additional requests are enqueued.
See https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/node-configuring-maxsockets.html
or increase socketAcquisitionWarningTimeout=(millis) in the NodeHttpHandler config.`);
					return Date.now();
				}
			}
			return socketWarningTimestamp;
		}
		constructor(options) {
			this.configProvider = new Promise((resolve, reject) => {
				if (typeof options === "function") options().then((_options) => {
					resolve(this.resolveDefaultConfig(_options));
				}).catch(reject);
				else resolve(this.resolveDefaultConfig(options));
			});
		}
		destroy() {
			this.config?.httpAgent?.destroy();
			this.config?.httpsAgent?.destroy();
		}
		async handle(request, { abortSignal, requestTimeout } = {}) {
			if (!this.config) this.config = await this.configProvider;
			const config = this.config;
			const logger = config.logger;
			const isSSL = request.protocol === "https:";
			if (!isSSL && !this.config.httpAgent) this.config.httpAgent = await this.config.httpAgentProvider();
			return new Promise((_resolve, _reject) => {
				let writeRequestBodyPromise = void 0;
				let socketWarningTimeoutId = -1;
				let connectionTimeoutId = -1;
				let requestTimeoutId = -1;
				let socketTimeoutId = -1;
				let keepAliveTimeoutId = -1;
				const clearTimeouts = () => {
					timing.clearTimeout(socketWarningTimeoutId);
					timing.clearTimeout(connectionTimeoutId);
					timing.clearTimeout(requestTimeoutId);
					timing.clearTimeout(socketTimeoutId);
					timing.clearTimeout(keepAliveTimeoutId);
				};
				const resolve = async (arg) => {
					await writeRequestBodyPromise;
					clearTimeouts();
					_resolve(arg);
				};
				const reject = async (arg) => {
					await writeRequestBodyPromise;
					clearTimeouts();
					_reject(arg);
				};
				if (abortSignal?.aborted) {
					reject(buildAbortError(abortSignal));
					return;
				}
				const headers = request.headers;
				const expectContinue = headers ? (headers.Expect ?? headers.expect) === "100-continue" : false;
				let agent = isSSL ? config.httpsAgent : config.httpAgent;
				if (expectContinue && !this.externalAgent) agent = new (isSSL ? node_https.Agent : hAgent)({
					keepAlive: false,
					maxSockets: Infinity
				});
				socketWarningTimeoutId = timing.setTimeout(() => {
					this.socketWarningTimestamp = NodeHttpHandler.checkSocketUsage(agent, this.socketWarningTimestamp, logger);
				}, config.socketAcquisitionWarningTimeout ?? (config.requestTimeout ?? 2e3) + (config.connectionTimeout ?? 1e3));
				const queryString = request.query ? (0, import_protocols$3.buildQueryString)(request.query) : "";
				let auth = void 0;
				if (request.username != null || request.password != null) auth = `${request.username ?? ""}:${request.password ?? ""}`;
				let path = request.path;
				if (queryString) path += `?${queryString}`;
				if (request.fragment) path += `#${request.fragment}`;
				let hostname = request.hostname ?? "";
				if (hostname[0] === "[" && hostname.endsWith("]")) hostname = request.hostname.slice(1, -1);
				else hostname = request.hostname;
				const nodeHttpsOptions = {
					headers: request.headers,
					host: hostname,
					method: request.method,
					path,
					port: request.port,
					agent,
					auth
				};
				const req = (isSSL ? node_https.request : hRequest)(nodeHttpsOptions, (res) => {
					const httpResponse = new import_protocols$3.HttpResponse({
						statusCode: res.statusCode || -1,
						reason: res.statusMessage,
						headers: getTransformedHeaders(res.headers),
						body: res
					});
					resolve({ response: httpResponse });
				});
				req.on("error", (err) => {
					if (NODEJS_TIMEOUT_ERROR_CODES.includes(err.code)) reject(Object.assign(err, { name: "TimeoutError" }));
					else reject(err);
				});
				if (abortSignal) {
					const onAbort = () => {
						req.destroy();
						const abortError = buildAbortError(abortSignal);
						reject(abortError);
					};
					if (typeof abortSignal.addEventListener === "function") {
						const signal = abortSignal;
						signal.addEventListener("abort", onAbort, { once: true });
						req.once("close", () => signal.removeEventListener("abort", onAbort));
					} else abortSignal.onabort = onAbort;
				}
				const effectiveRequestTimeout = requestTimeout ?? config.requestTimeout;
				connectionTimeoutId = setConnectionTimeout(req, reject, config.connectionTimeout);
				requestTimeoutId = setRequestTimeout(req, reject, effectiveRequestTimeout, config.throwOnRequestTimeout, logger ?? console);
				socketTimeoutId = setSocketTimeout(req, reject, config.socketTimeout);
				const httpAgent = nodeHttpsOptions.agent;
				if (typeof httpAgent === "object" && "keepAlive" in httpAgent) keepAliveTimeoutId = setSocketKeepAlive(req, {
					keepAlive: httpAgent.keepAlive,
					keepAliveMsecs: httpAgent.keepAliveMsecs
				});
				writeRequestBodyPromise = writeRequestBody(req, request, effectiveRequestTimeout, this.externalAgent).catch((e) => {
					clearTimeouts();
					return _reject(e);
				});
			});
		}
		updateHttpClientConfig(key, value) {
			this.config = void 0;
			this.configProvider = this.configProvider.then((config) => {
				if (key === Symbol.for("logger")) return {
					...config,
					logger: config.logger ?? value
				};
				return {
					...config,
					[key]: value
				};
			});
		}
		httpHandlerConfigs() {
			return this.config ?? {};
		}
		resolveDefaultConfig(options) {
			const { requestTimeout, connectionTimeout, socketTimeout, socketAcquisitionWarningTimeout, httpAgent, httpsAgent, throwOnRequestTimeout, logger } = options || {};
			const keepAlive = true;
			const maxSockets = 50;
			return {
				connectionTimeout,
				requestTimeout,
				socketTimeout,
				socketAcquisitionWarningTimeout,
				throwOnRequestTimeout,
				httpAgentProvider: async () => {
					const node_http = await import("node:http");
					const { Agent, request } = node_http.default ?? node_http;
					hRequest = request;
					hAgent = Agent;
					if (httpAgent instanceof hAgent || typeof httpAgent?.destroy === "function") {
						this.externalAgent = true;
						return httpAgent;
					}
					return new hAgent({
						keepAlive,
						maxSockets,
						...httpAgent
					});
				},
				httpsAgent: (() => {
					if (httpsAgent instanceof node_https.Agent || typeof httpsAgent?.destroy === "function") {
						this.externalAgent = true;
						return httpsAgent;
					}
					return new node_https.Agent({
						keepAlive,
						maxSockets,
						...httpsAgent
					});
				})(),
				logger
			};
		}
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/node-http2.js
var init_node_http2 = __esmMin((() => {}));
// node_modules/@smithy/node-http-handler/dist-es/http2/ClientHttp2SessionRef.js
var ids, ClientHttp2SessionRef;
var init_ClientHttp2SessionRef = __esmMin((() => {
	ids = /* @__PURE__ */ new Uint16Array(1);
	ClientHttp2SessionRef = class {
		id = ids[0]++;
		total = 0;
		max = 0;
		session;
		refs = 0;
		constructor(session) {
			session.unref();
			this.session = session;
		}
		retain() {
			if (this.session.destroyed) throw new Error("@smithy/node-http-handler - cannot acquire reference to destroyed session.");
			this.refs += 1;
			this.total += 1;
			this.max = Math.max(this.refs, this.max);
			this.session.ref();
		}
		free() {
			if (this.session.destroyed) return;
			this.refs -= 1;
			if (this.refs === 0) this.session.unref();
			if (this.refs < 0) throw new Error("@smithy/node-http-handler - ClientHttp2Session refcount at zero, cannot decrement.");
		}
		deref() {
			return this.session;
		}
		close() {
			if (!this.session.closed) this.session.close();
		}
		destroy() {
			this.refs = 0;
			if (!this.session.destroyed) {
				this.session.setTimeout(0);
				this.session.destroy();
			}
		}
		useCount() {
			return this.refs;
		}
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/node-http2-connection-pool.js
var NodeHttp2ConnectionPool;
var init_node_http2_connection_pool = __esmMin((() => {
	init_ClientHttp2SessionRef();
	NodeHttp2ConnectionPool = class {
		sessions = [];
		maxConcurrency = 0;
		constructor(sessions) {
			this.sessions = (sessions ?? []).map((session) => new ClientHttp2SessionRef(session));
		}
		poll() {
			let cleanup = false;
			for (const session of this.sessions) {
				if (session.deref().destroyed) {
					cleanup = true;
					continue;
				}
				if (!this.maxConcurrency || session.useCount() < this.maxConcurrency) return session;
			}
			if (cleanup) {
				for (const session of this.sessions) if (session.deref().destroyed) this.remove(session);
			}
		}
		offerLast(ref) {
			this.sessions.push(ref);
		}
		remove(ref) {
			const ix = this.sessions.indexOf(ref);
			if (ix > -1) this.sessions.splice(ix, 1);
		}
		[Symbol.iterator]() {
			return this.sessions[Symbol.iterator]();
		}
		setMaxConcurrency(maxConcurrency) {
			this.maxConcurrency = maxConcurrency;
		}
		destroy(ref) {
			this.remove(ref);
			ref.destroy();
		}
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/node-http2-connection-manager.js
var NodeHttp2ConnectionManager;
var init_node_http2_connection_manager = __esmMin((() => {
	init_ClientHttp2SessionRef();
	init_node_http2_connection_pool();
	NodeHttp2ConnectionManager = class {
		config;
		connectOptions;
		connectionPools = /* @__PURE__ */ new Map();
		constructor(config) {
			this.config = config;
			if (this.config.maxConcurrency && this.config.maxConcurrency <= 0) throw new RangeError("maxConcurrency must be greater than zero.");
		}
		lease(requestContext, connectionConfiguration) {
			const url = this.getUrlString(requestContext);
			const pool = this.getPool(url);
			if (!this.config.disableConcurrency && !connectionConfiguration.isEventStream) {
				const available = pool.poll();
				if (available) {
					available.retain();
					return available;
				}
			}
			const ref = new ClientHttp2SessionRef(this.connect(url));
			const session = ref.deref();
			if (this.config.maxConcurrency) session.settings({ maxConcurrentStreams: this.config.maxConcurrency }, (err) => {
				if (err) throw new Error("Fail to set maxConcurrentStreams to " + this.config.maxConcurrency + "when creating new session for " + requestContext.destination.toString());
			});
			const graceful = () => {
				this.removeFromPoolAndClose(url, ref);
			};
			const ensureDestroyed = () => {
				this.removeFromPoolAndCheckedDestroy(url, ref);
			};
			session.on("goaway", graceful);
			session.on("error", ensureDestroyed);
			session.on("frameError", ensureDestroyed);
			session.on("close", ensureDestroyed);
			if (connectionConfiguration.requestTimeout) session.setTimeout(connectionConfiguration.requestTimeout, ensureDestroyed);
			pool.offerLast(ref);
			ref.retain();
			return ref;
		}
		release(_requestContext, ref) {
			ref.free();
		}
		createIsolatedSession(requestContext, connectionConfiguration) {
			const url = this.getUrlString(requestContext);
			const ref = new ClientHttp2SessionRef(this.connect(url));
			const session = ref.deref();
			session.settings({ maxConcurrentStreams: 1 });
			const ensureDestroyed = () => {
				ref.destroy();
			};
			session.on("error", ensureDestroyed);
			session.on("frameError", ensureDestroyed);
			session.on("close", ensureDestroyed);
			const timeout = connectionConfiguration.requestTimeout ?? 3e5;
			session.setTimeout(timeout, ensureDestroyed);
			ref.retain();
			return ref;
		}
		destroy() {
			for (const [url, connectionPool] of this.connectionPools) {
				for (const session of [...connectionPool]) session.destroy();
				this.connectionPools.delete(url);
			}
		}
		setMaxConcurrentStreams(maxConcurrentStreams) {
			if (maxConcurrentStreams && maxConcurrentStreams <= 0) throw new RangeError("maxConcurrentStreams must be greater than zero.");
			this.config.maxConcurrency = maxConcurrentStreams;
			for (const pool of this.connectionPools.values()) pool.setMaxConcurrency(maxConcurrentStreams);
		}
		setDisableConcurrentStreams(disableConcurrentStreams) {
			this.config.disableConcurrency = disableConcurrentStreams;
		}
		setNodeHttp2ConnectOptions(nodeHttp2ConnectOptions) {
			this.connectOptions = nodeHttp2ConnectOptions;
		}
		debug() {
			const pools = {};
			for (const [url, pool] of this.connectionPools) {
				const sessions = [];
				for (const ref of pool) sessions.push({
					id: ref.id,
					active: ref.useCount(),
					maxConcurrent: ref.max,
					totalRequests: ref.total
				});
				pools[url] = { sessions };
			}
			return pools;
		}
		removeFromPoolAndClose(authority, ref) {
			this.connectionPools.get(authority)?.remove(ref);
			ref.close();
		}
		removeFromPoolAndCheckedDestroy(authority, ref) {
			this.connectionPools.get(authority)?.remove(ref);
			ref.destroy();
		}
		getPool(url) {
			if (!this.connectionPools.has(url)) {
				const pool = new NodeHttp2ConnectionPool();
				if (this.config.maxConcurrency) pool.setMaxConcurrency(this.config.maxConcurrency);
				this.connectionPools.set(url, pool);
			}
			return this.connectionPools.get(url);
		}
		getUrlString(request) {
			return request.destination.toString();
		}
		connect(url) {
			return this.connectOptions === void 0 ? nodeHTTP2.connect(url) : nodeHTTP2.connect(url, this.connectOptions);
		}
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/node-http2-handler.js
var import_protocols$2, constants, NodeHttp2Handler;
var init_node_http2_handler = __esmMin((() => {
	import_protocols$2 = require_protocols$1();
	init_build_abort_error();
	init_get_transformed_headers();
	init_node_http2();
	init_node_http2_connection_manager();
	init_write_request_body();
	({constants} = node_http2);
	NodeHttp2Handler = class NodeHttp2Handler {
		config;
		configProvider;
		metadata = { handlerProtocol: "h2" };
		connectionManager = new NodeHttp2ConnectionManager({});
		static create(instanceOrOptions) {
			if (typeof instanceOrOptions?.handle === "function") return instanceOrOptions;
			return new NodeHttp2Handler(instanceOrOptions);
		}
		constructor(options) {
			this.configProvider = new Promise((resolve, reject) => {
				if (typeof options === "function") options().then((opts) => {
					resolve(opts || {});
				}).catch(reject);
				else resolve(options || {});
			});
		}
		destroy() {
			this.connectionManager.destroy();
		}
		async handle(request, { abortSignal, requestTimeout, isEventStream } = {}) {
			if (!this.config) {
				this.config = await this.configProvider;
				const { disableConcurrentStreams, maxConcurrentStreams, nodeHttp2ConnectOptions } = this.config;
				this.connectionManager.setDisableConcurrentStreams(disableConcurrentStreams ?? false);
				if (maxConcurrentStreams) this.connectionManager.setMaxConcurrentStreams(maxConcurrentStreams);
				if (nodeHttp2ConnectOptions) this.connectionManager.setNodeHttp2ConnectOptions(nodeHttp2ConnectOptions);
			}
			const { requestTimeout: configRequestTimeout, disableConcurrentStreams } = this.config;
			const useIsolatedSession = disableConcurrentStreams || isEventStream;
			const effectiveRequestTimeout = requestTimeout ?? configRequestTimeout;
			return new Promise((_resolve, _reject) => {
				let fulfilled = false;
				let writeRequestBodyPromise = void 0;
				const resolve = async (arg) => {
					await writeRequestBodyPromise;
					_resolve(arg);
				};
				const reject = async (arg) => {
					await writeRequestBodyPromise;
					_reject(arg);
				};
				if (abortSignal?.aborted) {
					fulfilled = true;
					reject(buildAbortError(abortSignal));
					return;
				}
				const { hostname, method, port, protocol, query } = request;
				let auth = "";
				if (request.username != null || request.password != null) auth = `${request.username ?? ""}:${request.password ?? ""}@`;
				const authority = `${protocol}//${auth}${hostname}${port ? `:${port}` : ""}`;
				const requestContext = { destination: new URL(authority) };
				const connectConfig = {
					requestTimeout: this.config?.sessionTimeout,
					isEventStream
				};
				const ref = useIsolatedSession ? this.connectionManager.createIsolatedSession(requestContext, connectConfig) : this.connectionManager.lease(requestContext, connectConfig);
				const session = ref.deref();
				const rejectWithDestroy = (err) => {
					if (useIsolatedSession) ref.destroy();
					fulfilled = true;
					reject(err);
				};
				const queryString = query ? (0, import_protocols$2.buildQueryString)(query) : "";
				let path = request.path;
				if (queryString) path += `?${queryString}`;
				if (request.fragment) path += `#${request.fragment}`;
				const clientHttp2Stream = session.request({
					...request.headers,
					[constants.HTTP2_HEADER_PATH]: path,
					[constants.HTTP2_HEADER_METHOD]: method
				});
				if (effectiveRequestTimeout) clientHttp2Stream.setTimeout(effectiveRequestTimeout, () => {
					clientHttp2Stream.close();
					const timeoutError = /* @__PURE__ */ new Error(`Stream timed out because of no activity for ${effectiveRequestTimeout} ms`);
					timeoutError.name = "TimeoutError";
					rejectWithDestroy(timeoutError);
				});
				if (abortSignal) {
					const onAbort = () => {
						clientHttp2Stream.close();
						const abortError = buildAbortError(abortSignal);
						rejectWithDestroy(abortError);
					};
					if (typeof abortSignal.addEventListener === "function") {
						const signal = abortSignal;
						signal.addEventListener("abort", onAbort, { once: true });
						clientHttp2Stream.once("close", () => signal.removeEventListener("abort", onAbort));
					} else abortSignal.onabort = onAbort;
				}
				clientHttp2Stream.on("frameError", (type, code, id) => {
					rejectWithDestroy(/* @__PURE__ */ new Error(`Frame type id ${type} in stream id ${id} has failed with code ${code}.`));
				});
				clientHttp2Stream.on("error", rejectWithDestroy);
				clientHttp2Stream.on("aborted", () => {
					rejectWithDestroy(/* @__PURE__ */ new Error(`HTTP/2 stream is abnormally aborted in mid-communication with result code ${clientHttp2Stream.rstCode}.`));
				});
				clientHttp2Stream.on("response", (headers) => {
					const httpResponse = new import_protocols$2.HttpResponse({
						statusCode: headers[":status"] ?? -1,
						headers: getTransformedHeaders(headers),
						body: clientHttp2Stream
					});
					fulfilled = true;
					resolve({ response: httpResponse });
					if (useIsolatedSession) {
						session.close();
						clientHttp2Stream.on("end", () => {
							ref.destroy();
						});
					}
				});
				clientHttp2Stream.on("close", () => {
					if (useIsolatedSession) ref.destroy();
					else this.connectionManager.release(requestContext, ref);
					if (!fulfilled) {
						const error = /* @__PURE__ */ new Error("Unexpected error: http2 request did not get a response");
						if (session.destroyed) error.name = "TimeoutError";
						rejectWithDestroy(error);
					}
				});
				writeRequestBodyPromise = writeRequestBody(clientHttp2Stream, request, effectiveRequestTimeout);
			});
		}
		updateHttpClientConfig(key, value) {
			this.config = void 0;
			this.configProvider = this.configProvider.then((config) => {
				return {
					...config,
					[key]: value
				};
			});
		}
		httpHandlerConfigs() {
			return this.config ?? {};
		}
	};
}));
// node_modules/@smithy/node-http-handler/dist-es/index.js
var dist_es_exports = /* @__PURE__ */ __exportAll({
	DEFAULT_REQUEST_TIMEOUT: () => 0,
	NodeHttp2Handler: () => NodeHttp2Handler,
	NodeHttpHandler: () => NodeHttpHandler,
	streamCollector: () => import_serde$1.streamCollector
});
var import_serde$1;
var init_dist_es = __esmMin((() => {
	init_node_http_handler();
	init_node_http2_handler();
	import_serde$1 = require_serde();
}));
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/auth/httpAuthSchemeProvider.js
var import_schema = require_schema();
var import_endpoints = require_endpoints();
var import_retry = require_retry();
var import_dist_cjs = require_dist_cjs();
var import_httpAuthSchemes = require_httpAuthSchemes();
var import_client = require_client();
var defaultCognitoIdentityProviderHttpAuthSchemeParametersProvider = async (config, context, input) => {
	return {
		operation: (0, import_client.getSmithyContext)(context).operation,
		region: await (0, import_client.normalizeProvider)(config.region)() || (() => {
			throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
		})()
	};
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
	return {
		schemeId: "aws.auth#sigv4",
		signingProperties: {
			name: "cognito-idp",
			region: authParameters.region
		},
		propertiesExtractor: (config, context) => ({ signingProperties: {
			config,
			context
		} })
	};
}
function createSmithyApiNoAuthHttpAuthOption(authParameters) {
	return { schemeId: "smithy.api#noAuth" };
}
var defaultCognitoIdentityProviderHttpAuthSchemeProvider = (authParameters) => {
	const options = [];
	switch (authParameters.operation) {
		case "AssociateSoftwareToken":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ChangePassword":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "CompleteWebAuthnRegistration":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ConfirmDevice":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ConfirmForgotPassword":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ConfirmSignUp":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "DeleteUser":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "DeleteUserAttributes":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "DeleteWebAuthnCredential":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ForgetDevice":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ForgotPassword":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "GetDevice":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "GetTokensFromRefreshToken":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "GetUser":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "GetUserAttributeVerificationCode":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "GetUserAuthFactors":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "GlobalSignOut":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "InitiateAuth":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ListDevices":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ListWebAuthnCredentials":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "ResendConfirmationCode":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "RespondToAuthChallenge":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "RevokeToken":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "SetUserMFAPreference":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "SetUserSettings":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "SignUp":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "StartWebAuthnRegistration":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "UpdateAuthEventFeedback":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "UpdateDeviceStatus":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "UpdateUserAttributes":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "VerifySoftwareToken":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		case "VerifyUserAttribute":
			options.push(createSmithyApiNoAuthHttpAuthOption(authParameters));
			break;
		default: options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
	}
	return options;
};
var resolveHttpAuthSchemeConfig = (config) => {
	const config_0 = (0, import_httpAuthSchemes.resolveAwsSdkSigV4Config)(config);
	return Object.assign(config_0, { authSchemePreference: (0, import_client.normalizeProvider)(config.authSchemePreference ?? []) });
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/endpoint/EndpointParameters.js
var resolveClientEndpointParameters = (options) => {
	return Object.assign(options, {
		useDualstackEndpoint: options.useDualstackEndpoint ?? false,
		useFipsEndpoint: options.useFipsEndpoint ?? false,
		defaultSigningName: "cognito-idp"
	});
};
var commonParams = {
	UseFIPS: {
		type: "builtInParams",
		name: "useFipsEndpoint"
	},
	Endpoint: {
		type: "builtInParams",
		name: "endpoint"
	},
	Region: {
		type: "builtInParams",
		name: "region"
	},
	UseDualStack: {
		type: "builtInParams",
		name: "useDualstackEndpoint"
	}
};
var package_default = {
	name: "@aws-sdk/client-cognito-identity-provider",
	version: "3.1156.0",
	description: "AWS SDK for JavaScript Cognito Identity Provider Client for Node.js, Browser and React Native",
	homepage: "https://github.com/aws/aws-sdk-js-v3/tree/main/clients/client-cognito-identity-provider",
	license: "Apache-2.0",
	author: {
		"name": "AWS SDK for JavaScript Team",
		"url": "https://aws.amazon.com/sdk-for-javascript/"
	},
	repository: {
		"type": "git",
		"url": "https://github.com/aws/aws-sdk-js-v3.git",
		"directory": "clients/client-cognito-identity-provider"
	},
	files: ["dist-*/**"],
	sideEffects: false,
	main: "./dist-cjs/index.js",
	module: "./dist-es/index.js",
	browser: { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.browser" },
	types: "./dist-types/index.d.ts",
	typesVersions: { "<4.5": { "dist-types/*": ["dist-types/ts3.4/*"] } },
	"react-native": { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.native" },
	scripts: {
		"build": "concurrently 'yarn:build:types' 'yarn:build:es' && yarn build:cjs",
		"build:cjs": "node ../../scripts/compilation/inline",
		"build:es": "premove dist-es && tsc -p tsconfig.es.json",
		"build:include:deps": "yarn g:turbo run build -F=\"$npm_package_name\"",
		"build:types": "premove dist-types && tsc -p tsconfig.types.json",
		"build:types:downlevel": "downlevel-dts dist-types dist-types/ts3.4",
		"clean": "premove dist-cjs dist-es dist-types",
		"extract:docs": "api-extractor run --local",
		"generate:client": "node ../../scripts/generate-clients/single-service",
		"test:index": "tsc -p tsconfig.test.json && node ./test/index-objects.spec.mjs"
	},
	dependencies: {
		"@aws-sdk/core": "^3.978.5",
		"@aws-sdk/credential-provider-node": "^3.972.88",
		"@aws-sdk/types": "^3.975.0",
		"@smithy/core": "^3.36.1",
		"@smithy/fetch-http-handler": "^5.8.0",
		"@smithy/node-http-handler": "^4.12.1",
		"@smithy/types": "^4.19.0",
		"tslib": "^2.6.2"
	},
	devDependencies: {
		"@tsconfig/node20": "20.1.8",
		"@types/node": "^20.14.8",
		"concurrently": "7.0.0",
		"downlevel-dts": "0.10.1",
		"premove": "4.0.0",
		"typescript": "~7.0.2"
	},
	engines: { "node": ">=20.0.0" }
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/endpoint/bdd.js
var import_checksum = require_checksum();
var import_protocols = require_protocols();
init_dist_es();
var m = "ref";
var a = -1;
var b = true;
var c = "isSet";
var d = "PartitionResult";
var e = "booleanEquals";
var f = "getAttr";
var g = "stringEquals";
var h = { [m]: "Endpoint" };
var i = { [m]: d };
var j = { [m]: "Region" };
var k = {};
var l = [j];
var _data = {
	conditions: [
		[c, [h]],
		[c, l],
		[
			"aws.partition",
			l,
			d
		],
		[e, [{ [m]: "UseFIPS" }, b]],
		[e, [{
			fn: f,
			argv: [i, "supportsFIPS"]
		}, b]],
		[e, [{ [m]: "UseDualStack" }, b]],
		[e, [{
			fn: f,
			argv: [i, "supportsDualStack"]
		}, b]],
		[g, [{
			fn: f,
			argv: [i, "name"]
		}, "aws"]],
		[g, [j, "us-east-1"]],
		[g, [j, "us-east-2"]],
		[g, [j, "us-west-1"]],
		[g, [j, "us-west-2"]]
	],
	results: [
		[a],
		[a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
		[a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
		[h, k],
		["https://cognito-idp-fips.us-east-1.amazonaws.com", k],
		["https://cognito-idp-fips.us-east-2.amazonaws.com", k],
		["https://cognito-idp-fips.us-west-1.amazonaws.com", k],
		["https://cognito-idp-fips.us-west-2.amazonaws.com", k],
		["https://cognito-idp-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", k],
		[a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
		["https://cognito-idp-fips.{Region}.{PartitionResult#dnsSuffix}", k],
		[a, "FIPS is enabled but this partition does not support FIPS"],
		["https://cognito-idp.{Region}.amazonaws.com", k],
		["https://cognito-idp.{Region}.{PartitionResult#dualStackDnsSuffix}", k],
		[a, "DualStack is enabled but this partition does not support DualStack"],
		["https://cognito-idp.{Region}.{PartitionResult#dnsSuffix}", k],
		[a, "Invalid Configuration: Missing Region"]
	]
};
var root = 2;
var nodes = new Int32Array([
	-1,
	1,
	-1,
	0,
	17,
	3,
	1,
	4,
	100000016,
	2,
	5,
	100000016,
	3,
	9,
	6,
	5,
	7,
	100000015,
	6,
	8,
	100000014,
	7,
	100000012,
	100000013,
	4,
	11,
	10,
	5,
	100000009,
	100000011,
	5,
	12,
	100000010,
	6,
	13,
	100000009,
	8,
	100000004,
	14,
	9,
	100000005,
	15,
	10,
	100000006,
	16,
	11,
	100000007,
	100000008,
	3,
	100000001,
	18,
	5,
	100000002,
	100000003
]);
var bdd = import_endpoints.BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/endpoint/endpointResolver.js
var cache = new import_endpoints.EndpointCache({
	size: 50,
	params: [
		"Endpoint",
		"Region",
		"UseDualStack",
		"UseFIPS"
	]
});
var defaultEndpointResolver = (endpointParams, context = {}) => {
	return cache.get(endpointParams, () => (0, import_endpoints.decideEndpoint)(bdd, {
		endpointParams,
		logger: context.logger
	}));
};
import_endpoints.customEndpointFunctions.aws = import_client$1.awsEndpointFunctions;
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/models/CognitoIdentityProviderServiceException.js
var CognitoIdentityProviderServiceException = class CognitoIdentityProviderServiceException extends import_client.ServiceException {
	static shapeId = "smithy.ts.sdk.synthetic.com.amazonaws.cognitoidentityprovider#CognitoIdentityProviderServiceException";
	constructor(options) {
		super(options);
		Object.setPrototypeOf(this, CognitoIdentityProviderServiceException.prototype);
	}
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/models/errors.js
var AccessDeniedException = class AccessDeniedException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#AccessDeniedException";
	name = "AccessDeniedException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "AccessDeniedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, AccessDeniedException.prototype);
	}
};
var InternalErrorException = class InternalErrorException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InternalErrorException";
	name = "InternalErrorException";
	$fault = "server";
	constructor(opts) {
		super({
			name: "InternalErrorException",
			$fault: "server",
			...opts
		});
		Object.setPrototypeOf(this, InternalErrorException.prototype);
	}
};
var InvalidParameterException = class InvalidParameterException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidParameterException";
	name = "InvalidParameterException";
	$fault = "client";
	reasonCode;
	constructor(opts) {
		super({
			name: "InvalidParameterException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidParameterException.prototype);
		this.reasonCode = opts.reasonCode;
	}
};
var NotAuthorizedException = class NotAuthorizedException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#NotAuthorizedException";
	name = "NotAuthorizedException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "NotAuthorizedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, NotAuthorizedException.prototype);
	}
};
var OperationNotEnabledException = class OperationNotEnabledException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#OperationNotEnabledException";
	name = "OperationNotEnabledException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "OperationNotEnabledException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, OperationNotEnabledException.prototype);
	}
};
var ResourceNotFoundException = class ResourceNotFoundException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#ResourceNotFoundException";
	name = "ResourceNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ResourceNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
	}
};
var TooManyRequestsException = class TooManyRequestsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#TooManyRequestsException";
	name = "TooManyRequestsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TooManyRequestsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TooManyRequestsException.prototype);
	}
};
var UserImportInProgressException = class UserImportInProgressException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UserImportInProgressException";
	name = "UserImportInProgressException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UserImportInProgressException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UserImportInProgressException.prototype);
	}
};
var InternalServerException = class InternalServerException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InternalServerException";
	name = "InternalServerException";
	$fault = "server";
	constructor(opts) {
		super({
			name: "InternalServerException",
			$fault: "server",
			...opts
		});
		Object.setPrototypeOf(this, InternalServerException.prototype);
	}
};
var LimitExceededException = class LimitExceededException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#LimitExceededException";
	name = "LimitExceededException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "LimitExceededException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, LimitExceededException.prototype);
	}
};
var UserNotFoundException = class UserNotFoundException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UserNotFoundException";
	name = "UserNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UserNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UserNotFoundException.prototype);
	}
};
var InvalidLambdaResponseException = class InvalidLambdaResponseException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidLambdaResponseException";
	name = "InvalidLambdaResponseException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidLambdaResponseException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidLambdaResponseException.prototype);
	}
};
var TooManyFailedAttemptsException = class TooManyFailedAttemptsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#TooManyFailedAttemptsException";
	name = "TooManyFailedAttemptsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TooManyFailedAttemptsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TooManyFailedAttemptsException.prototype);
	}
};
var UnexpectedLambdaException = class UnexpectedLambdaException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UnexpectedLambdaException";
	name = "UnexpectedLambdaException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UnexpectedLambdaException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UnexpectedLambdaException.prototype);
	}
};
var UserLambdaValidationException = class UserLambdaValidationException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UserLambdaValidationException";
	name = "UserLambdaValidationException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UserLambdaValidationException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UserLambdaValidationException.prototype);
	}
};
var CodeDeliveryFailureException = class CodeDeliveryFailureException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#CodeDeliveryFailureException";
	name = "CodeDeliveryFailureException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "CodeDeliveryFailureException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, CodeDeliveryFailureException.prototype);
	}
};
var InvalidPasswordException = class InvalidPasswordException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidPasswordException";
	name = "InvalidPasswordException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidPasswordException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidPasswordException.prototype);
	}
};
var InvalidSmsRoleAccessPolicyException = class InvalidSmsRoleAccessPolicyException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidSmsRoleAccessPolicyException";
	name = "InvalidSmsRoleAccessPolicyException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidSmsRoleAccessPolicyException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidSmsRoleAccessPolicyException.prototype);
	}
};
var InvalidSmsRoleTrustRelationshipException = class InvalidSmsRoleTrustRelationshipException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidSmsRoleTrustRelationshipException";
	name = "InvalidSmsRoleTrustRelationshipException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidSmsRoleTrustRelationshipException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidSmsRoleTrustRelationshipException.prototype);
	}
};
var PreconditionNotMetException = class PreconditionNotMetException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#PreconditionNotMetException";
	name = "PreconditionNotMetException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "PreconditionNotMetException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, PreconditionNotMetException.prototype);
	}
};
var UnsupportedUserStateException = class UnsupportedUserStateException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UnsupportedUserStateException";
	name = "UnsupportedUserStateException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UnsupportedUserStateException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UnsupportedUserStateException.prototype);
	}
};
var UsernameExistsException = class UsernameExistsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UsernameExistsException";
	name = "UsernameExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UsernameExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UsernameExistsException.prototype);
	}
};
var UserNotConfirmedException = class UserNotConfirmedException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UserNotConfirmedException";
	name = "UserNotConfirmedException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UserNotConfirmedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UserNotConfirmedException.prototype);
	}
};
var AliasExistsException = class AliasExistsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#AliasExistsException";
	name = "AliasExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "AliasExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, AliasExistsException.prototype);
	}
};
var InvalidUserPoolConfigurationException = class InvalidUserPoolConfigurationException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidUserPoolConfigurationException";
	name = "InvalidUserPoolConfigurationException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidUserPoolConfigurationException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidUserPoolConfigurationException.prototype);
	}
};
var FeatureUnavailableInTierException = class FeatureUnavailableInTierException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#FeatureUnavailableInTierException";
	name = "FeatureUnavailableInTierException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "FeatureUnavailableInTierException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, FeatureUnavailableInTierException.prototype);
	}
};
var InvalidEmailRoleAccessPolicyException = class InvalidEmailRoleAccessPolicyException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidEmailRoleAccessPolicyException";
	name = "InvalidEmailRoleAccessPolicyException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidEmailRoleAccessPolicyException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidEmailRoleAccessPolicyException.prototype);
	}
};
var MFAMethodNotFoundException = class MFAMethodNotFoundException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#MFAMethodNotFoundException";
	name = "MFAMethodNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "MFAMethodNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, MFAMethodNotFoundException.prototype);
	}
};
var PasswordResetRequiredException = class PasswordResetRequiredException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#PasswordResetRequiredException";
	name = "PasswordResetRequiredException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "PasswordResetRequiredException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, PasswordResetRequiredException.prototype);
	}
};
var UnsupportedOperationException = class UnsupportedOperationException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UnsupportedOperationException";
	name = "UnsupportedOperationException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UnsupportedOperationException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UnsupportedOperationException.prototype);
	}
};
var UserPoolAddOnNotEnabledException = class UserPoolAddOnNotEnabledException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UserPoolAddOnNotEnabledException";
	name = "UserPoolAddOnNotEnabledException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UserPoolAddOnNotEnabledException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UserPoolAddOnNotEnabledException.prototype);
	}
};
var CodeMismatchException = class CodeMismatchException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#CodeMismatchException";
	name = "CodeMismatchException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "CodeMismatchException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, CodeMismatchException.prototype);
	}
};
var ExpiredCodeException = class ExpiredCodeException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#ExpiredCodeException";
	name = "ExpiredCodeException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ExpiredCodeException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ExpiredCodeException.prototype);
	}
};
var PasswordHistoryPolicyViolationException = class PasswordHistoryPolicyViolationException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#PasswordHistoryPolicyViolationException";
	name = "PasswordHistoryPolicyViolationException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "PasswordHistoryPolicyViolationException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, PasswordHistoryPolicyViolationException.prototype);
	}
};
var SoftwareTokenMFANotFoundException = class SoftwareTokenMFANotFoundException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#SoftwareTokenMFANotFoundException";
	name = "SoftwareTokenMFANotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "SoftwareTokenMFANotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, SoftwareTokenMFANotFoundException.prototype);
	}
};
var ConcurrentModificationException = class ConcurrentModificationException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#ConcurrentModificationException";
	name = "ConcurrentModificationException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ConcurrentModificationException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ConcurrentModificationException.prototype);
	}
};
var ForbiddenException = class ForbiddenException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#ForbiddenException";
	name = "ForbiddenException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ForbiddenException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ForbiddenException.prototype);
	}
};
var WebAuthnChallengeNotFoundException = class WebAuthnChallengeNotFoundException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#WebAuthnChallengeNotFoundException";
	name = "WebAuthnChallengeNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "WebAuthnChallengeNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, WebAuthnChallengeNotFoundException.prototype);
	}
};
var WebAuthnClientMismatchException = class WebAuthnClientMismatchException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#WebAuthnClientMismatchException";
	name = "WebAuthnClientMismatchException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "WebAuthnClientMismatchException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, WebAuthnClientMismatchException.prototype);
	}
};
var WebAuthnCredentialNotSupportedException = class WebAuthnCredentialNotSupportedException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#WebAuthnCredentialNotSupportedException";
	name = "WebAuthnCredentialNotSupportedException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "WebAuthnCredentialNotSupportedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, WebAuthnCredentialNotSupportedException.prototype);
	}
};
var WebAuthnNotEnabledException = class WebAuthnNotEnabledException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#WebAuthnNotEnabledException";
	name = "WebAuthnNotEnabledException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "WebAuthnNotEnabledException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, WebAuthnNotEnabledException.prototype);
	}
};
var WebAuthnOriginNotAllowedException = class WebAuthnOriginNotAllowedException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#WebAuthnOriginNotAllowedException";
	name = "WebAuthnOriginNotAllowedException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "WebAuthnOriginNotAllowedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, WebAuthnOriginNotAllowedException.prototype);
	}
};
var WebAuthnRelyingPartyMismatchException = class WebAuthnRelyingPartyMismatchException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#WebAuthnRelyingPartyMismatchException";
	name = "WebAuthnRelyingPartyMismatchException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "WebAuthnRelyingPartyMismatchException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, WebAuthnRelyingPartyMismatchException.prototype);
	}
};
var DeviceKeyExistsException = class DeviceKeyExistsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#DeviceKeyExistsException";
	name = "DeviceKeyExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "DeviceKeyExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, DeviceKeyExistsException.prototype);
	}
};
var GroupExistsException = class GroupExistsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#GroupExistsException";
	name = "GroupExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "GroupExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, GroupExistsException.prototype);
	}
};
var DuplicateProviderException = class DuplicateProviderException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#DuplicateProviderException";
	name = "DuplicateProviderException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "DuplicateProviderException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, DuplicateProviderException.prototype);
	}
};
var ManagedLoginBrandingExistsException = class ManagedLoginBrandingExistsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#ManagedLoginBrandingExistsException";
	name = "ManagedLoginBrandingExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ManagedLoginBrandingExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ManagedLoginBrandingExistsException.prototype);
	}
};
var TermsExistsException = class TermsExistsException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#TermsExistsException";
	name = "TermsExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TermsExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TermsExistsException.prototype);
	}
};
var TierChangeNotAllowedException = class TierChangeNotAllowedException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#TierChangeNotAllowedException";
	name = "TierChangeNotAllowedException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TierChangeNotAllowedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TierChangeNotAllowedException.prototype);
	}
};
var UserPoolTaggingException = class UserPoolTaggingException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UserPoolTaggingException";
	name = "UserPoolTaggingException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UserPoolTaggingException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UserPoolTaggingException.prototype);
	}
};
var InvalidOAuthFlowException = class InvalidOAuthFlowException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#InvalidOAuthFlowException";
	name = "InvalidOAuthFlowException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidOAuthFlowException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidOAuthFlowException.prototype);
	}
};
var ScopeDoesNotExistException = class ScopeDoesNotExistException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#ScopeDoesNotExistException";
	name = "ScopeDoesNotExistException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ScopeDoesNotExistException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ScopeDoesNotExistException.prototype);
	}
};
var UnsupportedIdentityProviderException = class UnsupportedIdentityProviderException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UnsupportedIdentityProviderException";
	name = "UnsupportedIdentityProviderException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UnsupportedIdentityProviderException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UnsupportedIdentityProviderException.prototype);
	}
};
var RefreshTokenReuseException = class RefreshTokenReuseException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#RefreshTokenReuseException";
	name = "RefreshTokenReuseException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "RefreshTokenReuseException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, RefreshTokenReuseException.prototype);
	}
};
var UnauthorizedException = class UnauthorizedException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UnauthorizedException";
	name = "UnauthorizedException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UnauthorizedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UnauthorizedException.prototype);
	}
};
var UnsupportedTokenTypeException = class UnsupportedTokenTypeException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#UnsupportedTokenTypeException";
	name = "UnsupportedTokenTypeException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UnsupportedTokenTypeException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UnsupportedTokenTypeException.prototype);
	}
};
var WebAuthnConfigurationMissingException = class WebAuthnConfigurationMissingException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#WebAuthnConfigurationMissingException";
	name = "WebAuthnConfigurationMissingException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "WebAuthnConfigurationMissingException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, WebAuthnConfigurationMissingException.prototype);
	}
};
var ServiceQuotaExceededException = class ServiceQuotaExceededException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#ServiceQuotaExceededException";
	name = "ServiceQuotaExceededException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ServiceQuotaExceededException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ServiceQuotaExceededException.prototype);
	}
};
var EnableSoftwareTokenMFAException = class EnableSoftwareTokenMFAException extends CognitoIdentityProviderServiceException {
	static shapeId = "com.amazonaws.cognitoidentityprovider#EnableSoftwareTokenMFAException";
	name = "EnableSoftwareTokenMFAException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "EnableSoftwareTokenMFAException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, EnableSoftwareTokenMFAException.prototype);
	}
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/schemas/schemas_0.js
var _AC = "AvailableChallenges";
var _ADE = "AccessDeniedException";
var _AEE = "AliasExistsException";
var _AEI = "AnalyticsEndpointId";
var _AF = "AuthFlow";
var _ALGFU = "AdminListGroupsForUser";
var _ALGFUR = "AdminListGroupsForUserRequest";
var _ALGFURd = "AdminListGroupsForUserResponse";
var _ALTt = "AttributeListType";
var _AM = "AnalyticsMetadata";
var _AMT = "AnalyticsMetadataType";
var _AN = "AttributeName";
var _AP = "AuthParameters";
var _APT = "AuthParametersType";
var _AR = "AuthenticationResult";
var _ART = "AuthenticationResultType";
var _ATc = "AccessToken";
var _ATt = "AttributeType";
var _AVT = "AttributeValueType";
var _CC = "ConfirmationCode";
var _CDD = "CodeDeliveryDetails";
var _CDDT = "CodeDeliveryDetailsType";
var _CDFE = "CodeDeliveryFailureException";
var _CDr = "CreationDate";
var _CFP = "ConfirmForgotPassword";
var _CFPR = "ConfirmForgotPasswordRequest";
var _CFPRo = "ConfirmForgotPasswordResponse";
var _CI = "ClientId";
var _CIT = "ClientIdType";
var _CM = "ClientMetadata";
var _CME = "CodeMismatchException";
var _CMEo = "ConcurrentModificationException";
var _CN = "ChallengeName";
var _CP = "ChallengeParameters";
var _CS = "ClientSecret";
var _CST = "ClientSecretType";
var _CSU = "ConfirmSignUp";
var _CSUR = "ConfirmSignUpRequest";
var _CSURo = "ConfirmSignUpResponse";
var _DGK = "DeviceGroupKey";
var _DK = "DeviceKey";
var _DKEE = "DeviceKeyExistsException";
var _DM = "DeliveryMedium";
var _DPE = "DuplicateProviderException";
var _Des = "Destination";
var _Desc = "Description";
var _ECE = "ExpiredCodeException";
var _ED = "EncodedData";
var _EIxp = "ExpiresIn";
var _ESTMFAE = "EnableSoftwareTokenMFAException";
var _FAC = "ForceAliasCreation";
var _FE = "ForbiddenException";
var _FP = "ForgotPassword";
var _FPR = "ForgotPasswordRequest";
var _FPRo = "ForgotPasswordResponse";
var _FUITE = "FeatureUnavailableInTierException";
var _G = "Groups";
var _GEE = "GroupExistsException";
var _GLT = "GroupListType";
var _GN = "GroupName";
var _GT = "GroupType";
var _GTFRT = "GetTokensFromRefreshToken";
var _GTFRTR = "GetTokensFromRefreshTokenRequest";
var _GTFRTRe = "GetTokensFromRefreshTokenResponse";
var _GU = "GetUser";
var _GUR = "GetUserRequest";
var _GURe = "GetUserResponse";
var _IA = "IpAddress";
var _IAR = "InitiateAuthRequest";
var _IARn = "InitiateAuthResponse";
var _IAn = "InitiateAuth";
var _IEE = "InternalErrorException";
var _IERAPE = "InvalidEmailRoleAccessPolicyException";
var _ILRE = "InvalidLambdaResponseException";
var _IOAFE = "InvalidOAuthFlowException";
var _IPE = "InvalidParameterException";
var _IPEn = "InvalidPasswordException";
var _ISE = "InternalServerException";
var _ISRAPE = "InvalidSmsRoleAccessPolicyException";
var _ISRTRE = "InvalidSmsRoleTrustRelationshipException";
var _IT = "IdToken";
var _IUPCE = "InvalidUserPoolConfigurationException";
var _L = "Limit";
var _LEE = "LimitExceededException";
var _LMD = "LastModifiedDate";
var _MFAMNFE = "MFAMethodNotFoundException";
var _MFAO = "MFAOptions";
var _MFAOLT = "MFAOptionListType";
var _MFAOT = "MFAOptionType";
var _MLBEE = "ManagedLoginBrandingExistsException";
var _NAE = "NotAuthorizedException";
var _NDM = "NewDeviceMetadata";
var _NDMT = "NewDeviceMetadataType";
var _NT = "NextToken";
var _Na = "Name";
var _ONEE = "OperationNotEnabledException";
var _P = "Password";
var _PHPVE = "PasswordHistoryPolicyViolationException";
var _PMS = "PreferredMfaSetting";
var _PNME = "PreconditionNotMetException";
var _PRRE = "PasswordResetRequiredException";
var _PT = "PasswordType";
var _Pr = "Precedence";
var _RA = "RoleArn";
var _RCC = "ResendConfirmationCode";
var _RCCR = "ResendConfirmationCodeRequest";
var _RCCRe = "ResendConfirmationCodeResponse";
var _RNFE = "ResourceNotFoundException";
var _RT = "RefreshToken";
var _RTRE = "RefreshTokenReuseException";
var _RTRe = "RevokeTokenRequest";
var _RTRev = "RevokeTokenResponse";
var _RTev = "RevokeToken";
var _S = "Session";
var _SDNEE = "ScopeDoesNotExistException";
var _SH = "SecretHash";
var _SHT = "SecretHashType";
var _SQEE = "ServiceQuotaExceededException";
var _ST = "SessionType";
var _STMFANFE = "SoftwareTokenMFANotFoundException";
var _SUR = "SignUpRequest";
var _SURi = "SignUpResponse";
var _SUi = "SignUp";
var _TCNAE = "TierChangeNotAllowedException";
var _TEE = "TermsExistsException";
var _TMFAE = "TooManyFailedAttemptsException";
var _TMRE = "TooManyRequestsException";
var _TMT = "TokenModelType";
var _TT = "TokenType";
var _To = "Token";
var _U = "Username";
var _UA = "UserAttributes";
var _UCDT = "UserContextDataType";
var _UCDs = "UserContextData";
var _UCs = "UserConfirmed";
var _UE = "UnauthorizedException";
var _UEE = "UsernameExistsException";
var _UIIPE = "UserImportInProgressException";
var _UIPE = "UnsupportedIdentityProviderException";
var _ULE = "UnexpectedLambdaException";
var _ULVE = "UserLambdaValidationException";
var _UMFASL = "UserMFASettingList";
var _UNCE = "UserNotConfirmedException";
var _UNFE = "UserNotFoundException";
var _UOE = "UnsupportedOperationException";
var _UPAONEE = "UserPoolAddOnNotEnabledException";
var _UPI = "UserPoolId";
var _UPTE = "UserPoolTaggingException";
var _USs = "UserSub";
var _UT = "UsernameType";
var _UTTE = "UnsupportedTokenTypeException";
var _UUSE = "UnsupportedUserStateException";
var _V = "Value";
var _VD = "ValidationData";
var _WACME = "WebAuthnClientMismatchException";
var _WACMEe = "WebAuthnConfigurationMissingException";
var _WACNFE = "WebAuthnChallengeNotFoundException";
var _WACNSE = "WebAuthnCredentialNotSupportedException";
var _WANEE = "WebAuthnNotEnabledException";
var _WAONAE = "WebAuthnOriginNotAllowedException";
var _WARPME = "WebAuthnRelyingPartyMismatchException";
var _c = "client";
var _e = "error";
var _hE = "httpError";
var _m = "message";
var _rC = "reasonCode";
var _s = "smithy.ts.sdk.synthetic.com.amazonaws.cognitoidentityprovider";
var _se = "server";
var n0 = "com.amazonaws.cognitoidentityprovider";
var _s_registry = new import_schema.TypeRegistry(_s);
var CognitoIdentityProviderServiceException$ = [
	-3,
	_s,
	"CognitoIdentityProviderServiceException",
	0,
	[],
	[]
];
_s_registry.registerError(CognitoIdentityProviderServiceException$, CognitoIdentityProviderServiceException);
var n0_registry = new import_schema.TypeRegistry(n0);
var AccessDeniedException$ = [
	-3,
	n0,
	_ADE,
	{
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(AccessDeniedException$, AccessDeniedException);
var AliasExistsException$ = [
	-3,
	n0,
	_AEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(AliasExistsException$, AliasExistsException);
var CodeDeliveryFailureException$ = [
	-3,
	n0,
	_CDFE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(CodeDeliveryFailureException$, CodeDeliveryFailureException);
var CodeMismatchException$ = [
	-3,
	n0,
	_CME,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(CodeMismatchException$, CodeMismatchException);
var ConcurrentModificationException$ = [
	-3,
	n0,
	_CMEo,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(ConcurrentModificationException$, ConcurrentModificationException);
var DeviceKeyExistsException$ = [
	-3,
	n0,
	_DKEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(DeviceKeyExistsException$, DeviceKeyExistsException);
var DuplicateProviderException$ = [
	-3,
	n0,
	_DPE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(DuplicateProviderException$, DuplicateProviderException);
var EnableSoftwareTokenMFAException$ = [
	-3,
	n0,
	_ESTMFAE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(EnableSoftwareTokenMFAException$, EnableSoftwareTokenMFAException);
var ExpiredCodeException$ = [
	-3,
	n0,
	_ECE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(ExpiredCodeException$, ExpiredCodeException);
var FeatureUnavailableInTierException$ = [
	-3,
	n0,
	_FUITE,
	{
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(FeatureUnavailableInTierException$, FeatureUnavailableInTierException);
var ForbiddenException$ = [
	-3,
	n0,
	_FE,
	{
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(ForbiddenException$, ForbiddenException);
var GroupExistsException$ = [
	-3,
	n0,
	_GEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(GroupExistsException$, GroupExistsException);
var InternalErrorException$ = [
	-3,
	n0,
	_IEE,
	{ [_e]: _se },
	[_m],
	[0]
];
n0_registry.registerError(InternalErrorException$, InternalErrorException);
var InternalServerException$ = [
	-3,
	n0,
	_ISE,
	{ [_e]: _se },
	[_m],
	[0]
];
n0_registry.registerError(InternalServerException$, InternalServerException);
var InvalidEmailRoleAccessPolicyException$ = [
	-3,
	n0,
	_IERAPE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidEmailRoleAccessPolicyException$, InvalidEmailRoleAccessPolicyException);
var InvalidLambdaResponseException$ = [
	-3,
	n0,
	_ILRE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidLambdaResponseException$, InvalidLambdaResponseException);
var InvalidOAuthFlowException$ = [
	-3,
	n0,
	_IOAFE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidOAuthFlowException$, InvalidOAuthFlowException);
var InvalidParameterException$ = [
	-3,
	n0,
	_IPE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m, _rC],
	[0, 0]
];
n0_registry.registerError(InvalidParameterException$, InvalidParameterException);
var InvalidPasswordException$ = [
	-3,
	n0,
	_IPEn,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidPasswordException$, InvalidPasswordException);
var InvalidSmsRoleAccessPolicyException$ = [
	-3,
	n0,
	_ISRAPE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidSmsRoleAccessPolicyException$, InvalidSmsRoleAccessPolicyException);
var InvalidSmsRoleTrustRelationshipException$ = [
	-3,
	n0,
	_ISRTRE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidSmsRoleTrustRelationshipException$, InvalidSmsRoleTrustRelationshipException);
var InvalidUserPoolConfigurationException$ = [
	-3,
	n0,
	_IUPCE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidUserPoolConfigurationException$, InvalidUserPoolConfigurationException);
var LimitExceededException$ = [
	-3,
	n0,
	_LEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(LimitExceededException$, LimitExceededException);
var ManagedLoginBrandingExistsException$ = [
	-3,
	n0,
	_MLBEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(ManagedLoginBrandingExistsException$, ManagedLoginBrandingExistsException);
var MFAMethodNotFoundException$ = [
	-3,
	n0,
	_MFAMNFE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(MFAMethodNotFoundException$, MFAMethodNotFoundException);
var NotAuthorizedException$ = [
	-3,
	n0,
	_NAE,
	{
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(NotAuthorizedException$, NotAuthorizedException);
var OperationNotEnabledException$ = [
	-3,
	n0,
	_ONEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(OperationNotEnabledException$, OperationNotEnabledException);
var PasswordHistoryPolicyViolationException$ = [
	-3,
	n0,
	_PHPVE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(PasswordHistoryPolicyViolationException$, PasswordHistoryPolicyViolationException);
var PasswordResetRequiredException$ = [
	-3,
	n0,
	_PRRE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(PasswordResetRequiredException$, PasswordResetRequiredException);
var PreconditionNotMetException$ = [
	-3,
	n0,
	_PNME,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(PreconditionNotMetException$, PreconditionNotMetException);
var RefreshTokenReuseException$ = [
	-3,
	n0,
	_RTRE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(RefreshTokenReuseException$, RefreshTokenReuseException);
var ResourceNotFoundException$ = [
	-3,
	n0,
	_RNFE,
	{
		[_e]: _c,
		[_hE]: 404
	},
	[_m],
	[0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
var ScopeDoesNotExistException$ = [
	-3,
	n0,
	_SDNEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(ScopeDoesNotExistException$, ScopeDoesNotExistException);
var ServiceQuotaExceededException$ = [
	-3,
	n0,
	_SQEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(ServiceQuotaExceededException$, ServiceQuotaExceededException);
var SoftwareTokenMFANotFoundException$ = [
	-3,
	n0,
	_STMFANFE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(SoftwareTokenMFANotFoundException$, SoftwareTokenMFANotFoundException);
var TermsExistsException$ = [
	-3,
	n0,
	_TEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(TermsExistsException$, TermsExistsException);
var TierChangeNotAllowedException$ = [
	-3,
	n0,
	_TCNAE,
	{
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(TierChangeNotAllowedException$, TierChangeNotAllowedException);
var TooManyFailedAttemptsException$ = [
	-3,
	n0,
	_TMFAE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(TooManyFailedAttemptsException$, TooManyFailedAttemptsException);
var TooManyRequestsException$ = [
	-3,
	n0,
	_TMRE,
	{
		[_e]: _c,
		[_hE]: 429
	},
	[_m],
	[0]
];
n0_registry.registerError(TooManyRequestsException$, TooManyRequestsException);
var UnauthorizedException$ = [
	-3,
	n0,
	_UE,
	{
		[_e]: _c,
		[_hE]: 401
	},
	[_m],
	[0]
];
n0_registry.registerError(UnauthorizedException$, UnauthorizedException);
var UnexpectedLambdaException$ = [
	-3,
	n0,
	_ULE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UnexpectedLambdaException$, UnexpectedLambdaException);
var UnsupportedIdentityProviderException$ = [
	-3,
	n0,
	_UIPE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UnsupportedIdentityProviderException$, UnsupportedIdentityProviderException);
var UnsupportedOperationException$ = [
	-3,
	n0,
	_UOE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UnsupportedOperationException$, UnsupportedOperationException);
var UnsupportedTokenTypeException$ = [
	-3,
	n0,
	_UTTE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UnsupportedTokenTypeException$, UnsupportedTokenTypeException);
var UnsupportedUserStateException$ = [
	-3,
	n0,
	_UUSE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UnsupportedUserStateException$, UnsupportedUserStateException);
var UserImportInProgressException$ = [
	-3,
	n0,
	_UIIPE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UserImportInProgressException$, UserImportInProgressException);
var UserLambdaValidationException$ = [
	-3,
	n0,
	_ULVE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UserLambdaValidationException$, UserLambdaValidationException);
var UsernameExistsException$ = [
	-3,
	n0,
	_UEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UsernameExistsException$, UsernameExistsException);
var UserNotConfirmedException$ = [
	-3,
	n0,
	_UNCE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UserNotConfirmedException$, UserNotConfirmedException);
var UserNotFoundException$ = [
	-3,
	n0,
	_UNFE,
	{
		[_e]: _c,
		[_hE]: 404
	},
	[_m],
	[0]
];
n0_registry.registerError(UserNotFoundException$, UserNotFoundException);
var UserPoolAddOnNotEnabledException$ = [
	-3,
	n0,
	_UPAONEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UserPoolAddOnNotEnabledException$, UserPoolAddOnNotEnabledException);
var UserPoolTaggingException$ = [
	-3,
	n0,
	_UPTE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UserPoolTaggingException$, UserPoolTaggingException);
var WebAuthnChallengeNotFoundException$ = [
	-3,
	n0,
	_WACNFE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(WebAuthnChallengeNotFoundException$, WebAuthnChallengeNotFoundException);
var WebAuthnClientMismatchException$ = [
	-3,
	n0,
	_WACME,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(WebAuthnClientMismatchException$, WebAuthnClientMismatchException);
var WebAuthnConfigurationMissingException$ = [
	-3,
	n0,
	_WACMEe,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(WebAuthnConfigurationMissingException$, WebAuthnConfigurationMissingException);
var WebAuthnCredentialNotSupportedException$ = [
	-3,
	n0,
	_WACNSE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(WebAuthnCredentialNotSupportedException$, WebAuthnCredentialNotSupportedException);
var WebAuthnNotEnabledException$ = [
	-3,
	n0,
	_WANEE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(WebAuthnNotEnabledException$, WebAuthnNotEnabledException);
var WebAuthnOriginNotAllowedException$ = [
	-3,
	n0,
	_WAONAE,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(WebAuthnOriginNotAllowedException$, WebAuthnOriginNotAllowedException);
var WebAuthnRelyingPartyMismatchException$ = [
	-3,
	n0,
	_WARPME,
	{
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(WebAuthnRelyingPartyMismatchException$, WebAuthnRelyingPartyMismatchException);
var errorTypeRegistries = [_s_registry, n0_registry];
var AttributeValueType = [
	0,
	n0,
	_AVT,
	8,
	0
];
var ClientIdType = [
	0,
	n0,
	_CIT,
	8,
	0
];
var ClientSecretType = [
	0,
	n0,
	_CST,
	8,
	0
];
var PasswordType = [
	0,
	n0,
	_PT,
	8,
	0
];
var SecretHashType = [
	0,
	n0,
	_SHT,
	8,
	0
];
var SessionType = [
	0,
	n0,
	_ST,
	8,
	0
];
var TokenModelType = [
	0,
	n0,
	_TMT,
	8,
	0
];
var UsernameType = [
	0,
	n0,
	_UT,
	8,
	0
];
var AdminListGroupsForUserRequest$ = [
	3,
	n0,
	_ALGFUR,
	0,
	[
		_U,
		_UPI,
		_L,
		_NT
	],
	[
		[() => UsernameType, 0],
		0,
		1,
		0
	],
	2
];
var AdminListGroupsForUserResponse$ = [
	3,
	n0,
	_ALGFURd,
	0,
	[_G, _NT],
	[() => GroupListType, 0]
];
var AnalyticsMetadataType$ = [
	3,
	n0,
	_AMT,
	0,
	[_AEI],
	[0]
];
var AttributeType$ = [
	3,
	n0,
	_ATt,
	0,
	[_Na, _V],
	[0, [() => AttributeValueType, 0]],
	1
];
var AuthenticationResultType$ = [
	3,
	n0,
	_ART,
	0,
	[
		_ATc,
		_EIxp,
		_TT,
		_RT,
		_IT,
		_NDM
	],
	[
		[() => TokenModelType, 0],
		1,
		0,
		[() => TokenModelType, 0],
		[() => TokenModelType, 0],
		() => NewDeviceMetadataType$
	]
];
var CodeDeliveryDetailsType$ = [
	3,
	n0,
	_CDDT,
	0,
	[
		_Des,
		_DM,
		_AN
	],
	[
		0,
		0,
		0
	]
];
var ConfirmForgotPasswordRequest$ = [
	3,
	n0,
	_CFPR,
	0,
	[
		_CI,
		_U,
		_CC,
		_P,
		_SH,
		_AM,
		_UCDs,
		_CM
	],
	[
		[() => ClientIdType, 0],
		[() => UsernameType, 0],
		0,
		[() => PasswordType, 0],
		[() => SecretHashType, 0],
		() => AnalyticsMetadataType$,
		[() => UserContextDataType$, 0],
		128
	],
	4
];
var ConfirmForgotPasswordResponse$ = [
	3,
	n0,
	_CFPRo,
	0,
	[],
	[]
];
var ConfirmSignUpRequest$ = [
	3,
	n0,
	_CSUR,
	0,
	[
		_CI,
		_U,
		_CC,
		_SH,
		_FAC,
		_AM,
		_UCDs,
		_CM,
		_S
	],
	[
		[() => ClientIdType, 0],
		[() => UsernameType, 0],
		0,
		[() => SecretHashType, 0],
		2,
		() => AnalyticsMetadataType$,
		[() => UserContextDataType$, 0],
		128,
		[() => SessionType, 0]
	],
	3
];
var ConfirmSignUpResponse$ = [
	3,
	n0,
	_CSURo,
	0,
	[_S],
	[[() => SessionType, 0]]
];
var ForgotPasswordRequest$ = [
	3,
	n0,
	_FPR,
	0,
	[
		_CI,
		_U,
		_SH,
		_UCDs,
		_AM,
		_CM
	],
	[
		[() => ClientIdType, 0],
		[() => UsernameType, 0],
		[() => SecretHashType, 0],
		[() => UserContextDataType$, 0],
		() => AnalyticsMetadataType$,
		128
	],
	2
];
var ForgotPasswordResponse$ = [
	3,
	n0,
	_FPRo,
	0,
	[_CDD],
	[() => CodeDeliveryDetailsType$]
];
var GetTokensFromRefreshTokenRequest$ = [
	3,
	n0,
	_GTFRTR,
	0,
	[
		_RT,
		_CI,
		_CS,
		_DK,
		_CM
	],
	[
		[() => TokenModelType, 0],
		[() => ClientIdType, 0],
		[() => ClientSecretType, 0],
		0,
		128
	],
	2
];
var GetTokensFromRefreshTokenResponse$ = [
	3,
	n0,
	_GTFRTRe,
	0,
	[_AR],
	[[() => AuthenticationResultType$, 0]]
];
var GetUserRequest$ = [
	3,
	n0,
	_GUR,
	0,
	[_ATc],
	[[() => TokenModelType, 0]],
	1
];
var GetUserResponse$ = [
	3,
	n0,
	_GURe,
	0,
	[
		_U,
		_UA,
		_MFAO,
		_PMS,
		_UMFASL
	],
	[
		[() => UsernameType, 0],
		[() => AttributeListType, 0],
		() => MFAOptionListType,
		0,
		64
	],
	2
];
var GroupType$ = [
	3,
	n0,
	_GT,
	0,
	[
		_GN,
		_UPI,
		_Desc,
		_RA,
		_Pr,
		_LMD,
		_CDr
	],
	[
		0,
		0,
		0,
		0,
		1,
		4,
		4
	]
];
var InitiateAuthRequest$ = [
	3,
	n0,
	_IAR,
	0,
	[
		_AF,
		_CI,
		_AP,
		_CM,
		_AM,
		_UCDs,
		_S
	],
	[
		0,
		[() => ClientIdType, 0],
		[() => AuthParametersType, 0],
		128,
		() => AnalyticsMetadataType$,
		[() => UserContextDataType$, 0],
		[() => SessionType, 0]
	],
	2
];
var InitiateAuthResponse$ = [
	3,
	n0,
	_IARn,
	0,
	[
		_CN,
		_S,
		_CP,
		_AR,
		_AC
	],
	[
		0,
		[() => SessionType, 0],
		128,
		[() => AuthenticationResultType$, 0],
		64
	]
];
var MFAOptionType$ = [
	3,
	n0,
	_MFAOT,
	0,
	[_DM, _AN],
	[0, 0]
];
var NewDeviceMetadataType$ = [
	3,
	n0,
	_NDMT,
	0,
	[_DK, _DGK],
	[0, 0]
];
var ResendConfirmationCodeRequest$ = [
	3,
	n0,
	_RCCR,
	0,
	[
		_CI,
		_U,
		_SH,
		_UCDs,
		_AM,
		_CM
	],
	[
		[() => ClientIdType, 0],
		[() => UsernameType, 0],
		[() => SecretHashType, 0],
		[() => UserContextDataType$, 0],
		() => AnalyticsMetadataType$,
		128
	],
	2
];
var ResendConfirmationCodeResponse$ = [
	3,
	n0,
	_RCCRe,
	0,
	[_CDD],
	[() => CodeDeliveryDetailsType$]
];
var RevokeTokenRequest$ = [
	3,
	n0,
	_RTRe,
	0,
	[
		_To,
		_CI,
		_CS
	],
	[
		[() => TokenModelType, 0],
		[() => ClientIdType, 0],
		[() => ClientSecretType, 0]
	],
	2
];
var RevokeTokenResponse$ = [
	3,
	n0,
	_RTRev,
	0,
	[],
	[]
];
var SignUpRequest$ = [
	3,
	n0,
	_SUR,
	0,
	[
		_CI,
		_U,
		_SH,
		_P,
		_UA,
		_VD,
		_AM,
		_UCDs,
		_CM
	],
	[
		[() => ClientIdType, 0],
		[() => UsernameType, 0],
		[() => SecretHashType, 0],
		[() => PasswordType, 0],
		[() => AttributeListType, 0],
		[() => AttributeListType, 0],
		() => AnalyticsMetadataType$,
		[() => UserContextDataType$, 0],
		128
	],
	2
];
var SignUpResponse$ = [
	3,
	n0,
	_SURi,
	0,
	[
		_UCs,
		_USs,
		_CDD,
		_S
	],
	[
		2,
		0,
		() => CodeDeliveryDetailsType$,
		[() => SessionType, 0]
	],
	2
];
var UserContextDataType$ = [
	3,
	n0,
	_UCDT,
	8,
	[_IA, _ED],
	[0, 0]
];
var AttributeListType = [
	1,
	n0,
	_ALTt,
	0,
	[() => AttributeType$, 0]
];
var GroupListType = [
	1,
	n0,
	_GLT,
	0,
	() => GroupType$
];
var MFAOptionListType = [
	1,
	n0,
	_MFAOLT,
	0,
	() => MFAOptionType$
];
var AuthParametersType = [
	2,
	n0,
	_APT,
	8,
	0,
	0
];
var AdminListGroupsForUser$ = [
	9,
	n0,
	_ALGFU,
	0,
	() => AdminListGroupsForUserRequest$,
	() => AdminListGroupsForUserResponse$
];
var ConfirmForgotPassword$ = [
	9,
	n0,
	_CFP,
	0,
	() => ConfirmForgotPasswordRequest$,
	() => ConfirmForgotPasswordResponse$
];
var ConfirmSignUp$ = [
	9,
	n0,
	_CSU,
	0,
	() => ConfirmSignUpRequest$,
	() => ConfirmSignUpResponse$
];
var ForgotPassword$ = [
	9,
	n0,
	_FP,
	0,
	() => ForgotPasswordRequest$,
	() => ForgotPasswordResponse$
];
var GetTokensFromRefreshToken$ = [
	9,
	n0,
	_GTFRT,
	0,
	() => GetTokensFromRefreshTokenRequest$,
	() => GetTokensFromRefreshTokenResponse$
];
var GetUser$ = [
	9,
	n0,
	_GU,
	0,
	() => GetUserRequest$,
	() => GetUserResponse$
];
var InitiateAuth$ = [
	9,
	n0,
	_IAn,
	0,
	() => InitiateAuthRequest$,
	() => InitiateAuthResponse$
];
var ResendConfirmationCode$ = [
	9,
	n0,
	_RCC,
	0,
	() => ResendConfirmationCodeRequest$,
	() => ResendConfirmationCodeResponse$
];
var RevokeToken$ = [
	9,
	n0,
	_RTev,
	0,
	() => RevokeTokenRequest$,
	() => RevokeTokenResponse$
];
var SignUp$ = [
	9,
	n0,
	_SUi,
	0,
	() => SignUpRequest$,
	() => SignUpResponse$
];
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/runtimeConfig.shared.js
var import_protocols$1 = require_protocols$1();
var import_serde = require_serde();
var getRuntimeConfig$1 = (config) => {
	return {
		apiVersion: "2016-04-18",
		base64Decoder: config?.base64Decoder ?? import_serde.fromBase64,
		base64Encoder: config?.base64Encoder ?? import_serde.toBase64,
		disableHostPrefix: config?.disableHostPrefix ?? false,
		endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
		extensions: config?.extensions ?? [],
		httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultCognitoIdentityProviderHttpAuthSchemeProvider,
		httpAuthSchemes: config?.httpAuthSchemes ?? [{
			schemeId: "aws.auth#sigv4",
			identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
			signer: new import_httpAuthSchemes.AwsSdkSigV4Signer()
		}, {
			schemeId: "smithy.api#noAuth",
			identityProvider: (ipc) => ipc.getIdentityProvider("smithy.api#noAuth") || (async () => ({})),
			signer: new import_dist_cjs.NoAuthSigner()
		}],
		logger: config?.logger ?? new import_client.NoOpLogger(),
		protocol: config?.protocol ?? import_protocols.AwsJson1_1Protocol,
		protocolSettings: config?.protocolSettings ?? {
			defaultNamespace: "com.amazonaws.cognitoidentityprovider",
			errorTypeRegistries,
			xmlNamespace: "http://cognito-idp.amazonaws.com/doc/2016-04-18/",
			version: "2016-04-18",
			serviceTarget: "AWSCognitoIdentityProviderService"
		},
		serviceId: config?.serviceId ?? "Cognito Identity Provider",
		sha256: config?.sha256 ?? import_checksum.Sha256,
		urlParser: config?.urlParser ?? import_protocols$1.parseUrl,
		utf8Decoder: config?.utf8Decoder ?? import_serde.fromUtf8,
		utf8Encoder: config?.utf8Encoder ?? import_serde.toUtf8
	};
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/runtimeConfig.js
var getRuntimeConfig = (config) => {
	(0, import_client.emitWarningIfUnsupportedVersion)(process.version);
	const defaultsMode = (0, import_config.resolveDefaultsModeConfig)(config);
	const defaultConfigProvider = () => defaultsMode().then(import_client.loadConfigsForDefaultMode);
	const clientSharedValues = getRuntimeConfig$1(config);
	(0, import_client$1.emitWarningIfUnsupportedVersion)(process.version);
	const loaderConfig = {
		profile: config?.profile,
		logger: clientSharedValues.logger
	};
	return {
		...clientSharedValues,
		...config,
		runtime: "node",
		defaultsMode,
		authSchemePreference: config?.authSchemePreference ?? (0, import_config.loadConfig)(import_httpAuthSchemes.NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
		bodyLengthChecker: config?.bodyLengthChecker ?? import_serde.calculateBodyLength,
		credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
		defaultUserAgentProvider: config?.defaultUserAgentProvider ?? (0, import_client$1.createDefaultUserAgentProvider)({
			serviceId: clientSharedValues.serviceId,
			clientVersion: package_default.version
		}),
		maxAttempts: config?.maxAttempts ?? (0, import_config.loadConfig)(import_retry.NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
		region: config?.region ?? (0, import_config.loadConfig)(import_config.NODE_REGION_CONFIG_OPTIONS, {
			...import_config.NODE_REGION_CONFIG_FILE_OPTIONS,
			...loaderConfig
		}),
		requestHandler: NodeHttpHandler.create(config?.requestHandler ?? defaultConfigProvider),
		retryMode: config?.retryMode ?? (0, import_config.loadConfig)({
			...import_retry.NODE_RETRY_MODE_CONFIG_OPTIONS,
			default: async () => (await defaultConfigProvider()).retryMode || import_retry.DEFAULT_RETRY_MODE
		}, config),
		streamCollector: config?.streamCollector ?? import_serde$1.streamCollector,
		useDualstackEndpoint: config?.useDualstackEndpoint ?? (0, import_config.loadConfig)(import_config.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
		useFipsEndpoint: config?.useFipsEndpoint ?? (0, import_config.loadConfig)(import_config.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
		userAgentAppId: config?.userAgentAppId ?? (0, import_config.loadConfig)(import_client$1.NODE_APP_ID_CONFIG_OPTIONS, loaderConfig)
	};
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/auth/httpAuthExtensionConfiguration.js
var getHttpAuthExtensionConfiguration = (runtimeConfig) => {
	const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
	let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
	let _credentials = runtimeConfig.credentials;
	return {
		setHttpAuthScheme(httpAuthScheme) {
			const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
			if (index === -1) _httpAuthSchemes.push(httpAuthScheme);
			else _httpAuthSchemes.splice(index, 1, httpAuthScheme);
		},
		httpAuthSchemes() {
			return _httpAuthSchemes;
		},
		setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
			_httpAuthSchemeProvider = httpAuthSchemeProvider;
		},
		httpAuthSchemeProvider() {
			return _httpAuthSchemeProvider;
		},
		setCredentials(credentials) {
			_credentials = credentials;
		},
		credentials() {
			return _credentials;
		}
	};
};
var resolveHttpAuthRuntimeConfig = (config) => {
	return {
		httpAuthSchemes: config.httpAuthSchemes(),
		httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
		credentials: config.credentials()
	};
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/runtimeExtensions.js
var resolveRuntimeExtensions = (runtimeConfig, extensions) => {
	const extensionConfiguration = Object.assign((0, import_client$1.getAwsRegionExtensionConfiguration)(runtimeConfig), (0, import_client.getDefaultExtensionConfiguration)(runtimeConfig), (0, import_protocols$1.getHttpHandlerExtensionConfiguration)(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
	extensions.forEach((extension) => extension.configure(extensionConfiguration));
	return Object.assign(runtimeConfig, (0, import_client$1.resolveAwsRegionExtensionConfiguration)(extensionConfiguration), (0, import_client.resolveDefaultRuntimeConfig)(extensionConfiguration), (0, import_protocols$1.resolveHttpHandlerRuntimeConfig)(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/CognitoIdentityProviderClient.js
var CognitoIdentityProviderClient = class extends import_client.Client {
	config;
	constructor(...[configuration]) {
		const _config_0 = getRuntimeConfig(configuration || {});
		super(_config_0);
		this.initConfig = _config_0;
		const _config_1 = resolveClientEndpointParameters(_config_0);
		const _config_2 = (0, import_client$1.resolveUserAgentConfig)(_config_1);
		const _config_3 = (0, import_retry.resolveRetryConfig)(_config_2);
		const _config_4 = (0, import_config.resolveRegionConfig)(_config_3);
		const _config_5 = (0, import_client$1.resolveHostHeaderConfig)(_config_4);
		const _config_8 = resolveRuntimeExtensions(resolveHttpAuthSchemeConfig((0, import_endpoints.resolveEndpointConfig)(_config_5)), configuration?.extensions || []);
		this.config = _config_8;
		this.middlewareStack.use((0, import_schema.getSchemaSerdePlugin)(this.config));
		this.middlewareStack.use((0, import_client$1.getUserAgentPlugin)(this.config));
		this.middlewareStack.use((0, import_retry.getRetryPlugin)(this.config));
		this.middlewareStack.use((0, import_protocols$1.getContentLengthPlugin)(this.config));
		this.middlewareStack.use((0, import_client$1.getHostHeaderPlugin)(this.config));
		this.middlewareStack.use((0, import_client$1.getLoggerPlugin)(this.config));
		this.middlewareStack.use((0, import_client$1.getRecursionDetectionPlugin)(this.config));
		this.middlewareStack.use((0, import_dist_cjs.getHttpAuthSchemeEndpointRuleSetPlugin)(this.config, {
			httpAuthSchemeParametersProvider: defaultCognitoIdentityProviderHttpAuthSchemeParametersProvider,
			identityProviderConfigProvider: async (config) => new import_dist_cjs.DefaultIdentityProviderConfig({ "aws.auth#sigv4": config.credentials })
		}));
		this.middlewareStack.use((0, import_dist_cjs.getHttpSigningPlugin)(this.config));
	}
	destroy() {
		super.destroy();
	}
};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commandBuilder.js
var command = (0, import_client.makeBuilder)(commonParams, "AWSCognitoIdentityProviderService", "CognitoIdentityProviderClient", import_endpoints.getEndpointPlugin);
var _ep0 = {};
var _mw0 = (Command, cs, config, o) => [];
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/AdminListGroupsForUserCommand.js
var AdminListGroupsForUserCommand = class extends command(_ep0, _mw0, "AdminListGroupsForUser", AdminListGroupsForUser$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/ConfirmForgotPasswordCommand.js
var ConfirmForgotPasswordCommand = class extends command(_ep0, _mw0, "ConfirmForgotPassword", ConfirmForgotPassword$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/ConfirmSignUpCommand.js
var ConfirmSignUpCommand = class extends command(_ep0, _mw0, "ConfirmSignUp", ConfirmSignUp$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/ForgotPasswordCommand.js
var ForgotPasswordCommand = class extends command(_ep0, _mw0, "ForgotPassword", ForgotPassword$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/GetTokensFromRefreshTokenCommand.js
var GetTokensFromRefreshTokenCommand = class extends command(_ep0, _mw0, "GetTokensFromRefreshToken", GetTokensFromRefreshToken$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/GetUserCommand.js
var GetUserCommand = class extends command(_ep0, _mw0, "GetUser", GetUser$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/InitiateAuthCommand.js
var InitiateAuthCommand = class extends command(_ep0, _mw0, "InitiateAuth", InitiateAuth$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/ResendConfirmationCodeCommand.js
var ResendConfirmationCodeCommand = class extends command(_ep0, _mw0, "ResendConfirmationCode", ResendConfirmationCode$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/RevokeTokenCommand.js
var RevokeTokenCommand = class extends command(_ep0, _mw0, "RevokeToken", RevokeToken$) {};
// node_modules/@aws-sdk/client-cognito-identity-provider/dist-es/commands/SignUpCommand.js
var SignUpCommand = class extends command(_ep0, _mw0, "SignUp", SignUp$) {};
export { signatureV4aContainer as C, getSigningKey as D, createScope as E, init_credentialDerivation as O, init_signature_v4a_container as S, init_SignatureV4 as T, defaultProvider as _, GetUserCommand as a, require_protocols as b, ConfirmSignUpCommand as c, CognitoIdentityProviderClient as d, dist_es_exports as f, init_node_http_handler as g, NodeHttpHandler as h, InitiateAuthCommand as i, ConfirmForgotPasswordCommand as l, init_dist_es as m, RevokeTokenCommand as n, GetTokensFromRefreshTokenCommand as o, import_serde$1 as p, ResendConfirmationCodeCommand as r, ForgotPasswordCommand as s, SignUpCommand as t, AdminListGroupsForUserCommand as u, dist_es_exports$1 as v, SignatureV4 as w, init_dist_es$2 as x, require_httpAuthSchemes as y };
