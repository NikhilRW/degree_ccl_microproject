import { o as __toESM, t as __commonJSMin } from "../../_runtime.mjs";
import { a as require_retry, c as require_checksum, d as require_config, f as require_client, i as require_dist_cjs, l as require_serde, o as require_protocols, p as require_schema, r as require_client$1, u as require_endpoints } from "./checksums+[...].mjs";
import { _ as defaultProvider, b as require_protocols$1, h as NodeHttpHandler, m as init_dist_es, p as import_serde$1, y as require_httpAuthSchemes } from "./client-cognito-identity-provider+[...].mjs";
// node_modules/@aws-sdk/core/dist-cjs/submodules/account-id-endpoint/index.js
var require_account_id_endpoint = /* @__PURE__ */ __commonJSMin(((exports) => {
	var { normalizeProvider } = require_client();
	var DEFAULT_ACCOUNT_ID_ENDPOINT_MODE = "preferred";
	var ACCOUNT_ID_ENDPOINT_MODE_VALUES = [
		"disabled",
		"preferred",
		"required"
	];
	function validateAccountIdEndpointMode(value) {
		return ACCOUNT_ID_ENDPOINT_MODE_VALUES.includes(value);
	}
	var resolveAccountIdEndpointModeConfig = (input) => {
		const { accountIdEndpointMode } = input;
		const accountIdEndpointModeProvider = normalizeProvider(accountIdEndpointMode ?? DEFAULT_ACCOUNT_ID_ENDPOINT_MODE);
		return Object.assign(input, { accountIdEndpointMode: async () => {
			const accIdMode = await accountIdEndpointModeProvider();
			if (!validateAccountIdEndpointMode(accIdMode)) throw new Error(`Invalid value for accountIdEndpointMode: ${accIdMode}. Valid values are: "required", "preferred", "disabled".`);
			return accIdMode;
		} });
	};
	var err = "Invalid AccountIdEndpointMode value";
	var _throw = (message) => {
		throw new Error(message);
	};
	var ENV_ACCOUNT_ID_ENDPOINT_MODE = "AWS_ACCOUNT_ID_ENDPOINT_MODE";
	var CONFIG_ACCOUNT_ID_ENDPOINT_MODE = "account_id_endpoint_mode";
	exports.NODE_ACCOUNT_ID_ENDPOINT_MODE_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => {
			const value = env[ENV_ACCOUNT_ID_ENDPOINT_MODE];
			if (value && !validateAccountIdEndpointMode(value)) _throw(err);
			return value;
		},
		configFileSelector: (profile) => {
			const value = profile[CONFIG_ACCOUNT_ID_ENDPOINT_MODE];
			if (value && !validateAccountIdEndpointMode(value)) _throw(err);
			return value;
		},
		default: DEFAULT_ACCOUNT_ID_ENDPOINT_MODE
	};
	exports.resolveAccountIdEndpointModeConfig = resolveAccountIdEndpointModeConfig;
}));
// node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/configurations.js
var ENV_ENDPOINT_DISCOVERY = ["AWS_ENABLE_ENDPOINT_DISCOVERY", "AWS_ENDPOINT_DISCOVERY_ENABLED"];
var CONFIG_ENDPOINT_DISCOVERY = "endpoint_discovery_enabled";
var isFalsy = (value) => ["false", "0"].indexOf(value) >= 0;
var NODE_ENDPOINT_DISCOVERY_CONFIG_OPTIONS = {
	environmentVariableSelector: (env) => {
		for (let i = 0; i < ENV_ENDPOINT_DISCOVERY.length; i++) {
			const envKey = ENV_ENDPOINT_DISCOVERY[i];
			if (envKey in env) {
				const value = env[envKey];
				if (value === "") throw Error(`Environment variable ${envKey} can't be empty of undefined, got "${value}"`);
				return !isFalsy(value);
			}
		}
	},
	configFileSelector: (profile) => {
		if (CONFIG_ENDPOINT_DISCOVERY in profile) {
			const value = profile[CONFIG_ENDPOINT_DISCOVERY];
			if (value === void 0) throw Error(`Shared config entry ${CONFIG_ENDPOINT_DISCOVERY} can't be undefined, got "${value}"`);
			return !isFalsy(value);
		}
	},
	default: void 0
};
// node_modules/obliterator/iterator.js
var require_iterator = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Obliterator Iterator Class
	* ===========================
	*
	* Simple class representing the library's iterators.
	*/
	/**
	* Iterator class.
	*
	* @constructor
	* @param {function} next - Next function.
	*/
	function Iterator(next) {
		Object.defineProperty(this, "_next", {
			writable: false,
			enumerable: false,
			value: next
		});
		this.done = false;
	}
	/**
	* Next function.
	*
	* @return {object}
	*/
	Iterator.prototype.next = function() {
		if (this.done) return { done: true };
		var step = this._next();
		if (step.done) this.done = true;
		return step;
	};
	/**
	* If symbols are supported, we add `next` to `Symbol.iterator`.
	*/
	if (typeof Symbol !== "undefined") Iterator.prototype[Symbol.iterator] = function() {
		return this;
	};
	/**
	* Returning an iterator of the given values.
	*
	* @param  {any...} values - Values.
	* @return {Iterator}
	*/
	Iterator.of = function() {
		var args = arguments, l = args.length, i = 0;
		return new Iterator(function() {
			if (i >= l) return { done: true };
			return {
				done: false,
				value: args[i++]
			};
		});
	};
	/**
	* Returning an empty iterator.
	*
	* @return {Iterator}
	*/
	Iterator.empty = function() {
		var iterator = new Iterator(null);
		iterator.done = true;
		return iterator;
	};
	/**
	* Returning whether the given value is an iterator.
	*
	* @param  {any} value - Value.
	* @return {boolean}
	*/
	Iterator.is = function(value) {
		if (value instanceof Iterator) return true;
		return typeof value === "object" && value !== null && typeof value.next === "function";
	};
	/**
	* Exporting.
	*/
	module.exports = Iterator;
}));
// node_modules/obliterator/foreach.js
var require_foreach = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Obliterator ForEach Function
	* =============================
	*
	* Helper function used to easily iterate over mixed values.
	*/
	/**
	* Constants.
	*/
	var ARRAY_BUFFER_SUPPORT = typeof ArrayBuffer !== "undefined";
	var SYMBOL_SUPPORT = typeof Symbol !== "undefined";
	/**
	* Function able to iterate over almost any iterable JS value.
	*
	* @param  {any}      iterable - Iterable value.
	* @param  {function} callback - Callback function.
	*/
	function forEach(iterable, callback) {
		var iterator, k, i, l, s;
		if (!iterable) throw new Error("obliterator/forEach: invalid iterable.");
		if (typeof callback !== "function") throw new Error("obliterator/forEach: expecting a callback.");
		if (Array.isArray(iterable) || ARRAY_BUFFER_SUPPORT && ArrayBuffer.isView(iterable) || typeof iterable === "string" || iterable.toString() === "[object Arguments]") {
			for (i = 0, l = iterable.length; i < l; i++) callback(iterable[i], i);
			return;
		}
		if (typeof iterable.forEach === "function") {
			iterable.forEach(callback);
			return;
		}
		if (SYMBOL_SUPPORT && Symbol.iterator in iterable && typeof iterable.next !== "function") iterable = iterable[Symbol.iterator]();
		if (typeof iterable.next === "function") {
			iterator = iterable;
			i = 0;
			while (s = iterator.next(), s.done !== true) {
				callback(s.value, i);
				i++;
			}
			return;
		}
		for (k in iterable) if (iterable.hasOwnProperty(k)) callback(iterable[k], k);
	}
	/**
	* Same function as the above `forEach` but will yield `null` when the target
	* does not have keys.
	*
	* @param  {any}      iterable - Iterable value.
	* @param  {function} callback - Callback function.
	*/
	forEach.forEachWithNullKeys = function(iterable, callback) {
		var iterator, k, i, l, s;
		if (!iterable) throw new Error("obliterator/forEachWithNullKeys: invalid iterable.");
		if (typeof callback !== "function") throw new Error("obliterator/forEachWithNullKeys: expecting a callback.");
		if (Array.isArray(iterable) || ARRAY_BUFFER_SUPPORT && ArrayBuffer.isView(iterable) || typeof iterable === "string" || iterable.toString() === "[object Arguments]") {
			for (i = 0, l = iterable.length; i < l; i++) callback(iterable[i], null);
			return;
		}
		if (iterable instanceof Set) {
			iterable.forEach(function(value) {
				callback(value, null);
			});
			return;
		}
		if (typeof iterable.forEach === "function") {
			iterable.forEach(callback);
			return;
		}
		if (SYMBOL_SUPPORT && Symbol.iterator in iterable && typeof iterable.next !== "function") iterable = iterable[Symbol.iterator]();
		if (typeof iterable.next === "function") {
			iterator = iterable;
			i = 0;
			while (s = iterator.next(), s.done !== true) {
				callback(s.value, null);
				i++;
			}
			return;
		}
		for (k in iterable) if (iterable.hasOwnProperty(k)) callback(iterable[k], k);
	};
	/**
	* Exporting.
	*/
	module.exports = forEach;
}));
// node_modules/mnemonist/utils/typed-arrays.js
var require_typed_arrays = /* @__PURE__ */ __commonJSMin(((exports) => {
	/**
	* Mnemonist Typed Array Helpers
	* ==============================
	*
	* Miscellaneous helpers related to typed arrays.
	*/
	/**
	* When using an unsigned integer array to store pointers, one might want to
	* choose the optimal word size in regards to the actual numbers of pointers
	* to store.
	*
	* This helpers does just that.
	*
	* @param  {number} size - Expected size of the array to map.
	* @return {TypedArray}
	*/
	var MAX_8BIT_INTEGER = Math.pow(2, 8) - 1;
	var MAX_16BIT_INTEGER = Math.pow(2, 16) - 1;
	var MAX_32BIT_INTEGER = Math.pow(2, 32) - 1;
	var MAX_SIGNED_8BIT_INTEGER = Math.pow(2, 7) - 1;
	var MAX_SIGNED_16BIT_INTEGER = Math.pow(2, 15) - 1;
	var MAX_SIGNED_32BIT_INTEGER = Math.pow(2, 31) - 1;
	exports.getPointerArray = function(size) {
		var maxIndex = size - 1;
		if (maxIndex <= MAX_8BIT_INTEGER) return Uint8Array;
		if (maxIndex <= MAX_16BIT_INTEGER) return Uint16Array;
		if (maxIndex <= MAX_32BIT_INTEGER) return Uint32Array;
		return Float64Array;
	};
	exports.getSignedPointerArray = function(size) {
		var maxIndex = size - 1;
		if (maxIndex <= MAX_SIGNED_8BIT_INTEGER) return Int8Array;
		if (maxIndex <= MAX_SIGNED_16BIT_INTEGER) return Int16Array;
		if (maxIndex <= MAX_SIGNED_32BIT_INTEGER) return Int32Array;
		return Float64Array;
	};
	/**
	* Function returning the minimal type able to represent the given number.
	*
	* @param  {number} value - Value to test.
	* @return {TypedArrayClass}
	*/
	exports.getNumberType = function(value) {
		if (value === (value | 0)) {
			if (Math.sign(value) === -1) {
				if (value <= 127 && value >= -128) return Int8Array;
				if (value <= 32767 && value >= -32768) return Int16Array;
				return Int32Array;
			} else {
				if (value <= 255) return Uint8Array;
				if (value <= 65535) return Uint16Array;
				return Uint32Array;
			}
		}
		return Float64Array;
	};
	/**
	* Function returning the minimal type able to represent the given array
	* of JavaScript numbers.
	*
	* @param  {array}    array  - Array to represent.
	* @param  {function} getter - Optional getter.
	* @return {TypedArrayClass}
	*/
	var TYPE_PRIORITY = {
		Uint8Array: 1,
		Int8Array: 2,
		Uint16Array: 3,
		Int16Array: 4,
		Uint32Array: 5,
		Int32Array: 6,
		Float32Array: 7,
		Float64Array: 8
	};
	exports.getMinimalRepresentation = function(array, getter) {
		var maxType = null, maxPriority = 0, p, t, v, i = 0, l = array.length;
		for (; i < l; i++) {
			v = getter ? getter(array[i]) : array[i];
			t = exports.getNumberType(v);
			p = TYPE_PRIORITY[t.name];
			if (p > maxPriority) {
				maxPriority = p;
				maxType = t;
			}
		}
		return maxType;
	};
	/**
	* Function returning whether the given value is a typed array.
	*
	* @param  {any} value - Value to test.
	* @return {boolean}
	*/
	exports.isTypedArray = function(value) {
		return typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView(value);
	};
	/**
	* Function used to concat byte arrays.
	*
	* @param  {...ByteArray}
	* @return {ByteArray}
	*/
	exports.concat = function() {
		var length = 0, i = 0, o, l = arguments.length;
		for (; i < l; i++) length += arguments[i].length;
		var array = new arguments[0].constructor(length);
		for (i = 0, o = 0; i < l; i++) {
			array.set(arguments[i], o);
			o += arguments[i].length;
		}
		return array;
	};
	/**
	* Function used to initialize a byte array of indices.
	*
	* @param  {number}    length - Length of target.
	* @return {ByteArray}
	*/
	exports.indices = function(length) {
		var array = new (exports.getPointerArray(length))(length);
		for (var i = 0; i < length; i++) array[i] = i;
		return array;
	};
}));
// node_modules/mnemonist/utils/iterables.js
var require_iterables = /* @__PURE__ */ __commonJSMin(((exports) => {
	/**
	* Mnemonist Iterable Function
	* ============================
	*
	* Harmonized iteration helpers over mixed iterable targets.
	*/
	var forEach = require_foreach();
	var typed = require_typed_arrays();
	/**
	* Function used to determine whether the given object supports array-like
	* random access.
	*
	* @param  {any} target - Target object.
	* @return {boolean}
	*/
	function isArrayLike(target) {
		return Array.isArray(target) || typed.isTypedArray(target);
	}
	/**
	* Function used to guess the length of the structure over which we are going
	* to iterate.
	*
	* @param  {any} target - Target object.
	* @return {number|undefined}
	*/
	function guessLength(target) {
		if (typeof target.length === "number") return target.length;
		if (typeof target.size === "number") return target.size;
	}
	/**
	* Function used to convert an iterable to an array.
	*
	* @param  {any}   target - Iteration target.
	* @return {array}
	*/
	function toArray(target) {
		var l = guessLength(target);
		var array = typeof l === "number" ? new Array(l) : [];
		var i = 0;
		forEach(target, function(value) {
			array[i++] = value;
		});
		return array;
	}
	/**
	* Same as above but returns a supplementary indices array.
	*
	* @param  {any}   target - Iteration target.
	* @return {array}
	*/
	function toArrayWithIndices(target) {
		var l = guessLength(target);
		var IndexArray = typeof l === "number" ? typed.getPointerArray(l) : Array;
		var array = typeof l === "number" ? new Array(l) : [];
		var indices = typeof l === "number" ? new IndexArray(l) : [];
		var i = 0;
		forEach(target, function(value) {
			array[i] = value;
			indices[i] = i++;
		});
		return [array, indices];
	}
	/**
	* Exporting.
	*/
	exports.isArrayLike = isArrayLike;
	exports.guessLength = guessLength;
	exports.toArray = toArray;
	exports.toArrayWithIndices = toArrayWithIndices;
}));
// node_modules/@aws-sdk/endpoint-cache/dist-es/EndpointCache.js
var import_lru_cache = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Mnemonist LRUCache
	* ===================
	*
	* JavaScript implementation of the LRU Cache data structure. To save up
	* memory and allocations this implementation represents its underlying
	* doubly-linked list as static arrays and pointers. Thus, memory is allocated
	* only once at instantiation and JS objects are never created to serve as
	* pointers. This also means this implementation does not trigger too many
	* garbage collections.
	*
	* Note that to save up memory, a LRU Cache can be implemented using a singly
	* linked list by storing predecessors' pointers as hashmap values.
	* However, this means more hashmap lookups and would probably slow the whole
	* thing down. What's more, pointers are not the things taking most space in
	* memory.
	*/
	var Iterator = require_iterator();
	var forEach = require_foreach();
	var typed = require_typed_arrays();
	var iterables = require_iterables();
	/**
	* LRUCache.
	*
	* @constructor
	* @param {function} Keys     - Array class for storing keys.
	* @param {function} Values   - Array class for storing values.
	* @param {number}   capacity - Desired capacity.
	*/
	function LRUCache(Keys, Values, capacity) {
		if (arguments.length < 2) {
			capacity = Keys;
			Keys = null;
			Values = null;
		}
		this.capacity = capacity;
		if (typeof this.capacity !== "number" || this.capacity <= 0) throw new Error("mnemonist/lru-cache: capacity should be positive number.");
		var PointerArray = typed.getPointerArray(capacity);
		this.forward = new PointerArray(capacity);
		this.backward = new PointerArray(capacity);
		this.K = typeof Keys === "function" ? new Keys(capacity) : new Array(capacity);
		this.V = typeof Values === "function" ? new Values(capacity) : new Array(capacity);
		this.size = 0;
		this.head = 0;
		this.tail = 0;
		this.items = {};
	}
	/**
	* Method used to clear the structure.
	*
	* @return {undefined}
	*/
	LRUCache.prototype.clear = function() {
		this.size = 0;
		this.head = 0;
		this.tail = 0;
		this.items = {};
	};
	/**
	* Method used to splay a value on top.
	*
	* @param  {number}   pointer - Pointer of the value to splay on top.
	* @return {LRUCache}
	*/
	LRUCache.prototype.splayOnTop = function(pointer) {
		var oldHead = this.head;
		if (this.head === pointer) return this;
		var previous = this.backward[pointer], next = this.forward[pointer];
		if (this.tail === pointer) this.tail = previous;
		else this.backward[next] = previous;
		this.forward[previous] = next;
		this.backward[oldHead] = pointer;
		this.head = pointer;
		this.forward[pointer] = oldHead;
		return this;
	};
	/**
	* Method used to set the value for the given key in the cache.
	*
	* @param  {any} key   - Key.
	* @param  {any} value - Value.
	* @return {undefined}
	*/
	LRUCache.prototype.set = function(key, value) {
		var pointer = this.items[key];
		if (typeof pointer !== "undefined") {
			this.splayOnTop(pointer);
			this.V[pointer] = value;
			return;
		}
		if (this.size < this.capacity) pointer = this.size++;
		else {
			pointer = this.tail;
			this.tail = this.backward[pointer];
			delete this.items[this.K[pointer]];
		}
		this.items[key] = pointer;
		this.K[pointer] = key;
		this.V[pointer] = value;
		this.forward[pointer] = this.head;
		this.backward[this.head] = pointer;
		this.head = pointer;
	};
	/**
	* Method used to set the value for the given key in the cache
	*
	* @param  {any} key   - Key.
	* @param  {any} value - Value.
	* @return {{evicted: boolean, key: any, value: any}} An object containing the
	* key and value of an item that was overwritten or evicted in the set
	* operation, as well as a boolean indicating whether it was evicted due to
	* limited capacity. Return value is null if nothing was evicted or overwritten
	* during the set operation.
	*/
	LRUCache.prototype.setpop = function(key, value) {
		var oldValue = null;
		var oldKey = null;
		var pointer = this.items[key];
		if (typeof pointer !== "undefined") {
			this.splayOnTop(pointer);
			oldValue = this.V[pointer];
			this.V[pointer] = value;
			return {
				evicted: false,
				key,
				value: oldValue
			};
		}
		if (this.size < this.capacity) pointer = this.size++;
		else {
			pointer = this.tail;
			this.tail = this.backward[pointer];
			oldValue = this.V[pointer];
			oldKey = this.K[pointer];
			delete this.items[this.K[pointer]];
		}
		this.items[key] = pointer;
		this.K[pointer] = key;
		this.V[pointer] = value;
		this.forward[pointer] = this.head;
		this.backward[this.head] = pointer;
		this.head = pointer;
		if (oldKey) return {
			evicted: true,
			key: oldKey,
			value: oldValue
		};
		else return null;
	};
	/**
	* Method used to check whether the key exists in the cache.
	*
	* @param  {any} key   - Key.
	* @return {boolean}
	*/
	LRUCache.prototype.has = function(key) {
		return key in this.items;
	};
	/**
	* Method used to get the value attached to the given key. Will move the
	* related key to the front of the underlying linked list.
	*
	* @param  {any} key   - Key.
	* @return {any}
	*/
	LRUCache.prototype.get = function(key) {
		var pointer = this.items[key];
		if (typeof pointer === "undefined") return;
		this.splayOnTop(pointer);
		return this.V[pointer];
	};
	/**
	* Method used to get the value attached to the given key. Does not modify
	* the ordering of the underlying linked list.
	*
	* @param  {any} key   - Key.
	* @return {any}
	*/
	LRUCache.prototype.peek = function(key) {
		var pointer = this.items[key];
		if (typeof pointer === "undefined") return;
		return this.V[pointer];
	};
	/**
	* Method used to iterate over the cache's entries using a callback.
	*
	* @param  {function}  callback - Function to call for each item.
	* @param  {object}    scope    - Optional scope.
	* @return {undefined}
	*/
	LRUCache.prototype.forEach = function(callback, scope) {
		scope = arguments.length > 1 ? scope : this;
		var i = 0, l = this.size;
		var pointer = this.head, keys = this.K, values = this.V, forward = this.forward;
		while (i < l) {
			callback.call(scope, values[pointer], keys[pointer], this);
			pointer = forward[pointer];
			i++;
		}
	};
	/**
	* Method used to create an iterator over the cache's keys from most
	* recently used to least recently used.
	*
	* @return {Iterator}
	*/
	LRUCache.prototype.keys = function() {
		var i = 0, l = this.size;
		var pointer = this.head, keys = this.K, forward = this.forward;
		return new Iterator(function() {
			if (i >= l) return { done: true };
			var key = keys[pointer];
			i++;
			if (i < l) pointer = forward[pointer];
			return {
				done: false,
				value: key
			};
		});
	};
	/**
	* Method used to create an iterator over the cache's values from most
	* recently used to least recently used.
	*
	* @return {Iterator}
	*/
	LRUCache.prototype.values = function() {
		var i = 0, l = this.size;
		var pointer = this.head, values = this.V, forward = this.forward;
		return new Iterator(function() {
			if (i >= l) return { done: true };
			var value = values[pointer];
			i++;
			if (i < l) pointer = forward[pointer];
			return {
				done: false,
				value
			};
		});
	};
	/**
	* Method used to create an iterator over the cache's entries from most
	* recently used to least recently used.
	*
	* @return {Iterator}
	*/
	LRUCache.prototype.entries = function() {
		var i = 0, l = this.size;
		var pointer = this.head, keys = this.K, values = this.V, forward = this.forward;
		return new Iterator(function() {
			if (i >= l) return { done: true };
			var key = keys[pointer], value = values[pointer];
			i++;
			if (i < l) pointer = forward[pointer];
			return {
				done: false,
				value: [key, value]
			};
		});
	};
	/**
	* Attaching the #.entries method to Symbol.iterator if possible.
	*/
	if (typeof Symbol !== "undefined") LRUCache.prototype[Symbol.iterator] = LRUCache.prototype.entries;
	/**
	* Convenience known methods.
	*/
	LRUCache.prototype.inspect = function() {
		var proxy = /* @__PURE__ */ new Map();
		var iterator = this.entries(), step;
		while (step = iterator.next(), !step.done) proxy.set(step.value[0], step.value[1]);
		Object.defineProperty(proxy, "constructor", {
			value: LRUCache,
			enumerable: false
		});
		return proxy;
	};
	if (typeof Symbol !== "undefined") LRUCache.prototype[Symbol.for("nodejs.util.inspect.custom")] = LRUCache.prototype.inspect;
	/**
	* Static @.from function taking an arbitrary iterable & converting it into
	* a structure.
	*
	* @param  {Iterable} iterable - Target iterable.
	* @param  {function} Keys     - Array class for storing keys.
	* @param  {function} Values   - Array class for storing values.
	* @param  {number}   capacity - Cache's capacity.
	* @return {LRUCache}
	*/
	LRUCache.from = function(iterable, Keys, Values, capacity) {
		if (arguments.length < 2) {
			capacity = iterables.guessLength(iterable);
			if (typeof capacity !== "number") throw new Error("mnemonist/lru-cache.from: could not guess iterable length. Please provide desired capacity as last argument.");
		} else if (arguments.length === 2) {
			capacity = Keys;
			Keys = null;
			Values = null;
		}
		var cache = new LRUCache(Keys, Values, capacity);
		forEach(iterable, function(value, key) {
			cache.set(key, value);
		});
		return cache;
	};
	/**
	* Exporting.
	*/
	module.exports = LRUCache;
})))());
var EndpointCache$1 = class {
	cache;
	constructor(capacity) {
		this.cache = new import_lru_cache.default(capacity);
	}
	getEndpoint(key) {
		const endpointsWithExpiry = this.get(key);
		if (!endpointsWithExpiry || endpointsWithExpiry.length === 0) return;
		const endpoints = endpointsWithExpiry.map((endpoint) => endpoint.Address);
		return endpoints[Math.floor(Math.random() * endpoints.length)];
	}
	get(key) {
		if (!this.has(key)) return;
		const value = this.cache.get(key);
		if (!value) return;
		const now = Date.now();
		const endpointsWithExpiry = value.filter((endpoint) => now < endpoint.Expires);
		if (endpointsWithExpiry.length === 0) {
			this.delete(key);
			return;
		}
		return endpointsWithExpiry;
	}
	set(key, endpoints) {
		const now = Date.now();
		this.cache.set(key, endpoints.map(({ Address, CachePeriodInMinutes }) => ({
			Address,
			Expires: now + CachePeriodInMinutes * 60 * 1e3
		})));
	}
	delete(key) {
		this.cache.set(key, []);
	}
	has(key) {
		if (!this.cache.has(key)) return false;
		const endpoints = this.cache.peek(key);
		if (!endpoints) return false;
		return endpoints.length > 0;
	}
	clear() {
		this.cache.clear();
	}
};
// node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/resolveEndpointDiscoveryConfig.js
var resolveEndpointDiscoveryConfig = (input, { endpointDiscoveryCommandCtor }) => {
	const { endpointCacheSize, endpointDiscoveryEnabled, endpointDiscoveryEnabledProvider } = input;
	return Object.assign(input, {
		endpointDiscoveryCommandCtor,
		endpointCache: new EndpointCache$1(endpointCacheSize ?? 1e3),
		endpointDiscoveryEnabled: endpointDiscoveryEnabled !== void 0 ? () => Promise.resolve(endpointDiscoveryEnabled) : endpointDiscoveryEnabledProvider,
		isClientEndpointDiscoveryEnabled: endpointDiscoveryEnabled !== void 0
	});
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/auth/httpAuthSchemeProvider.js
var import_schema = require_schema();
var import_config = require_config();
var import_endpoints = require_endpoints();
var import_serde = require_serde();
var import_protocols = require_protocols();
var import_retry = require_retry();
var import_dist_cjs = require_dist_cjs();
var import_client = require_client$1();
var import_protocols$1 = require_protocols$1();
var import_account_id_endpoint = require_account_id_endpoint();
var import_httpAuthSchemes = require_httpAuthSchemes();
var import_client$1 = require_client();
var defaultDynamoDBHttpAuthSchemeParametersProvider = async (config, context, input) => {
	return {
		operation: (0, import_client$1.getSmithyContext)(context).operation,
		region: await (0, import_client$1.normalizeProvider)(config.region)() || (() => {
			throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
		})()
	};
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
	return {
		schemeId: "aws.auth#sigv4",
		signingProperties: {
			name: "dynamodb",
			region: authParameters.region
		},
		propertiesExtractor: (config, context) => ({ signingProperties: {
			config,
			context
		} })
	};
}
var defaultDynamoDBHttpAuthSchemeProvider = (authParameters) => {
	const options = [];
	switch (authParameters.operation) {
		default: options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
	}
	return options;
};
var resolveHttpAuthSchemeConfig = (config) => {
	const config_0 = (0, import_httpAuthSchemes.resolveAwsSdkSigV4Config)(config);
	return Object.assign(config_0, { authSchemePreference: (0, import_client$1.normalizeProvider)(config.authSchemePreference ?? []) });
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/endpoint/EndpointParameters.js
var resolveClientEndpointParameters = (options) => {
	return Object.assign(options, {
		useDualstackEndpoint: options.useDualstackEndpoint ?? false,
		useFipsEndpoint: options.useFipsEndpoint ?? false,
		defaultSigningName: "dynamodb"
	});
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commandBuilder.js
var command = (0, import_client$1.makeBuilder)({
	UseFIPS: {
		type: "builtInParams",
		name: "useFipsEndpoint"
	},
	AccountId: {
		type: "builtInParams",
		name: "accountId"
	},
	Endpoint: {
		type: "builtInParams",
		name: "endpoint"
	},
	Region: {
		type: "builtInParams",
		name: "region"
	},
	UseDualStack: {
		type: "builtInParams",
		name: "useDualstackEndpoint"
	},
	AccountIdEndpointMode: {
		type: "builtInParams",
		name: "accountIdEndpointMode"
	}
}, "DynamoDB_20120810", "DynamoDBClient", import_endpoints.getEndpointPlugin);
var _ep0 = {};
var _ep2 = { ResourceArn: {
	type: "contextParams",
	name: "TableName"
} };
var _ep13 = { ResourceArnList: {
	type: "operationContextParams",
	get: (input) => input?.TransactItems?.map((obj) => [
		obj?.ConditionCheck?.TableName,
		obj?.Put?.TableName,
		obj?.Delete?.TableName,
		obj?.Update?.TableName
	].filter((i) => i)).flat()
} };
var _mw0 = (Command, cs, config, o) => [];
// node_modules/@aws-sdk/client-dynamodb/dist-es/models/DynamoDBServiceException.js
var DynamoDBServiceException = class DynamoDBServiceException extends import_client$1.ServiceException {
	static shapeId = "smithy.ts.sdk.synthetic.com.amazonaws.dynamodb#DynamoDBServiceException";
	constructor(options) {
		super(options);
		Object.setPrototypeOf(this, DynamoDBServiceException.prototype);
	}
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/models/errors.js
var BackupInUseException = class BackupInUseException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#BackupInUseException";
	name = "BackupInUseException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "BackupInUseException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, BackupInUseException.prototype);
	}
};
var BackupNotFoundException = class BackupNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#BackupNotFoundException";
	name = "BackupNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "BackupNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, BackupNotFoundException.prototype);
	}
};
var InternalServerError = class InternalServerError extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#InternalServerError";
	name = "InternalServerError";
	$fault = "server";
	constructor(opts) {
		super({
			name: "InternalServerError",
			$fault: "server",
			...opts
		});
		Object.setPrototypeOf(this, InternalServerError.prototype);
	}
};
var RequestLimitExceeded = class RequestLimitExceeded extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#RequestLimitExceeded";
	name = "RequestLimitExceeded";
	$fault = "client";
	ThrottlingReasons;
	constructor(opts) {
		super({
			name: "RequestLimitExceeded",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, RequestLimitExceeded.prototype);
		this.ThrottlingReasons = opts.ThrottlingReasons;
	}
};
var ThrottlingException = class ThrottlingException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ThrottlingException";
	name = "ThrottlingException";
	$fault = "client";
	throttlingReasons;
	constructor(opts) {
		super({
			name: "ThrottlingException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ThrottlingException.prototype);
		this.throttlingReasons = opts.throttlingReasons;
	}
};
var InvalidEndpointException = class InvalidEndpointException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#InvalidEndpointException";
	name = "InvalidEndpointException";
	$fault = "client";
	Message;
	constructor(opts) {
		super({
			name: "InvalidEndpointException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidEndpointException.prototype);
		this.Message = opts.Message;
	}
};
var ProvisionedThroughputExceededException = class ProvisionedThroughputExceededException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ProvisionedThroughputExceededException";
	name = "ProvisionedThroughputExceededException";
	$fault = "client";
	ThrottlingReasons;
	constructor(opts) {
		super({
			name: "ProvisionedThroughputExceededException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ProvisionedThroughputExceededException.prototype);
		this.ThrottlingReasons = opts.ThrottlingReasons;
	}
};
var ResourceNotFoundException = class ResourceNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ResourceNotFoundException";
	name = "ResourceNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ResourceNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
	}
};
var ItemCollectionSizeLimitExceededException = class ItemCollectionSizeLimitExceededException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException";
	name = "ItemCollectionSizeLimitExceededException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ItemCollectionSizeLimitExceededException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ItemCollectionSizeLimitExceededException.prototype);
	}
};
var ReplicatedWriteConflictException = class ReplicatedWriteConflictException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ReplicatedWriteConflictException";
	name = "ReplicatedWriteConflictException";
	$fault = "client";
	$retryable = {};
	constructor(opts) {
		super({
			name: "ReplicatedWriteConflictException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ReplicatedWriteConflictException.prototype);
	}
};
var ContinuousBackupsUnavailableException = class ContinuousBackupsUnavailableException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ContinuousBackupsUnavailableException";
	name = "ContinuousBackupsUnavailableException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ContinuousBackupsUnavailableException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ContinuousBackupsUnavailableException.prototype);
	}
};
var LimitExceededException = class LimitExceededException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#LimitExceededException";
	name = "LimitExceededException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "LimitExceededException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, LimitExceededException.prototype);
	}
};
var TableInUseException = class TableInUseException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#TableInUseException";
	name = "TableInUseException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TableInUseException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TableInUseException.prototype);
	}
};
var TableNotFoundException = class TableNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#TableNotFoundException";
	name = "TableNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TableNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TableNotFoundException.prototype);
	}
};
var GlobalTableAlreadyExistsException = class GlobalTableAlreadyExistsException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#GlobalTableAlreadyExistsException";
	name = "GlobalTableAlreadyExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "GlobalTableAlreadyExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, GlobalTableAlreadyExistsException.prototype);
	}
};
var ResourceInUseException = class ResourceInUseException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ResourceInUseException";
	name = "ResourceInUseException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ResourceInUseException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ResourceInUseException.prototype);
	}
};
var TransactionConflictException = class TransactionConflictException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#TransactionConflictException";
	name = "TransactionConflictException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TransactionConflictException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TransactionConflictException.prototype);
	}
};
var PolicyNotFoundException = class PolicyNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#PolicyNotFoundException";
	name = "PolicyNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "PolicyNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, PolicyNotFoundException.prototype);
	}
};
var ExportNotFoundException = class ExportNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ExportNotFoundException";
	name = "ExportNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ExportNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ExportNotFoundException.prototype);
	}
};
var GlobalTableNotFoundException = class GlobalTableNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#GlobalTableNotFoundException";
	name = "GlobalTableNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "GlobalTableNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, GlobalTableNotFoundException.prototype);
	}
};
var ImportNotFoundException = class ImportNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ImportNotFoundException";
	name = "ImportNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ImportNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ImportNotFoundException.prototype);
	}
};
var DuplicateItemException = class DuplicateItemException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#DuplicateItemException";
	name = "DuplicateItemException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "DuplicateItemException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, DuplicateItemException.prototype);
	}
};
var IdempotentParameterMismatchException = class IdempotentParameterMismatchException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#IdempotentParameterMismatchException";
	name = "IdempotentParameterMismatchException";
	$fault = "client";
	Message;
	constructor(opts) {
		super({
			name: "IdempotentParameterMismatchException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, IdempotentParameterMismatchException.prototype);
		this.Message = opts.Message;
	}
};
var TransactionInProgressException = class TransactionInProgressException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#TransactionInProgressException";
	name = "TransactionInProgressException";
	$fault = "client";
	Message;
	constructor(opts) {
		super({
			name: "TransactionInProgressException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TransactionInProgressException.prototype);
		this.Message = opts.Message;
	}
};
var ExportConflictException = class ExportConflictException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ExportConflictException";
	name = "ExportConflictException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ExportConflictException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ExportConflictException.prototype);
	}
};
var InvalidExportTimeException = class InvalidExportTimeException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#InvalidExportTimeException";
	name = "InvalidExportTimeException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidExportTimeException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidExportTimeException.prototype);
	}
};
var PointInTimeRecoveryUnavailableException = class PointInTimeRecoveryUnavailableException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#PointInTimeRecoveryUnavailableException";
	name = "PointInTimeRecoveryUnavailableException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "PointInTimeRecoveryUnavailableException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, PointInTimeRecoveryUnavailableException.prototype);
	}
};
var ImportConflictException = class ImportConflictException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ImportConflictException";
	name = "ImportConflictException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ImportConflictException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ImportConflictException.prototype);
	}
};
var TableAlreadyExistsException = class TableAlreadyExistsException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#TableAlreadyExistsException";
	name = "TableAlreadyExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TableAlreadyExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TableAlreadyExistsException.prototype);
	}
};
var InvalidRestoreTimeException = class InvalidRestoreTimeException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#InvalidRestoreTimeException";
	name = "InvalidRestoreTimeException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidRestoreTimeException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidRestoreTimeException.prototype);
	}
};
var ReplicaAlreadyExistsException = class ReplicaAlreadyExistsException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ReplicaAlreadyExistsException";
	name = "ReplicaAlreadyExistsException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ReplicaAlreadyExistsException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ReplicaAlreadyExistsException.prototype);
	}
};
var ReplicaNotFoundException = class ReplicaNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ReplicaNotFoundException";
	name = "ReplicaNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ReplicaNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ReplicaNotFoundException.prototype);
	}
};
var IndexNotFoundException = class IndexNotFoundException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#IndexNotFoundException";
	name = "IndexNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "IndexNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, IndexNotFoundException.prototype);
	}
};
var ConditionalCheckFailedException = class ConditionalCheckFailedException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#ConditionalCheckFailedException";
	name = "ConditionalCheckFailedException";
	$fault = "client";
	Item;
	constructor(opts) {
		super({
			name: "ConditionalCheckFailedException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ConditionalCheckFailedException.prototype);
		this.Item = opts.Item;
	}
};
var TransactionCanceledException = class TransactionCanceledException extends DynamoDBServiceException {
	static shapeId = "com.amazonaws.dynamodb#TransactionCanceledException";
	name = "TransactionCanceledException";
	$fault = "client";
	Message;
	CancellationReasons;
	constructor(opts) {
		super({
			name: "TransactionCanceledException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TransactionCanceledException.prototype);
		this.Message = opts.Message;
		this.CancellationReasons = opts.CancellationReasons;
	}
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/schemas/schemas_0.js
var _A = "Action";
var _AM = "AttributeMap";
var _ATG = "AttributesToGet";
var _AU = "AttributeUpdates";
var _AV = "AttributeValue";
var _AVL = "AttributeValueList";
var _AVU = "AttributeValueUpdate";
var _Ad = "Address";
var _At = "Attributes";
var _BIUE = "BackupInUseException";
var _BNFE = "BackupNotFoundException";
var _BOOL = "BOOL";
var _BS_ = "BS";
var _B_ = "B";
var _C = "Code";
var _CBUE = "ContinuousBackupsUnavailableException";
var _CC = "ConsumedCapacity";
var _CCFE = "ConditionalCheckFailedException";
var _CCM = "ConsumedCapacityMultiple";
var _CCo = "ConditionCheck";
var _CE = "ConditionExpression";
var _CO = "ComparisonOperator";
var _COo = "ConditionalOperator";
var _CPIM = "CachePeriodInMinutes";
var _CR = "CancellationReasons";
var _CRL = "CancellationReasonList";
var _CRT = "ClientRequestToken";
var _CRa = "CancellationReason";
var _CRo = "ConsistentRead";
var _CU = "CapacityUnits";
var _Ca = "Capacity";
var _Co = "Condition";
var _Cou = "Count";
var _DE = "DescribeEndpoints";
var _DER = "DescribeEndpointsRequest";
var _DERe = "DescribeEndpointsResponse";
var _DI = "DeleteItem";
var _DIE = "DuplicateItemException";
var _DII = "DeleteItemInput";
var _DIO = "DeleteItemOutput";
var _Del = "Delete";
var _EAM = "ExpectedAttributeMap";
var _EAN = "ExpressionAttributeNames";
var _EAV = "ExpressionAttributeValues";
var _EAVM = "ExpressionAttributeValueMap";
var _EAVx = "ExpectedAttributeValue";
var _ECE = "ExportConflictException";
var _ENFE = "ExportNotFoundException";
var _ESK = "ExclusiveStartKey";
var _En = "Endpoints";
var _End = "Endpoint";
var _Ex = "Expected";
var _Exi = "Exists";
var _FCM = "FilterConditionMap";
var _FEi = "FilterExpression";
var _GI = "GetItem";
var _GII = "GetItemInput";
var _GIO = "GetItemOutput";
var _GSI = "GlobalSecondaryIndexes";
var _GTAEE = "GlobalTableAlreadyExistsException";
var _GTNFE = "GlobalTableNotFoundException";
var _I = "Item";
var _ICE = "ImportConflictException";
var _ICK = "ItemCollectionKey";
var _ICKAM = "ItemCollectionKeyAttributeMap";
var _ICM = "ItemCollectionMetrics";
var _ICMM = "ItemCollectionMetricsMultiple";
var _ICMPT = "ItemCollectionMetricsPerTable";
var _ICSLEE = "ItemCollectionSizeLimitExceededException";
var _IEE = "InvalidEndpointException";
var _IETE = "InvalidExportTimeException";
var _IL = "ItemList";
var _IN = "IndexName";
var _INFE = "ImportNotFoundException";
var _INFEn = "IndexNotFoundException";
var _IPME = "IdempotentParameterMismatchException";
var _IRTE = "InvalidRestoreTimeException";
var _ISE = "InternalServerError";
var _It = "Items";
var _K = "Key";
var _KC = "KeyConditions";
var _KCE = "KeyConditionExpression";
var _L = "Limit";
var _LAV = "ListAttributeValue";
var _LEE = "LimitExceededException";
var _LEK = "LastEvaluatedKey";
var _LSI = "LocalSecondaryIndexes";
var _L_ = "L";
var _M = "Message";
var _MAV = "MapAttributeValue";
var _M_ = "M";
var _N = "N";
var _NS = "NS";
var _NULL = "NULL";
var _PE = "ProjectionExpression";
var _PI = "PutItem";
var _PII = "PutItemInput";
var _PIIAM = "PutItemInputAttributeMap";
var _PIO = "PutItemOutput";
var _PITRUE = "PointInTimeRecoveryUnavailableException";
var _PNFE = "PolicyNotFoundException";
var _PTEE = "ProvisionedThroughputExceededException";
var _Pu = "Put";
var _Q = "Query";
var _QF = "QueryFilter";
var _QI = "QueryInput";
var _QO = "QueryOutput";
var _RAEE = "ReplicaAlreadyExistsException";
var _RCC = "ReturnConsumedCapacity";
var _RCU = "ReadCapacityUnits";
var _RICM = "ReturnItemCollectionMetrics";
var _RIUE = "ResourceInUseException";
var _RLE = "RequestLimitExceeded";
var _RNFE = "ReplicaNotFoundException";
var _RNFEe = "ResourceNotFoundException";
var _RV = "ReturnValues";
var _RVOCCF = "ReturnValuesOnConditionCheckFailure";
var _RWCE = "ReplicatedWriteConflictException";
var _SC = "ScannedCount";
var _SERGB = "SizeEstimateRangeGB";
var _SF = "ScanFilter";
var _SI = "ScanInput";
var _SICM = "SecondaryIndexesCapacityMap";
var _SIF = "ScanIndexForward";
var _SO = "ScanOutput";
var _SS_ = "SS";
var _S_ = "S";
var _Sca = "Scan";
var _Se = "Select";
var _Seg = "Segment";
var _T = "Table";
var _TAEE = "TableAlreadyExistsException";
var _TCE = "TransactionCanceledException";
var _TCEr = "TransactionConflictException";
var _TE = "ThrottlingException";
var _TIPE = "TransactionInProgressException";
var _TIUE = "TableInUseException";
var _TIr = "TransactItems";
var _TN = "TableName";
var _TNFE = "TableNotFoundException";
var _TR = "ThrottlingReasons";
var _TRL = "ThrottlingReasonList";
var _TRh = "ThrottlingReason";
var _TSo = "TotalSegments";
var _TWI = "TransactWriteItem";
var _TWII = "TransactWriteItemsInput";
var _TWIL = "TransactWriteItemList";
var _TWIO = "TransactWriteItemsOutput";
var _TWIr = "TransactWriteItems";
var _U = "Update";
var _UE = "UpdateExpression";
var _UII = "UpdateItemInput";
var _UIO = "UpdateItemOutput";
var _UIp = "UpdateItem";
var _V = "Value";
var _VC = "VectorCapacity";
var _VI = "VectorIndexes";
var _VICM = "VectorIndexesCapacityMap";
var _VSRB = "VectorSearchRequestBytes";
var _VWRB = "VectorWriteRequestBytes";
var _WCU = "WriteCapacityUnits";
var _aQE = "awsQueryError";
var _c = "client";
var _e = "error";
var _hE = "httpError";
var _m = "message";
var _r = "reason";
var _re = "resource";
var _s = "smithy.ts.sdk.synthetic.com.amazonaws.dynamodb";
var _se = "server";
var _tR = "throttlingReasons";
var n0 = "com.amazonaws.dynamodb";
var _s_registry = new import_schema.TypeRegistry(_s);
var DynamoDBServiceException$ = [
	-3,
	_s,
	"DynamoDBServiceException",
	0,
	[],
	[]
];
_s_registry.registerError(DynamoDBServiceException$, DynamoDBServiceException);
var n0_registry = new import_schema.TypeRegistry(n0);
var BackupInUseException$ = [
	-3,
	n0,
	_BIUE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(BackupInUseException$, BackupInUseException);
var BackupNotFoundException$ = [
	-3,
	n0,
	_BNFE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(BackupNotFoundException$, BackupNotFoundException);
var ConditionalCheckFailedException$ = [
	-3,
	n0,
	_CCFE,
	{ [_e]: _c },
	[_m, _I],
	[0, () => AttributeMap]
];
n0_registry.registerError(ConditionalCheckFailedException$, ConditionalCheckFailedException);
var ContinuousBackupsUnavailableException$ = [
	-3,
	n0,
	_CBUE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ContinuousBackupsUnavailableException$, ContinuousBackupsUnavailableException);
var DuplicateItemException$ = [
	-3,
	n0,
	_DIE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(DuplicateItemException$, DuplicateItemException);
var ExportConflictException$ = [
	-3,
	n0,
	_ECE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ExportConflictException$, ExportConflictException);
var ExportNotFoundException$ = [
	-3,
	n0,
	_ENFE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ExportNotFoundException$, ExportNotFoundException);
var GlobalTableAlreadyExistsException$ = [
	-3,
	n0,
	_GTAEE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(GlobalTableAlreadyExistsException$, GlobalTableAlreadyExistsException);
var GlobalTableNotFoundException$ = [
	-3,
	n0,
	_GTNFE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(GlobalTableNotFoundException$, GlobalTableNotFoundException);
var IdempotentParameterMismatchException$ = [
	-3,
	n0,
	_IPME,
	{ [_e]: _c },
	[_M],
	[0]
];
n0_registry.registerError(IdempotentParameterMismatchException$, IdempotentParameterMismatchException);
var ImportConflictException$ = [
	-3,
	n0,
	_ICE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ImportConflictException$, ImportConflictException);
var ImportNotFoundException$ = [
	-3,
	n0,
	_INFE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ImportNotFoundException$, ImportNotFoundException);
var IndexNotFoundException$ = [
	-3,
	n0,
	_INFEn,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(IndexNotFoundException$, IndexNotFoundException);
var InternalServerError$ = [
	-3,
	n0,
	_ISE,
	{ [_e]: _se },
	[_m],
	[0]
];
n0_registry.registerError(InternalServerError$, InternalServerError);
var InvalidEndpointException$ = [
	-3,
	n0,
	_IEE,
	{
		[_e]: _c,
		[_hE]: 421
	},
	[_M],
	[0]
];
n0_registry.registerError(InvalidEndpointException$, InvalidEndpointException);
var InvalidExportTimeException$ = [
	-3,
	n0,
	_IETE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(InvalidExportTimeException$, InvalidExportTimeException);
var InvalidRestoreTimeException$ = [
	-3,
	n0,
	_IRTE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(InvalidRestoreTimeException$, InvalidRestoreTimeException);
var ItemCollectionSizeLimitExceededException$ = [
	-3,
	n0,
	_ICSLEE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ItemCollectionSizeLimitExceededException$, ItemCollectionSizeLimitExceededException);
var LimitExceededException$ = [
	-3,
	n0,
	_LEE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(LimitExceededException$, LimitExceededException);
var PointInTimeRecoveryUnavailableException$ = [
	-3,
	n0,
	_PITRUE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(PointInTimeRecoveryUnavailableException$, PointInTimeRecoveryUnavailableException);
var PolicyNotFoundException$ = [
	-3,
	n0,
	_PNFE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(PolicyNotFoundException$, PolicyNotFoundException);
var ProvisionedThroughputExceededException$ = [
	-3,
	n0,
	_PTEE,
	{ [_e]: _c },
	[_m, _TR],
	[0, () => ThrottlingReasonList]
];
n0_registry.registerError(ProvisionedThroughputExceededException$, ProvisionedThroughputExceededException);
var ReplicaAlreadyExistsException$ = [
	-3,
	n0,
	_RAEE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ReplicaAlreadyExistsException$, ReplicaAlreadyExistsException);
var ReplicaNotFoundException$ = [
	-3,
	n0,
	_RNFE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ReplicaNotFoundException$, ReplicaNotFoundException);
var ReplicatedWriteConflictException$ = [
	-3,
	n0,
	_RWCE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ReplicatedWriteConflictException$, ReplicatedWriteConflictException);
var RequestLimitExceeded$ = [
	-3,
	n0,
	_RLE,
	{ [_e]: _c },
	[_m, _TR],
	[0, () => ThrottlingReasonList]
];
n0_registry.registerError(RequestLimitExceeded$, RequestLimitExceeded);
var ResourceInUseException$ = [
	-3,
	n0,
	_RIUE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ResourceInUseException$, ResourceInUseException);
var ResourceNotFoundException$ = [
	-3,
	n0,
	_RNFEe,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
var TableAlreadyExistsException$ = [
	-3,
	n0,
	_TAEE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(TableAlreadyExistsException$, TableAlreadyExistsException);
var TableInUseException$ = [
	-3,
	n0,
	_TIUE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(TableInUseException$, TableInUseException);
var TableNotFoundException$ = [
	-3,
	n0,
	_TNFE,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(TableNotFoundException$, TableNotFoundException);
var ThrottlingException$ = [
	-3,
	n0,
	_TE,
	{
		[_aQE]: [`Throttling`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m, _tR],
	[0, () => ThrottlingReasonList]
];
n0_registry.registerError(ThrottlingException$, ThrottlingException);
var TransactionCanceledException$ = [
	-3,
	n0,
	_TCE,
	{ [_e]: _c },
	[_M, _CR],
	[0, () => CancellationReasonList]
];
n0_registry.registerError(TransactionCanceledException$, TransactionCanceledException);
var TransactionConflictException$ = [
	-3,
	n0,
	_TCEr,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(TransactionConflictException$, TransactionConflictException);
var TransactionInProgressException$ = [
	-3,
	n0,
	_TIPE,
	{ [_e]: _c },
	[_M],
	[0]
];
n0_registry.registerError(TransactionInProgressException$, TransactionInProgressException);
var errorTypeRegistries = [_s_registry, n0_registry];
var AttributeValueUpdate$ = [
	3,
	n0,
	_AVU,
	0,
	[_V, _A],
	[() => AttributeValue$, 0]
];
var CancellationReason$ = [
	3,
	n0,
	_CRa,
	0,
	[
		_I,
		_C,
		_M
	],
	[
		() => AttributeMap,
		0,
		0
	]
];
var Capacity$ = [
	3,
	n0,
	_Ca,
	0,
	[
		_RCU,
		_WCU,
		_CU
	],
	[
		1,
		1,
		1
	]
];
var Condition$ = [
	3,
	n0,
	_Co,
	0,
	[_CO, _AVL],
	[0, () => AttributeValueList],
	1
];
var ConditionCheck$ = [
	3,
	n0,
	_CCo,
	0,
	[
		_K,
		_TN,
		_CE,
		_EAN,
		_EAV,
		_RVOCCF
	],
	[
		() => Key,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		0
	],
	3
];
var ConsumedCapacity$ = [
	3,
	n0,
	_CC,
	0,
	[
		_TN,
		_CU,
		_RCU,
		_WCU,
		_T,
		_LSI,
		_GSI,
		_VI
	],
	[
		0,
		1,
		1,
		1,
		() => Capacity$,
		() => SecondaryIndexesCapacityMap,
		() => SecondaryIndexesCapacityMap,
		() => VectorIndexesCapacityMap
	]
];
var Delete$ = [
	3,
	n0,
	_Del,
	0,
	[
		_K,
		_TN,
		_CE,
		_EAN,
		_EAV,
		_RVOCCF
	],
	[
		() => Key,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		0
	],
	2
];
var DeleteItemInput$ = [
	3,
	n0,
	_DII,
	0,
	[
		_TN,
		_K,
		_Ex,
		_COo,
		_RV,
		_RCC,
		_RICM,
		_CE,
		_EAN,
		_EAV,
		_RVOCCF
	],
	[
		0,
		() => Key,
		() => ExpectedAttributeMap,
		0,
		0,
		0,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		0
	],
	2
];
var DeleteItemOutput$ = [
	3,
	n0,
	_DIO,
	0,
	[
		_At,
		_CC,
		_ICM
	],
	[
		() => AttributeMap,
		() => ConsumedCapacity$,
		() => ItemCollectionMetrics$
	]
];
var DescribeEndpointsRequest$ = [
	3,
	n0,
	_DER,
	0,
	[],
	[]
];
var DescribeEndpointsResponse$ = [
	3,
	n0,
	_DERe,
	0,
	[_En],
	[() => Endpoints],
	1
];
var Endpoint$ = [
	3,
	n0,
	_End,
	0,
	[_Ad, _CPIM],
	[0, 1],
	2
];
var ExpectedAttributeValue$ = [
	3,
	n0,
	_EAVx,
	0,
	[
		_V,
		_Exi,
		_CO,
		_AVL
	],
	[
		() => AttributeValue$,
		2,
		0,
		() => AttributeValueList
	]
];
var GetItemInput$ = [
	3,
	n0,
	_GII,
	0,
	[
		_TN,
		_K,
		_ATG,
		_CRo,
		_RCC,
		_PE,
		_EAN
	],
	[
		0,
		() => Key,
		64,
		2,
		0,
		0,
		128
	],
	2
];
var GetItemOutput$ = [
	3,
	n0,
	_GIO,
	0,
	[_I, _CC],
	[() => AttributeMap, () => ConsumedCapacity$]
];
var ItemCollectionMetrics$ = [
	3,
	n0,
	_ICM,
	0,
	[_ICK, _SERGB],
	[() => ItemCollectionKeyAttributeMap, 65]
];
var Put$ = [
	3,
	n0,
	_Pu,
	0,
	[
		_I,
		_TN,
		_CE,
		_EAN,
		_EAV,
		_RVOCCF
	],
	[
		() => PutItemInputAttributeMap,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		0
	],
	2
];
var PutItemInput$ = [
	3,
	n0,
	_PII,
	0,
	[
		_TN,
		_I,
		_Ex,
		_RV,
		_RCC,
		_RICM,
		_COo,
		_CE,
		_EAN,
		_EAV,
		_RVOCCF
	],
	[
		0,
		() => PutItemInputAttributeMap,
		() => ExpectedAttributeMap,
		0,
		0,
		0,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		0
	],
	2
];
var PutItemOutput$ = [
	3,
	n0,
	_PIO,
	0,
	[
		_At,
		_CC,
		_ICM
	],
	[
		() => AttributeMap,
		() => ConsumedCapacity$,
		() => ItemCollectionMetrics$
	]
];
var QueryInput$ = [
	3,
	n0,
	_QI,
	0,
	[
		_TN,
		_IN,
		_Se,
		_ATG,
		_L,
		_CRo,
		_KC,
		_QF,
		_COo,
		_SIF,
		_ESK,
		_RCC,
		_PE,
		_FEi,
		_KCE,
		_EAN,
		_EAV
	],
	[
		0,
		0,
		0,
		64,
		1,
		2,
		() => KeyConditions,
		() => FilterConditionMap,
		0,
		2,
		() => Key,
		0,
		0,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap
	],
	1
];
var QueryOutput$ = [
	3,
	n0,
	_QO,
	0,
	[
		_It,
		_Cou,
		_SC,
		_LEK,
		_CC
	],
	[
		() => ItemList,
		1,
		1,
		() => Key,
		() => ConsumedCapacity$
	]
];
var ScanInput$ = [
	3,
	n0,
	_SI,
	0,
	[
		_TN,
		_IN,
		_ATG,
		_L,
		_Se,
		_SF,
		_COo,
		_ESK,
		_RCC,
		_TSo,
		_Seg,
		_PE,
		_FEi,
		_EAN,
		_EAV,
		_CRo
	],
	[
		0,
		0,
		64,
		1,
		0,
		() => FilterConditionMap,
		0,
		() => Key,
		0,
		1,
		1,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		2
	],
	1
];
var ScanOutput$ = [
	3,
	n0,
	_SO,
	0,
	[
		_It,
		_Cou,
		_SC,
		_LEK,
		_CC
	],
	[
		() => ItemList,
		1,
		1,
		() => Key,
		() => ConsumedCapacity$
	]
];
var ThrottlingReason$ = [
	3,
	n0,
	_TRh,
	0,
	[_r, _re],
	[0, 0]
];
var TransactWriteItem$ = [
	3,
	n0,
	_TWI,
	0,
	[
		_CCo,
		_Pu,
		_Del,
		_U
	],
	[
		() => ConditionCheck$,
		() => Put$,
		() => Delete$,
		() => Update$
	]
];
var TransactWriteItemsInput$ = [
	3,
	n0,
	_TWII,
	0,
	[
		_TIr,
		_RCC,
		_RICM,
		_CRT
	],
	[
		() => TransactWriteItemList,
		0,
		0,
		[0, 4]
	],
	1
];
var TransactWriteItemsOutput$ = [
	3,
	n0,
	_TWIO,
	0,
	[_CC, _ICM],
	[() => ConsumedCapacityMultiple, () => ItemCollectionMetricsPerTable]
];
var Update$ = [
	3,
	n0,
	_U,
	0,
	[
		_K,
		_UE,
		_TN,
		_CE,
		_EAN,
		_EAV,
		_RVOCCF
	],
	[
		() => Key,
		0,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		0
	],
	3
];
var UpdateItemInput$ = [
	3,
	n0,
	_UII,
	0,
	[
		_TN,
		_K,
		_AU,
		_Ex,
		_COo,
		_RV,
		_RCC,
		_RICM,
		_UE,
		_CE,
		_EAN,
		_EAV,
		_RVOCCF
	],
	[
		0,
		() => Key,
		() => AttributeUpdates,
		() => ExpectedAttributeMap,
		0,
		0,
		0,
		0,
		0,
		0,
		128,
		() => ExpressionAttributeValueMap,
		0
	],
	2
];
var UpdateItemOutput$ = [
	3,
	n0,
	_UIO,
	0,
	[
		_At,
		_CC,
		_ICM
	],
	[
		() => AttributeMap,
		() => ConsumedCapacity$,
		() => ItemCollectionMetrics$
	]
];
var VectorCapacity$ = [
	3,
	n0,
	_VC,
	0,
	[_VSRB, _VWRB],
	[1, 1]
];
var AttributeValueList = [
	1,
	n0,
	_AVL,
	0,
	() => AttributeValue$
];
var CancellationReasonList = [
	1,
	n0,
	_CRL,
	0,
	() => CancellationReason$
];
var ConsumedCapacityMultiple = [
	1,
	n0,
	_CCM,
	0,
	() => ConsumedCapacity$
];
var Endpoints = [
	1,
	n0,
	_En,
	0,
	() => Endpoint$
];
var ItemCollectionMetricsMultiple = [
	1,
	n0,
	_ICMM,
	0,
	() => ItemCollectionMetrics$
];
var ItemList = [
	1,
	n0,
	_IL,
	0,
	() => AttributeMap
];
var ListAttributeValue = [
	1,
	n0,
	_LAV,
	0,
	() => AttributeValue$
];
var ThrottlingReasonList = [
	1,
	n0,
	_TRL,
	0,
	() => ThrottlingReason$
];
var TransactWriteItemList = [
	1,
	n0,
	_TWIL,
	0,
	() => TransactWriteItem$
];
var AttributeMap = [
	2,
	n0,
	_AM,
	0,
	0,
	() => AttributeValue$
];
var AttributeUpdates = [
	2,
	n0,
	_AU,
	0,
	0,
	() => AttributeValueUpdate$
];
var ExpectedAttributeMap = [
	2,
	n0,
	_EAM,
	0,
	0,
	() => ExpectedAttributeValue$
];
var ExpressionAttributeValueMap = [
	2,
	n0,
	_EAVM,
	0,
	0,
	() => AttributeValue$
];
var FilterConditionMap = [
	2,
	n0,
	_FCM,
	0,
	0,
	() => Condition$
];
var ItemCollectionKeyAttributeMap = [
	2,
	n0,
	_ICKAM,
	0,
	0,
	() => AttributeValue$
];
var ItemCollectionMetricsPerTable = [
	2,
	n0,
	_ICMPT,
	0,
	0,
	() => ItemCollectionMetricsMultiple
];
var Key = [
	2,
	n0,
	_K,
	0,
	0,
	() => AttributeValue$
];
var KeyConditions = [
	2,
	n0,
	_KC,
	0,
	0,
	() => Condition$
];
var MapAttributeValue = [
	2,
	n0,
	_MAV,
	0,
	0,
	() => AttributeValue$
];
var PutItemInputAttributeMap = [
	2,
	n0,
	_PIIAM,
	0,
	0,
	() => AttributeValue$
];
var SecondaryIndexesCapacityMap = [
	2,
	n0,
	_SICM,
	0,
	0,
	() => Capacity$
];
var VectorIndexesCapacityMap = [
	2,
	n0,
	_VICM,
	0,
	0,
	() => VectorCapacity$
];
var AttributeValue$ = [
	4,
	n0,
	_AV,
	0,
	[
		_S_,
		_N,
		_B_,
		_SS_,
		_NS,
		_BS_,
		_M_,
		_L_,
		_NULL,
		_BOOL
	],
	[
		0,
		0,
		21,
		64,
		64,
		85,
		() => MapAttributeValue,
		() => ListAttributeValue,
		2,
		2
	]
];
var DeleteItem$ = [
	9,
	n0,
	_DI,
	0,
	() => DeleteItemInput$,
	() => DeleteItemOutput$
];
var DescribeEndpoints$ = [
	9,
	n0,
	_DE,
	0,
	() => DescribeEndpointsRequest$,
	() => DescribeEndpointsResponse$
];
var GetItem$ = [
	9,
	n0,
	_GI,
	0,
	() => GetItemInput$,
	() => GetItemOutput$
];
var PutItem$ = [
	9,
	n0,
	_PI,
	0,
	() => PutItemInput$,
	() => PutItemOutput$
];
var Query$ = [
	9,
	n0,
	_Q,
	0,
	() => QueryInput$,
	() => QueryOutput$
];
var Scan$ = [
	9,
	n0,
	_Sca,
	0,
	() => ScanInput$,
	() => ScanOutput$
];
var TransactWriteItems$ = [
	9,
	n0,
	_TWIr,
	0,
	() => TransactWriteItemsInput$,
	() => TransactWriteItemsOutput$
];
var UpdateItem$ = [
	9,
	n0,
	_UIp,
	0,
	() => UpdateItemInput$,
	() => UpdateItemOutput$
];
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeEndpointsCommand.js
var DescribeEndpointsCommand = class extends command(_ep0, _mw0, "DescribeEndpoints", DescribeEndpoints$) {};
var package_default = {
	name: "@aws-sdk/client-dynamodb",
	version: "3.1156.0",
	description: "AWS SDK for JavaScript Dynamodb Client for Node.js, Browser and React Native",
	homepage: "https://github.com/aws/aws-sdk-js-v3/tree/main/clients/client-dynamodb",
	license: "Apache-2.0",
	author: {
		"name": "AWS SDK for JavaScript Team",
		"url": "https://aws.amazon.com/sdk-for-javascript/"
	},
	repository: {
		"type": "git",
		"url": "https://github.com/aws/aws-sdk-js-v3.git",
		"directory": "clients/client-dynamodb"
	},
	files: ["dist-*/**"],
	sideEffects: false,
	main: "./dist-cjs/index.js",
	module: "./dist-es/index.js",
	browser: { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.browser" },
	types: "./dist-types/index.d.ts",
	typesVersions: { "<4.5": { "dist-types/*": ["dist-types/ts3.4/*"] } },
	"react-native": { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.native" },
	scripts: {
		"build": "concurrently 'yarn:build:types' 'yarn:build:es' && yarn build:cjs",
		"build:cjs": "node ../../scripts/compilation/inline",
		"build:es": "premove dist-es && tsc -p tsconfig.es.json",
		"build:include:deps": "yarn g:turbo run build -F=\"$npm_package_name\"",
		"build:types": "premove dist-types && tsc -p tsconfig.types.json",
		"build:types:downlevel": "downlevel-dts dist-types dist-types/ts3.4",
		"clean": "premove dist-cjs dist-es dist-types",
		"extract:docs": "api-extractor run --local",
		"generate:client": "node ../../scripts/generate-clients/single-service",
		"test": "yarn g:vitest run --passWithNoTests",
		"test:watch": "yarn g:vitest watch --passWithNoTests",
		"test:integration": "yarn g:vitest run --passWithNoTests -c vitest.config.integ.mts",
		"test:integration:watch": "yarn g:vitest watch --passWithNoTests -c vitest.config.integ.mts",
		"test:e2e": "yarn g:vitest run -c vitest.config.e2e.mts",
		"test:e2e:watch": "yarn g:vitest watch -c vitest.config.e2e.mts",
		"test:index": "tsc -p tsconfig.test.json && node ./test/index-objects.spec.mjs"
	},
	dependencies: {
		"@aws-sdk/core": "^3.978.5",
		"@aws-sdk/credential-provider-node": "^3.972.88",
		"@aws-sdk/dynamodb-codec": "^3.973.50",
		"@aws-sdk/middleware-endpoint-discovery": "^3.972.34",
		"@aws-sdk/types": "^3.975.0",
		"@smithy/core": "^3.36.1",
		"@smithy/fetch-http-handler": "^5.8.0",
		"@smithy/node-http-handler": "^4.12.1",
		"@smithy/types": "^4.19.0",
		"tslib": "^2.6.2"
	},
	devDependencies: {
		"@smithy/snapshot-testing": "^2.3.2",
		"@tsconfig/node20": "20.1.8",
		"@types/node": "^20.14.8",
		"concurrently": "7.0.0",
		"downlevel-dts": "0.10.1",
		"premove": "4.0.0",
		"typescript": "~7.0.2",
		"vitest": "^4.0.17"
	},
	engines: { "node": ">=20.0.0" }
};
// node_modules/@aws-sdk/dynamodb-codec/dist-es/codec-v2/DynamoDBJsonCodec2.js
var ATTRIBUTE_VALUE = "com.amazonaws.dynamodb#AttributeValue";
var DynamoDBJsonShapeSerializer2 = class extends import_protocols$1.JsonShapeSerializer2 {
	writeValue(schema, value, container) {
		if (value != null && typeof value === "object") {
			const ns = import_schema.NormalizedSchema.of(schema);
			if (ns.isStructSchema() && ns.getName(true) === ATTRIBUTE_VALUE) {
				this.writeAttributeValue(value);
				return;
			}
		}
		super.writeValue(schema, value, container);
	}
	writeAttributeValue(av) {
		const base64Encode = this.serdeContext?.base64Encoder ?? import_serde.toBase64;
		this.writeAscii("{");
		let first = true;
		for (const key in av) {
			const val = av[key];
			if (val == null) continue;
			if (!first) this.writeAscii(",");
			first = false;
			this.writeAsciiQuoted(key);
			this.writeAscii(":");
			switch (key) {
				case "B":
					if (val instanceof Uint8Array) this.writeBase64(val);
					else this.writeJsonString(val);
					break;
				case "BS":
					this.writeAscii("[");
					{
						const arr = val;
						for (let i = 0; i < arr.length; i++) {
							if (i > 0) this.writeAscii(",");
							const item = arr[i];
							if (item instanceof Uint8Array) this.writeBase64(item);
							else this.writeJsonString(base64Encode(item));
						}
					}
					this.writeAscii("]");
					break;
				case "L":
					this.writeAscii("[");
					{
						const arr = val;
						for (let i = 0; i < arr.length; i++) {
							if (i > 0) this.writeAscii(",");
							if (arr[i] != null) this.writeAttributeValue(arr[i]);
							else this.writeAscii("null");
						}
					}
					this.writeAscii("]");
					break;
				case "M":
					this.writeAscii("{");
					{
						const map = val;
						let mapFirst = true;
						for (const k in map) {
							if (map[k] == null) continue;
							if (!mapFirst) this.writeAscii(",");
							mapFirst = false;
							this.writeJsonString(k);
							this.writeAscii(":");
							this.writeAttributeValue(map[k]);
						}
					}
					this.writeAscii("}");
					break;
				case "SS":
				case "NS":
					this.writeAscii("[");
					{
						const arr = val;
						for (let i = 0; i < arr.length; i++) {
							if (i > 0) this.writeAscii(",");
							this.writeJsonString(arr[i]);
						}
					}
					this.writeAscii("]");
					break;
				case "S":
				case "N":
					this.writeJsonString(val);
					break;
				case "BOOL":
					this.writeAscii(val ? "true" : "false");
					break;
				case "NULL":
					this.writeAscii(val ? "true" : "false");
					break;
				default: this.writeAscii(JSON.stringify(val));
			}
		}
		this.writeAscii("}");
	}
};
var DynamoDBJsonShapeDeserializer2 = class extends import_protocols$1.JsonShapeDeserializer2 {
	_read(schema, value) {
		const ns = import_schema.NormalizedSchema.of(schema);
		if (ns.isStructSchema() && ns.getName(true) === ATTRIBUTE_VALUE) {
			if (value && typeof value === "object") return this.readAttributeValue(value);
		}
		return super._read(ns, value);
	}
	readAttributeValue(av) {
		const base64Decode = this.serdeContext?.base64Decoder ?? import_serde.fromBase64;
		const out = av;
		if (typeof av.B === "string") out.B = base64Decode(av.B);
		if (Array.isArray(av.BS)) out.BS = av.BS.map(base64Decode);
		if (Array.isArray(av.L)) out.L = av.L.map((v) => this.readAttributeValue(v));
		if (av.M && typeof av.M === "object") {
			const m = av.M;
			for (const k in m) m[k] = this.readAttributeValue(m[k]);
		}
		return out;
	}
};
var DynamoDBJsonCodec2 = class extends import_protocols$1.JsonCodec2 {
	constructor() {
		super({
			timestampFormat: {
				useTrait: true,
				default: 7
			},
			jsonName: false
		});
	}
	createSerializer() {
		const serializer = new DynamoDBJsonShapeSerializer2(this.settings);
		serializer.setSerdeContext(this.serdeContext);
		return serializer;
	}
	createDeserializer() {
		const deserializer = new DynamoDBJsonShapeDeserializer2(this.settings);
		deserializer.setSerdeContext(this.serdeContext);
		return deserializer;
	}
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/endpoint/bdd.js
var import_checksum = require_checksum();
init_dist_es();
var L = "ref";
var M = "argv";
var a = -1;
var b = true;
var c = false;
var d = "isSet";
var e = "booleanEquals";
var f = "PartitionResult";
var g = "stringEquals";
var h = "getAttr";
var i = "parsedEndpoint";
var j = "aws.parseArn";
var k = (n) => "ParsedArn_ssa_" + n;
var l = "service";
var m = "dynamodb";
var n = "isValidHostLabel";
var o = "accountId";
var p = "FirstArn";
var q = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.search-ddb.{Region}.{PartitionResult#dualStackDnsSuffix}";
var s = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.ddb.{Region}.{PartitionResult#dualStackDnsSuffix}";
var t = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.search-ddb.{Region}.{PartitionResult#dnsSuffix}";
var u = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.ddb.{Region}.{PartitionResult#dnsSuffix}";
var v = { [L]: "Region" };
var w = { [L]: f };
var x = {
	"fn": h,
	[M]: [{ [L]: i }, "authority"]
};
var y = { [L]: "AccountIdEndpointMode" };
var z = {
	"fn": h,
	[M]: [w, "name"]
};
var A = { [L]: "ParsedArn_ssa_2" };
var B = {
	"fn": h,
	[M]: [A, "region"]
};
var C = { [L]: "ResourceArnList" };
var D = {
	"fn": h,
	[M]: [{ [L]: "ParsedArn_ssa_1" }, "region"]
};
var E = { [L]: "ParsedArn_ssa_1" };
var F = { [L]: "AccountId" };
var G = {};
var H = { "metricValues": ["O"] };
var I = [v];
var J = [{ [L]: "Endpoint" }];
var K = [{ [L]: "ResourceArn" }];
var _data = {
	conditions: [
		[d, I],
		[d, J],
		[e, [{ [L]: "UseFIPS" }, b]],
		[e, [{ [L]: "UseDualStack" }, b]],
		[
			"aws.partition",
			I,
			f
		],
		[g, [v, "local"]],
		[e, [{
			fn: h,
			[M]: [w, "supportsFIPS"]
		}, b]],
		[
			"parseURL",
			J,
			i
		],
		[g, ["dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", x]],
		[e, [{
			fn: h,
			[M]: [w, "supportsDualStack"]
		}, b]],
		[g, ["search-dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", x]],
		[d, [y]],
		[g, [v, "us-gov-east-1"]],
		[g, [v, "cn-north-1"]],
		[g, [v, "cn-northwest-1"]],
		[g, [v, "us-gov-west-1"]],
		[g, [z, "aws"]],
		[g, [y, "disabled"]],
		[d, K],
		[
			j,
			K,
			k(2)
		],
		[g, [{
			fn: h,
			[M]: [A, l]
		}, m]],
		[g, [B, v]],
		[n, [{
			fn: h,
			[M]: [A, o]
		}, c]],
		[n, [B, c]],
		[d, [C]],
		[
			h,
			[C, "[0]"],
			p
		],
		[
			j,
			[{ [L]: p }],
			k(1)
		],
		[g, [D, v]],
		[g, [{
			fn: h,
			[M]: [E, l]
		}, m]],
		[n, [{
			fn: h,
			[M]: [E, o]
		}, c]],
		[n, [D, c]],
		[d, [F]],
		[g, [y, "required"]],
		[n, [F, c]],
		[g, [z, "aws-us-gov"]],
		[e, [{
			fn: "coalesce",
			[M]: [{ [L]: "IsSearchOperation" }, c]
		}, b]]
	],
	results: [
		[a],
		[a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
		[a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
		[a, "Endpoint override is not supported for dual-stack endpoints. Please enable dual-stack functionality by enabling the configuration. For more details, see: https://docs.aws.amazon.com/sdkref/latest/guide/feature-endpoints.html"],
		["{Endpoint}", G],
		[a, "Invalid Configuration: FIPS and local endpoint are not supported"],
		[a, "Invalid Configuration: Dualstack and local endpoint are not supported"],
		["http://localhost:8000", { authSchemes: [{
			signingRegion: "us-east-1",
			name: "sigv4",
			signingName: m
		}] }],
		[a, "Invalid Configuration: AccountIdEndpointMode is required and FIPS is enabled, but FIPS account endpoints are not supported"],
		["https://search-dynamodb-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
		["https://dynamodb-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
		[a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
		["https://search-dynamodb.{Region}.{PartitionResult#dnsSuffix}", G],
		["https://dynamodb.{Region}.{PartitionResult#dnsSuffix}", G],
		["https://search-dynamodb-fips.{Region}.{PartitionResult#dnsSuffix}", G],
		["https://dynamodb-fips.{Region}.{PartitionResult#dnsSuffix}", G],
		[a, "FIPS is enabled but this partition does not support FIPS"],
		[a, "Invalid Configuration: AccountIdEndpointMode is required but account endpoints are not supported in this region"],
		["https://search-dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
		["https://dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
		[q(2), H],
		[s(2), H],
		[q(1), H],
		[s(1), H],
		["https://{AccountId}.search-ddb.{Region}.{PartitionResult#dualStackDnsSuffix}", H],
		["https://{AccountId}.ddb.{Region}.{PartitionResult#dualStackDnsSuffix}", H],
		[a, "Credentials-sourced account ID parameter is invalid"],
		[a, "AccountIdEndpointMode is required but no AccountID was provided or able to be loaded"],
		[a, "DualStack is enabled but this partition does not support DualStack"],
		[t(2), H],
		[u(2), H],
		[t(1), H],
		[u(1), H],
		["https://{AccountId}.search-ddb.{Region}.{PartitionResult#dnsSuffix}", H],
		["https://{AccountId}.ddb.{Region}.{PartitionResult#dnsSuffix}", H],
		[a, "Invalid Configuration: Missing Region"]
	]
};
var root = 2;
var nodes = new Int32Array([
	-1,
	1,
	-1,
	0,
	6,
	3,
	1,
	4,
	100000035,
	2,
	100000001,
	5,
	3,
	100000002,
	100000004,
	1,
	85,
	7,
	2,
	69,
	8,
	3,
	38,
	9,
	4,
	10,
	100000035,
	5,
	100000007,
	11,
	11,
	12,
	77,
	12,
	18,
	13,
	13,
	18,
	14,
	14,
	18,
	15,
	15,
	18,
	16,
	16,
	18,
	17,
	32,
	100000017,
	77,
	17,
	37,
	19,
	18,
	20,
	25,
	19,
	21,
	25,
	20,
	22,
	25,
	21,
	23,
	25,
	22,
	24,
	25,
	23,
	36,
	25,
	24,
	26,
	32,
	25,
	27,
	32,
	26,
	28,
	32,
	27,
	29,
	32,
	28,
	30,
	32,
	29,
	31,
	32,
	30,
	35,
	32,
	31,
	33,
	37,
	33,
	34,
	100000026,
	35,
	100000033,
	100000034,
	35,
	100000031,
	100000032,
	35,
	100000029,
	100000030,
	32,
	100000027,
	77,
	4,
	39,
	100000035,
	5,
	100000006,
	40,
	9,
	41,
	100000028,
	11,
	42,
	68,
	12,
	48,
	43,
	13,
	48,
	44,
	14,
	48,
	45,
	15,
	48,
	46,
	16,
	48,
	47,
	32,
	100000017,
	68,
	17,
	67,
	49,
	18,
	50,
	55,
	19,
	51,
	55,
	20,
	52,
	55,
	21,
	53,
	55,
	22,
	54,
	55,
	23,
	66,
	55,
	24,
	56,
	62,
	25,
	57,
	62,
	26,
	58,
	62,
	27,
	59,
	62,
	28,
	60,
	62,
	29,
	61,
	62,
	30,
	65,
	62,
	31,
	63,
	67,
	33,
	64,
	100000026,
	35,
	100000024,
	100000025,
	35,
	100000022,
	100000023,
	35,
	100000020,
	100000021,
	32,
	100000027,
	68,
	35,
	100000018,
	100000019,
	3,
	78,
	70,
	4,
	71,
	100000035,
	5,
	100000005,
	72,
	6,
	73,
	100000016,
	11,
	74,
	75,
	32,
	100000008,
	75,
	34,
	77,
	76,
	35,
	100000014,
	100000015,
	35,
	100000012,
	100000013,
	4,
	79,
	100000035,
	5,
	100000005,
	80,
	6,
	81,
	100000011,
	9,
	82,
	100000011,
	11,
	83,
	84,
	32,
	100000008,
	84,
	35,
	100000009,
	100000010,
	2,
	100000001,
	86,
	3,
	100000002,
	87,
	4,
	88,
	100000004,
	7,
	89,
	100000004,
	8,
	100000003,
	90,
	10,
	100000003,
	100000004
]);
var bdd = import_endpoints.BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);
// node_modules/@aws-sdk/client-dynamodb/dist-es/endpoint/endpointResolver.js
var cache = new import_endpoints.EndpointCache({
	size: 50,
	params: [
		"AccountId",
		"AccountIdEndpointMode",
		"Endpoint",
		"IsSearchOperation",
		"Region",
		"ResourceArn",
		"ResourceArnList",
		"UseDualStack",
		"UseFIPS"
	]
});
var defaultEndpointResolver = (endpointParams, context = {}) => {
	return cache.get(endpointParams, () => (0, import_endpoints.decideEndpoint)(bdd, {
		endpointParams,
		logger: context.logger
	}));
};
import_endpoints.customEndpointFunctions.aws = import_client.awsEndpointFunctions;
// node_modules/@aws-sdk/client-dynamodb/dist-es/runtimeConfig.shared.js
var getRuntimeConfig$1 = (config) => {
	return {
		apiVersion: "2012-08-10",
		base64Decoder: config?.base64Decoder ?? import_serde.fromBase64,
		base64Encoder: config?.base64Encoder ?? import_serde.toBase64,
		disableHostPrefix: config?.disableHostPrefix ?? false,
		endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
		extensions: config?.extensions ?? [],
		httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultDynamoDBHttpAuthSchemeProvider,
		httpAuthSchemes: config?.httpAuthSchemes ?? [{
			schemeId: "aws.auth#sigv4",
			identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
			signer: new import_httpAuthSchemes.AwsSdkSigV4Signer()
		}],
		logger: config?.logger ?? new import_client$1.NoOpLogger(),
		protocol: config?.protocol ?? import_protocols$1.AwsJson1_0Protocol,
		protocolSettings: config?.protocolSettings ?? {
			defaultNamespace: "com.amazonaws.dynamodb",
			errorTypeRegistries,
			xmlNamespace: "http://dynamodb.amazonaws.com/doc/2012-08-10/",
			version: "2012-08-10",
			serviceTarget: "DynamoDB_20120810",
			jsonCodec: new DynamoDBJsonCodec2()
		},
		serviceId: config?.serviceId ?? "DynamoDB",
		sha256: config?.sha256 ?? import_checksum.Sha256,
		urlParser: config?.urlParser ?? import_protocols.parseUrl,
		utf8Decoder: config?.utf8Decoder ?? import_serde.fromUtf8,
		utf8Encoder: config?.utf8Encoder ?? import_serde.toUtf8
	};
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/runtimeConfig.js
var getRuntimeConfig = (config) => {
	(0, import_client$1.emitWarningIfUnsupportedVersion)(process.version);
	const defaultsMode = (0, import_config.resolveDefaultsModeConfig)(config);
	const defaultConfigProvider = () => defaultsMode().then(import_client$1.loadConfigsForDefaultMode);
	const clientSharedValues = getRuntimeConfig$1(config);
	(0, import_client.emitWarningIfUnsupportedVersion)(process.version);
	const loaderConfig = {
		profile: config?.profile,
		logger: clientSharedValues.logger
	};
	return {
		...clientSharedValues,
		...config,
		runtime: "node",
		defaultsMode,
		accountIdEndpointMode: config?.accountIdEndpointMode ?? (0, import_config.loadConfig)(import_account_id_endpoint.NODE_ACCOUNT_ID_ENDPOINT_MODE_CONFIG_OPTIONS, loaderConfig),
		authSchemePreference: config?.authSchemePreference ?? (0, import_config.loadConfig)(import_httpAuthSchemes.NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
		bodyLengthChecker: config?.bodyLengthChecker ?? import_serde.calculateBodyLength,
		credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
		defaultUserAgentProvider: config?.defaultUserAgentProvider ?? (0, import_client.createDefaultUserAgentProvider)({
			serviceId: clientSharedValues.serviceId,
			clientVersion: package_default.version
		}),
		endpointDiscoveryEnabledProvider: config?.endpointDiscoveryEnabledProvider ?? (0, import_config.loadConfig)(NODE_ENDPOINT_DISCOVERY_CONFIG_OPTIONS, loaderConfig),
		maxAttempts: config?.maxAttempts ?? (0, import_config.loadConfig)(import_retry.Retry.v2026 ? {
			...import_retry.NODE_MAX_ATTEMPT_CONFIG_OPTIONS,
			default: 4
		} : import_retry.NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
		region: config?.region ?? (0, import_config.loadConfig)(import_config.NODE_REGION_CONFIG_OPTIONS, {
			...import_config.NODE_REGION_CONFIG_FILE_OPTIONS,
			...loaderConfig
		}),
		requestHandler: NodeHttpHandler.create(config?.requestHandler ?? defaultConfigProvider),
		retryMode: config?.retryMode ?? (0, import_config.loadConfig)({
			...import_retry.NODE_RETRY_MODE_CONFIG_OPTIONS,
			default: async () => (await defaultConfigProvider()).retryMode || import_retry.DEFAULT_RETRY_MODE
		}, config),
		streamCollector: config?.streamCollector ?? import_serde$1.streamCollector,
		useDualstackEndpoint: config?.useDualstackEndpoint ?? (0, import_config.loadConfig)(import_config.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
		useFipsEndpoint: config?.useFipsEndpoint ?? (0, import_config.loadConfig)(import_config.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
		userAgentAppId: config?.userAgentAppId ?? (0, import_config.loadConfig)(import_client.NODE_APP_ID_CONFIG_OPTIONS, loaderConfig)
	};
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/auth/httpAuthExtensionConfiguration.js
var getHttpAuthExtensionConfiguration = (runtimeConfig) => {
	const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
	let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
	let _credentials = runtimeConfig.credentials;
	return {
		setHttpAuthScheme(httpAuthScheme) {
			const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
			if (index === -1) _httpAuthSchemes.push(httpAuthScheme);
			else _httpAuthSchemes.splice(index, 1, httpAuthScheme);
		},
		httpAuthSchemes() {
			return _httpAuthSchemes;
		},
		setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
			_httpAuthSchemeProvider = httpAuthSchemeProvider;
		},
		httpAuthSchemeProvider() {
			return _httpAuthSchemeProvider;
		},
		setCredentials(credentials) {
			_credentials = credentials;
		},
		credentials() {
			return _credentials;
		}
	};
};
var resolveHttpAuthRuntimeConfig = (config) => {
	return {
		httpAuthSchemes: config.httpAuthSchemes(),
		httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
		credentials: config.credentials()
	};
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/runtimeExtensions.js
var resolveRuntimeExtensions = (runtimeConfig, extensions) => {
	const extensionConfiguration = Object.assign((0, import_client.getAwsRegionExtensionConfiguration)(runtimeConfig), (0, import_client$1.getDefaultExtensionConfiguration)(runtimeConfig), (0, import_protocols.getHttpHandlerExtensionConfiguration)(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
	extensions.forEach((extension) => extension.configure(extensionConfiguration));
	return Object.assign(runtimeConfig, (0, import_client.resolveAwsRegionExtensionConfiguration)(extensionConfiguration), (0, import_client$1.resolveDefaultRuntimeConfig)(extensionConfiguration), (0, import_protocols.resolveHttpHandlerRuntimeConfig)(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/DynamoDBClient.js
var DynamoDBClient = class extends import_client$1.Client {
	config;
	constructor(...[configuration]) {
		const _config_0 = getRuntimeConfig(configuration || {});
		super(_config_0);
		this.initConfig = _config_0;
		const _config_1 = resolveClientEndpointParameters(_config_0);
		const _config_2 = (0, import_account_id_endpoint.resolveAccountIdEndpointModeConfig)(_config_1);
		const _config_3 = (0, import_client.resolveUserAgentConfig)(_config_2);
		const _config_4 = (0, import_retry.resolveRetryConfig)(_config_3, {
			defaultBaseDelay: import_retry.Retry.v2026 ? 25 : void 0,
			defaultMaxAttempts: import_retry.Retry.v2026 ? 4 : void 0
		});
		const _config_5 = (0, import_config.resolveRegionConfig)(_config_4);
		const _config_6 = (0, import_client.resolveHostHeaderConfig)(_config_5);
		const _config_10 = resolveRuntimeExtensions(resolveEndpointDiscoveryConfig(resolveHttpAuthSchemeConfig((0, import_endpoints.resolveEndpointConfig)(_config_6)), { endpointDiscoveryCommandCtor: DescribeEndpointsCommand }), configuration?.extensions || []);
		this.config = _config_10;
		this.middlewareStack.use((0, import_schema.getSchemaSerdePlugin)(this.config));
		this.middlewareStack.use((0, import_client.getUserAgentPlugin)(this.config));
		this.middlewareStack.use((0, import_retry.getRetryPlugin)(this.config));
		this.middlewareStack.use((0, import_protocols.getContentLengthPlugin)(this.config));
		this.middlewareStack.use((0, import_client.getHostHeaderPlugin)(this.config));
		this.middlewareStack.use((0, import_client.getLoggerPlugin)(this.config));
		this.middlewareStack.use((0, import_client.getRecursionDetectionPlugin)(this.config));
		this.middlewareStack.use((0, import_dist_cjs.getHttpAuthSchemeEndpointRuleSetPlugin)(this.config, {
			httpAuthSchemeParametersProvider: defaultDynamoDBHttpAuthSchemeParametersProvider,
			identityProviderConfigProvider: async (config) => new import_dist_cjs.DefaultIdentityProviderConfig({ "aws.auth#sigv4": config.credentials })
		}));
		this.middlewareStack.use((0, import_dist_cjs.getHttpSigningPlugin)(this.config));
	}
	destroy() {
		super.destroy();
	}
};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DeleteItemCommand.js
var DeleteItemCommand = class extends command(_ep2, _mw0, "DeleteItem", DeleteItem$) {};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/GetItemCommand.js
var GetItemCommand = class extends command(_ep2, _mw0, "GetItem", GetItem$) {};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/PutItemCommand.js
var PutItemCommand = class extends command(_ep2, _mw0, "PutItem", PutItem$) {};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/QueryCommand.js
var QueryCommand = class extends command(_ep2, _mw0, "Query", Query$) {};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ScanCommand.js
var ScanCommand = class extends command(_ep2, _mw0, "Scan", Scan$) {};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactWriteItemsCommand.js
var TransactWriteItemsCommand = class extends command(_ep13, _mw0, "TransactWriteItems", TransactWriteItems$) {};
// node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateItemCommand.js
var UpdateItemCommand = class extends command(_ep2, _mw0, "UpdateItem", UpdateItem$) {};
export { PutItemCommand as a, DynamoDBClient as c, QueryCommand as i, TransactionCanceledException as l, TransactWriteItemsCommand as n, GetItemCommand as o, ScanCommand as r, DeleteItemCommand as s, UpdateItemCommand as t };
