import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "./@floating-ui/react-dom+[...].mjs";
import { c as useLayoutEffect2, d as createSlot, f as useComposedRefs, l as createContextScope, p as require_jsx_runtime } from "./@radix-ui/react-checkbox+[...].mjs";
// node_modules/@radix-ui/react-collection/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
// @__NO_SIDE_EFFECTS__
function createCollection(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionProviderImpl, useCollectionContext] = createCollectionContext(PROVIDER_NAME, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	});
	const CollectionProvider = /* @__PURE__ */ __name((props) => {
		const { scope, children } = props;
		const ref = import_react.useRef(null);
		const itemMap = import_react.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			scope,
			itemMap,
			collectionRef: ref,
			children
		});
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const composedRefs = useComposedRefs(forwardedRef, ref);
		const context = useCollectionContext(ITEM_SLOT_NAME, scope);
		import_react.useEffect(() => {
			context.itemMap.set(ref, {
				ref,
				...itemData
			});
			return () => void context.itemMap.delete(ref);
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useCollection(scope) {
		const context = useCollectionContext(name + "CollectionConsumer", scope);
		return import_react.useCallback(() => {
			const collectionNode = context.collectionRef.current;
			if (!collectionNode) return [];
			const orderedNodes = Array.from(collectionNode.querySelectorAll(`[${ITEM_DATA_ATTR}]`));
			return Array.from(context.itemMap.values()).sort((a, b) => orderedNodes.indexOf(a.ref.current) - orderedNodes.indexOf(b.ref.current));
		}, [context.collectionRef, context.itemMap]);
	}
	__name(useCollection, "useCollection");
	return [
		{
			Provider: CollectionProvider,
			Slot: CollectionSlot,
			ItemSlot: CollectionItemSlot
		},
		useCollection,
		createCollectionScope
	];
}
__name(createCollection, "createCollection");
var __instanciated = /* @__PURE__ */ new WeakMap();
var OrderedDict = class _OrderedDict extends Map {
	static {
		__name(this, "OrderedDict");
	}
	#keys;
	constructor(entries) {
		super(entries);
		this.#keys = [...super.keys()];
		__instanciated.set(this, true);
	}
	set(key, value) {
		if (__instanciated.get(this) && !this.has(key)) this.#keys.push(key);
		super.set(key, value);
		return this;
	}
	/**
	* Sets a key-value pair so that it ends up at the given index.
	* - Existing keys are moved
	* - Negative indices count from the end of the resulting dictionary, so
	*   inserting at -1 makes the item the last one, -2 the second to last, etc.
	* - Out-of-range indices are clamped
	*/
	insert(index, key, value) {
		const has = this.has(key);
		const finalSize = has ? this.size : this.size + 1;
		const relativeIndex = toSafeInteger(index);
		const targetIndex = relativeIndex >= 0 ? Math.min(relativeIndex, finalSize - 1) : Math.max(finalSize + relativeIndex, 0);
		if (has ? this.#keys.indexOf(key) === targetIndex : targetIndex === this.size) {
			this.set(key, value);
			return this;
		}
		const keys = this.#keys.filter((existingKey) => existingKey !== key);
		keys.splice(targetIndex, 0, key);
		const entries = keys.map((entryKey) => [entryKey, entryKey === key ? value : this.get(entryKey)]);
		this.clear();
		for (const [entryKey, entryValue] of entries) this.set(entryKey, entryValue);
		return this;
	}
	with(index, key, value) {
		const copy = new _OrderedDict(this);
		copy.insert(index, key, value);
		return copy;
	}
	before(key) {
		const index = this.#keys.indexOf(key) - 1;
		if (index < 0) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position before the given key.
	*/
	setBefore(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		const currentIndex = this.#keys.indexOf(newKey);
		const targetIndex = currentIndex !== -1 && currentIndex < index ? index - 1 : index;
		return this.insert(targetIndex, newKey, value);
	}
	after(key) {
		let index = this.#keys.indexOf(key);
		index = index === -1 || index === this.size - 1 ? -1 : index + 1;
		if (index === -1) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position after the given key.
	*/
	setAfter(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		const currentIndex = this.#keys.indexOf(newKey);
		const targetIndex = currentIndex !== -1 && currentIndex <= index ? index : index + 1;
		return this.insert(targetIndex, newKey, value);
	}
	first() {
		return this.entryAt(0);
	}
	last() {
		return this.entryAt(-1);
	}
	clear() {
		this.#keys = [];
		return super.clear();
	}
	delete(key) {
		const deleted = super.delete(key);
		if (deleted) this.#keys.splice(this.#keys.indexOf(key), 1);
		return deleted;
	}
	deleteAt(index) {
		const key = this.keyAt(index);
		if (key !== void 0) return this.delete(key);
		return false;
	}
	at(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return this.get(key);
	}
	entryAt(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return [key, this.get(key)];
	}
	indexOf(key) {
		return this.#keys.indexOf(key);
	}
	keyAt(index) {
		return at(this.#keys, index);
	}
	from(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.at(dest);
	}
	keyFrom(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.keyAt(dest);
	}
	find(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return entry;
			index++;
		}
	}
	findIndex(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return index;
			index++;
		}
		return -1;
	}
	filter(predicate, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) entries.push(entry);
			index++;
		}
		return new _OrderedDict(entries);
	}
	map(callbackfn, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			entries.push([entry[0], Reflect.apply(callbackfn, thisArg, [
				entry,
				index,
				this
			])]);
			index++;
		}
		return new _OrderedDict(entries);
	}
	reduce(...args) {
		const [callbackfn, initialValue] = args;
		const hasInitialValue = args.length > 1;
		if (!hasInitialValue && this.size === 0) throw new TypeError("Reduce of empty OrderedDict with no initial value");
		let index = 0;
		let accumulator = initialValue;
		for (const entry of this) {
			if (index === 0 && !hasInitialValue) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
			index++;
		}
		return accumulator;
	}
	reduceRight(...args) {
		const [callbackfn, initialValue] = args;
		const hasInitialValue = args.length > 1;
		if (!hasInitialValue && this.size === 0) throw new TypeError("Reduce of empty OrderedDict with no initial value");
		let accumulator = initialValue;
		for (let index = this.size - 1; index >= 0; index--) {
			const entry = this.entryAt(index);
			if (index === this.size - 1 && !hasInitialValue) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
		}
		return accumulator;
	}
	/**
	* Sorts the dictionary in place. This method mutates the dictionary and
	* returns a reference to the same object
	*
	* @param compareFn Function used to determine the order of the elements. It
	* is expected to return a negative value if the first argument is less than
	* the second argument, zero if they're equal, and a positive value otherwise.
	*/
	sort(compareFn) {
		if (typeof compareFn !== "function") throw new TypeError(`OrderedDict.sort requires a compare function`);
		const entries = [...this.entries()].sort(compareFn);
		this.clear();
		for (const [key, value] of entries) this.set(key, value);
		return this;
	}
	/**
	* Returns a copy of the dictionary with its elements sorted.
	*
	* @param compareFn Function used to determine the order of the elements. It
	* is expected to return a negative value if the first argument is less than
	* the second argument, zero if they're equal, and a positive value otherwise.
	*/
	toSorted(compareFn) {
		if (typeof compareFn !== "function") throw new TypeError(`OrderedDict.toSorted requires a compare function`);
		const entries = [...this.entries()].sort(compareFn);
		return new _OrderedDict(entries);
	}
	toReversed() {
		const reversed = new _OrderedDict();
		for (let index = this.size - 1; index >= 0; index--) {
			const key = this.keyAt(index);
			const element = this.get(key);
			reversed.set(key, element);
		}
		return reversed;
	}
	toSpliced(...args) {
		const entries = [...this.entries()];
		entries.splice(...args);
		return new _OrderedDict(entries);
	}
	slice(start, end) {
		const result = new _OrderedDict();
		for (const key of this.#keys.slice(start, end)) result.set(key, this.get(key));
		return result;
	}
	every(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (!Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return false;
			index++;
		}
		return true;
	}
	some(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return true;
			index++;
		}
		return false;
	}
};
function at(array, index) {
	if ("at" in Array.prototype) return Array.prototype.at.call(array, index);
	const actualIndex = toSafeIndex(array, index);
	return actualIndex === -1 ? void 0 : array[actualIndex];
}
__name(at, "at");
function toSafeIndex(array, index) {
	const length = array.length;
	const relativeIndex = toSafeInteger(index);
	const actualIndex = relativeIndex >= 0 ? relativeIndex : length + relativeIndex;
	return actualIndex < 0 || actualIndex >= length ? -1 : actualIndex;
}
__name(toSafeIndex, "toSafeIndex");
function toSafeInteger(number) {
	return number !== number || number === 0 ? 0 : Math.trunc(number);
}
__name(toSafeInteger, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function createCollection2(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionStableContextProvider, useStableCollectionContext] = createCollectionContext(PROVIDER_NAME);
	CollectionStableContextProvider.displayName = name + "CollectionStableContextProvider";
	const [CollectionStatefulContextProvider, useStatefulCollectionContext] = createCollectionContext(PROVIDER_NAME);
	CollectionStatefulContextProvider.displayName = name + "CollectionStatefulContextProvider";
	const CollectionProvider = /* @__PURE__ */ __name(({ state, ...props }) => {
		return state ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionInit, { ...props });
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const CollectionInit = /* @__PURE__ */ __name((props) => {
		const state = useInitCollection();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		});
	}, "CollectionInit");
	CollectionInit.displayName = name + "CollectionInit";
	const CollectionProviderImpl = /* @__PURE__ */ __name((props) => {
		const { scope, children, state } = props;
		const ref = import_react.useRef(null);
		const [collectionElement, setCollectionElement] = import_react.useState(null);
		const composeRefs = useComposedRefs(ref, setCollectionElement);
		const [collection, setCollection] = state;
		const registryRef = import_react.useRef(new OrderedDict());
		const getCollection = import_react.useCallback(() => {
			const registry = registryRef.current;
			if (!isInDocumentOrder(registry)) registry.sort(sortByDocumentPosition);
			return registry;
		}, []);
		import_react.useEffect(() => {
			if (!collectionElement) return;
			const observer = getChildListObserver(() => {
				setCollection((map) => {
					const sorted = map.toSorted(sortByDocumentPosition);
					return sorted.some(([key], index) => map.keyAt(index) !== key) ? sorted : map;
				});
			});
			observer.observe(collectionElement, {
				childList: true,
				subtree: true
			});
			return () => {
				observer.disconnect();
			};
		}, [collectionElement, setCollection]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionStableContextProvider, {
			scope,
			collectionElementRef: composeRefs,
			collectionElementRefObject: ref,
			getCollection,
			setCollection,
			registryRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionStatefulContextProvider, {
				scope,
				collectionElement,
				collection,
				children
			})
		});
	}, "CollectionProviderImpl");
	CollectionProviderImpl.displayName = name + "CollectionProviderImpl";
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useStableCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionElementRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const { setCollection, registryRef } = useStableCollectionContext(ITEM_SLOT_NAME, scope);
		const itemDataRef = import_react.useRef(itemData);
		if (!shallowEqual(itemDataRef.current, itemData)) itemDataRef.current = itemData;
		const memoizedItemData = itemDataRef.current;
		const registerElement = import_react.useCallback((node) => {
			const registry = registryRef.current;
			if (node) registry.set(node, {
				...itemDataRef.current,
				element: node
			});
			else if (ref.current) registry.delete(ref.current);
		}, [registryRef]);
		const composedRefs = useComposedRefs(forwardedRef, registerElement, ref);
		useLayoutEffect2(() => {
			const node = ref.current;
			const registry = registryRef.current;
			if (node && registry.has(node)) registry.set(node, {
				...memoizedItemData,
				element: node
			});
		}, [memoizedItemData, registryRef]);
		const registeredRef = import_react.useRef(null);
		import_react.useEffect(() => {
			const element = ref.current;
			const registered = registeredRef.current;
			if ((registered?.element ?? null) === element && (!element || registered?.itemData === memoizedItemData)) return;
			registeredRef.current = element ? {
				element,
				itemData: memoizedItemData
			} : null;
			setCollection((map) => {
				const next = new OrderedDict(map);
				if (registered && registered.element !== element) next.delete(registered.element);
				if (element) next.set(element, {
					...memoizedItemData,
					element
				});
				return next.sort(sortByDocumentPosition);
			});
		});
		import_react.useEffect(() => {
			return () => {
				const registered = registeredRef.current;
				registeredRef.current = null;
				if (!registered) return;
				setCollection((map) => {
					if (!map.has(registered.element)) return map;
					const next = new OrderedDict(map);
					next.delete(registered.element);
					return next;
				});
			};
		}, [setCollection]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useInitCollection() {
		return import_react.useState(new OrderedDict());
	}
	__name(useInitCollection, "useInitCollection");
	function useCollection(scope) {
		const { collection } = useStatefulCollectionContext(name + "CollectionConsumer", scope);
		return collection;
	}
	__name(useCollection, "useCollection");
	function useGetCollection(scope) {
		const { getCollection } = useStableCollectionContext(name + "CollectionConsumer", scope);
		return getCollection;
	}
	__name(useGetCollection, "useGetCollection");
	return [{
		Provider: CollectionProvider,
		Slot: CollectionSlot,
		ItemSlot: CollectionItemSlot
	}, {
		createCollectionScope,
		useCollection,
		useGetCollection,
		useInitCollection
	}];
}
__name(createCollection2, "createCollection");
function shallowEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== "object" || typeof b !== "object") return false;
	if (a == null || b == null) return false;
	const keysA = Object.keys(a);
	const keysB = Object.keys(b);
	if (keysA.length !== keysB.length) return false;
	for (const key of keysA) {
		if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
		if (a[key] !== b[key]) return false;
	}
	return true;
}
__name(shallowEqual, "shallowEqual");
function isElementPreceding(a, b) {
	return !!(b.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_PRECEDING);
}
__name(isElementPreceding, "isElementPreceding");
function isInDocumentOrder(dict) {
	let previous;
	for (const element of dict.keys()) {
		if (previous) {
			const position = previous.compareDocumentPosition(element);
			if (!(position & Node.DOCUMENT_POSITION_DISCONNECTED) && position & Node.DOCUMENT_POSITION_PRECEDING) return false;
		}
		previous = element;
	}
	return true;
}
__name(isInDocumentOrder, "isInDocumentOrder");
function sortByDocumentPosition(a, b) {
	return !a[1].element || !b[1].element ? 0 : isElementPreceding(a[1].element, b[1].element) ? -1 : 1;
}
__name(sortByDocumentPosition, "sortByDocumentPosition");
function getChildListObserver(callback) {
	return new MutationObserver((mutationsList) => {
		for (const mutation of mutationsList) if (mutation.type === "childList") {
			callback();
			return;
		}
	});
}
__name(getChildListObserver, "getChildListObserver");
export { createCollection as t };
